---
name: reel-dinamico
description: Edita Reel talking-head do @yangalasso no padrão dinâmico aprovado (série "30 dias, 30 skills do Claude", Dia 01 v2, 03/11/2026) - tela dividida com motion graphics Infuser v2 em cima e rosto embaixo, cena nova a cada ~2 s, rosto cheio com punch-in, legenda palavra a palavra na emenda, mosaico de fecho e SFX real CC0 (Openverse + earshot + real-sfx). Use quando pedirem para editar um reel gravado de frente, "edita o vídeo do dia N", "monta o reel com o prompt do card", "deixa dinâmico como o do Fabiano Carvalho", ou colarem o prompt de edição de um card da série com o vídeo bruto.
---

# reel-dinamico

O Yan grava só a fala, de frente. Tudo de tela é gerado: painel animado, legenda, stickers, SFX. O padrão
foi medido em dois reels de referência (Fabiano Carvalho, cena nova a cada ~2,3 s) e aprovado pelo Yan no
Dia 01 v2 ("de resto, perfeito, mantenha essa consistência"). **Não invente estilo**: as cenas, a paleta,
a fonte e o ritmo vêm daqui. O que muda por vídeo é o conteúdo das cenas.

## Entrada
- Vídeo bruto (iPhone, vertical; HDR é convertido sozinho).
- Do card: roteiro, mapa visual (frase → tela), dados do dia (skill, tagline, repo, estrelas, comando de
  instalação, palavra-chave do CTA, título do gancho).

## Saída (pasta do projeto)
`<saida>.mp4` (1080x1920, 30 fps, H.264, AAC 48 kHz, -14 LUFS), `capa-<saida>.png`, `work/checklist.md`,
`work/folha-*.png` (1 quadro por segundo), `work/sfx/criticas.txt`.

## Passo a passo
Rode os scripts de dentro desta pasta da skill. `PASTA` é a pasta do projeto do vídeo.

1. **Criar a pasta** com `projeto.json` (modelo em `references/projeto.md`) e, se o mapa pede README ou
   página, o screenshot em `PASTA/assets/` (Playwright, viewport 1280, dark, deviceScaleFactor 2; pasta de
   skill sem README: use o `SKILL.md` renderizado em `blob/...`).
2. `python scripts/reel.py PASTA --de 1 --ate 1` transcreve **cada ilha de fala sozinha**. Leia a tabela
   contra o roteiro e escreva `"manter"` no `projeto.json`: tropeço e take repetido saem (fica o ÚLTIMO),
   comentário fora do roteiro sai, ilha sem fala sai. Ilha que mistura tropeço e frase boa: use
   `{"id": "i08", "inicio": s, "fim": s}`.
3. Escreva `PASTA/cenas.json`: uma cena por trecho mantido (ou por frase do mapa visual), no catálogo de
   `references/cenas.md`. Tempos são **palavras-âncora** (`"em": "marca"`, `"te#2"`, `"aponta+0.1"`), nunca
   segundos: re-cortar não quebra nada. Regra de ritmo: nenhuma cena de painel parada mais de ~3,5 s;
   dentro dela, algo novo a cada 0,5 a 1 s.
4. `python scripts/reel.py PASTA` roda as etapas 2 a 7 (plano, base, gráficos, composição, SFX, checklist).
5. Abra `work/folha-*.png` e confira com os olhos; leia `work/checklist.md` e `work/sfx/criticas.txt`.
   Ajuste `cenas.json`/`projeto.json` e rode de novo a partir da etapa certa (`--de 4` refaz gráficos).
6. Entregue dizendo o que foi medido e o que só o ouvido do Yan confirma (os 3 a 4 momentos que a crítica
   da real-sfx lista).

## Regras que já morderam (não repetir)
- **Tropeço some se transcrever o vídeo inteiro**: o whisper cola "ele faz a... ele te faz" numa frase só.
  Por isso a etapa 1 é por ilha. Ilha curta de "obrigado"/ruído também é tropeço.
- **HDR do iPhone** (HLG) sai lavado sem tonemap; a etapa 3 detecta e converte.
- **Rosto**: o enquadramento real fica mais baixo do que a bíblia antiga supunha. Ajuste `"rosto": [x, y]`
  (centro do rosto no quadro 1080x1920 do bruto) se a pessoa estiver deslocada; a tela dividida e o rosto
  cheio se posicionam por ele.
- **Legenda na emenda (y 960)**, 1 a 3 palavras, uma linha. Nome errado da transcrição se corrige em
  `"grafias"`, não à mão na legenda.
- **SFX**: nome de arquivo mente (um "click" era estalo de boca); o earshot classifica cada som. Balão de
  chat, envio e colagem usam uisfx (CC0, interface). Cada gravação no máximo 2x por vídeo.
- **Crítica do earshot**: "sem música" é proposital (o Yan põe a música no app do Instagram); "salient hits
  demais" vem da própria fala (medido: só a voz já dá 1,93/s). Não "corrija" esses dois.
- Texto de tela em português; inglês só em nome de skill, comando e screenshot real. Exemplo ilustrativo leva
  o rótulo "exemplo" (o padrão das cenas já põe). Nunca número inventado apresentado como dado real.

## Referências
- `references/projeto.md`: campos do `projeto.json`.
- `references/cenas.md`: catálogo de cenas, parâmetros e o som que cada momento recebe.
- `references/biblia.md`: identidade, zonas, modos de quadro, legenda, movimento.
- `references/sfx.md`: biblioteca, classificação, mix e como ler as críticas.
- `references/setup.md`: dependências da máquina (GPU, Playwright, real-sfx, earshot).
- `references/prompt-card.md`: o prompt curto que vai em cada card da série.
- `exemplos/dia-01/`: projeto completo do Dia 01 (o vídeo aprovado).
