"""Etapa 4: resolve as âncoras do cenas.json em segundos e renderiza tudo que é gráfico.

Saídas: work/cenas.json (resolvido, com modo, t0/t1, punches, stickers e eventos de som),
work/painel/fNNNNN.jpg (painel de cima de cada quadro em tela dividida), work/legendas/*.png, work/stickers/*.png.
"""
import math
import os
import re
from urllib.parse import quote, urlencode

from playwright.sync_api import sync_playwright

from common import FPS, SKILL, Anchors, ProjectError, load, norm, run_main, save

MODES = {"rosto": "F", "mosaico": "M"}
SEGUE_HOLD = 1.2

# Which sound each anchored moment gets (sound kinds are explained in references/sfx.md). "som" in the JSON overrides.
SOUNDS = {
    ("gancho", "linhas"): "ui:paste", ("nascer", "em"): "pop2", ("card", "em_trilha"): "ding", ("grade", "em_aceso"): "ding",
    ("grade", "selo"): "pop", ("chat", "tecla"): "ui:copy", ("chat", "itens"): "ui:receive|paste|drop",
    ("limpar", "em_clique"): "key", ("limpar", "frase"): "hit", ("arvore", "em"): "typing:1.1", ("arvore", "em_destaque"): "pop",
    ("arvore", "selo"): "ding", ("tela", "selos"): "pop", ("pedido", "em"): "typing:0.7", ("pedido", "em_enviar"): "ui:send",
    ("perguntas", "itens"): "ui:notification|mention|receive", ("fluxo", "passos"): "key", ("fluxo", "ok"): "ding+",
    ("fluxo", "selo"): "pop", ("terminal", "linhas"): "typing:0.8", ("versao", "selo"): "ding", ("frase", "em"): "hit",
    ("rosto", "punch"): "hit-", ("rosto", "sticker"): "pop",
}


def resolve(value, at):
    """Turns every 'em'/'em_*' anchor inside a scene's parameters into seconds."""
    if isinstance(value, dict):
        return {k: (at(v) if (k == "em" or k.startswith("em_")) and isinstance(v, (str, int, float)) else resolve(v, at))
                for k, v in value.items()}
    if isinstance(value, list):
        return [resolve(v, at) for v in value]
    return value


def sound_events(tipo, p):
    """Collects (time, sound) for every anchored moment of a resolved scene."""
    out = []
    for key, val in p.items():
        kind = SOUNDS.get((tipo, key))
        items = val if isinstance(val, list) else [val]
        for i, it in enumerate(items):
            t = it if isinstance(it, (int, float)) and key.startswith("em") else it.get("em") if isinstance(it, dict) else None
            if t is None or kind is None or (tipo == "fluxo" and key == "passos" and i == 0) or (tipo == "gancho" and i == 0):
                continue
            som = it.get("som") if isinstance(it, dict) and it.get("som") else kind
            if som == "nenhum":
                continue
            if "|" in som:  # rotate interface sounds so three bubbles do not sound the same
                head, names = som.split(":")
                som = f"{head}:{names.split('|')[i % len(names.split('|'))]}"
            out.append({"t": round(t, 3), "som": som, "rotulo": f"{tipo}.{key}"})
    return out


def build(root):
    proj, tl = load(root, "projeto.json"), load(root, "work/timeline.json")
    at, total = Anchors(tl), tl["total"]
    raw = load(root, "cenas.json")
    scenes = []
    for i, sc in enumerate(raw):
        if "trecho" in sc:
            t0 = at.segment_start(sc["trecho"])
        elif "inicio" in sc:
            t0 = at(sc["inicio"])
        else:
            raise ProjectError(f"cena {i + 1} ({sc.get('tipo')}) sem 'trecho' nem 'inicio'")
        scenes.append({"tipo": sc["tipo"], "modo": MODES.get(sc["tipo"], "S"), "t0": round(t0, 3), "p": resolve(sc.get("p", {}), at)})
    scenes[0]["t0"] = 0.0
    for a, b in zip(scenes, scenes[1:] + [None]):
        a["t1"] = b["t0"] if b else total
        if a["t1"] <= a["t0"]:
            raise ProjectError(f"cena {a['tipo']} em {a['t0']} termina antes de começar: confira a ordem do cenas.json")
        a["p"].update(t0=a["t0"], t1=a["t1"])
        if a["tipo"] == "tela":
            img = os.path.abspath(os.path.join(root, a["p"]["img"]))
            if not os.path.exists(img):
                raise ProjectError(f"tela: imagem {img} não existe (gere o screenshot antes)")
            a["p"]["img"] = "file:///" + quote(img.replace(os.sep, "/"))

    events = [{"t": s["t0"], "som": "whoosh", "rotulo": f"corte {s['tipo']}"} for s in scenes[1:]]
    for s in scenes:
        events += sound_events(s["tipo"], s["p"])
    punches = [s["p"]["punch"]["em"] for s in scenes if s["tipo"] == "rosto" and "punch" in s["p"]]
    stickers = []
    for s in scenes:
        st = s["p"].get("sticker")
        if s["tipo"] == "rosto" and st:
            stickers.append({"texto": st["texto"], "t0": st["em"], "t1": min(st["em"] + st.get("dur", 2.0), s["t1"]), "entrada": True})
    cta = proj["cta"]
    stickers.append({"texto": cta["texto"], "t0": at(cta["em"]), "t1": round(total - SEGUE_HOLD, 3), "entrada": True})
    events.append({"t": at(cta["em"]), "som": "pop", "rotulo": "cta"})
    dia, n = proj["dia"], proj.get("total_dias", 30)
    segue = proj.get("segue") or (f"Segue pro dia {dia + 1}" if dia < n else "Segue pra mais")
    stickers.append({"texto": segue, "t0": round(total - SEGUE_HOLD, 3), "t1": total + 1, "entrada": False})
    events.append({"t": round(total - SEGUE_HOLD, 3), "som": "ding", "rotulo": "segue"})
    for i, s in enumerate(stickers):
        s["png"] = f"sticker-{i:02d}-{norm(re.sub('<[^>]+>', '', s['texto']))[:24]}.png"
    mosaic = next((s for s in scenes if s["modo"] == "M"), None)
    if mosaic:
        events.append({"t": mosaic["t0"], "som": "whoosh", "rotulo": "mosaico"})
    resolved = {"total": total, "scenes": scenes, "punches": punches, "stickers": stickers,
                "events": sorted(events, key=lambda e: e["t"]), "face": proj.get("rosto", [540, 1030])}
    save(root, "work/cenas.json", resolved)
    return proj, tl, resolved


CAPTION_HTML = """<!doctype html><html><head><meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@800&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:1080px;height:1920px;background:transparent;overflow:hidden}
#cap{position:absolute;left:60px;right:60px;top:900px;text-align:center;white-space:nowrap;line-height:1;
font-family:'Inter',sans-serif;font-weight:800;font-size:66px;text-transform:uppercase;color:#F0F0E4;
-webkit-text-stroke:5px rgba(2,2,2,.6);paint-order:stroke fill;text-shadow:0 4px 18px rgba(0,0,0,.6)}
#cap .on{color:#C6FF34}#bl{display:inline-block;width:0;height:0}</style></head><body><div id="cap"></div></body></html>"""

CAPTION_JS = """([words, active]) => {
  const cap = document.getElementById('cap'); cap.textContent = ''; cap.style.top = '900px';
  words.forEach((w, k) => { if (k) cap.append(' '); const s = document.createElement('span'); s.textContent = w; if (k === active) s.className = 'on'; cap.append(s); });
  const bl = document.createElement('i'); bl.id = 'bl'; cap.append(bl);
  cap.style.top = (900 + 960 - bl.getBoundingClientRect().bottom) + 'px';
  const r = [...cap.querySelectorAll('span')].map(s => s.getBoundingClientRect());
  return {left: Math.min(...r.map(x => x.left)), right: Math.max(...r.map(x => x.right)), top: Math.min(...r.map(x => x.top)),
          bottom: Math.max(...r.map(x => x.bottom)), lines: new Set(r.map(x => Math.round(x.top))).size};
}"""


def render(root, proj, tl, res):
    work = os.path.join(root, "work")
    for d in ("painel", "legendas", "stickers"):
        os.makedirs(os.path.join(work, d), exist_ok=True)
        for f in os.listdir(os.path.join(work, d)):
            os.remove(os.path.join(work, d, f))
    dia, n = proj["dia"], proj.get("total_dias", 30)
    pj = {"dia": dia, "dia2": f"{dia:02d}", "total_dias": n, "serie": proj.get("serie", "SKILLS DO CLAUDE"),
          "titulo": proj["titulo_gancho"], "skill": proj["skill"], "tagline": proj["tagline"], "repo": proj["repo"],
          "estrelas": proj.get("estrelas", "")}
    assets = "file:///" + quote(os.path.join(SKILL, "assets").replace(os.sep, "/"))
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        pg = b.new_page(viewport={"width": 1080, "height": 960})
        pg.goto(assets + "/cenas.html", wait_until="networkidle")
        pg.evaluate("document.fonts.ready")
        imgs = [s["p"]["img"] for s in res["scenes"] if s["tipo"] == "tela"]
        pg.evaluate("u => preload(u)", imgs)
        pg.wait_for_timeout(300)
        for s in res["scenes"]:
            if s["modo"] != "S":
                continue
            # same rule the compositor uses: frame i belongs to the scene when t0 <= i/FPS < t1
            for i in range(math.ceil(s["t0"] * FPS - 1e-9), math.ceil(s["t1"] * FPS - 1e-9)):
                pg.evaluate("([a, t, p, j]) => render(a, t, p, j)", [s["tipo"], i / FPS, s["p"], pj])
                pg.screenshot(path=os.path.join(work, "painel", f"f{i:05d}.jpg"), type="jpeg", quality=93)
        cp = b.new_page(viewport={"width": 1080, "height": 1920})
        cp.set_content(CAPTION_HTML, wait_until="networkidle")
        cp.evaluate("document.fonts.ready")
        cp.wait_for_timeout(300)
        bad = []
        for i, c in enumerate(tl["captions"]):
            m = cp.evaluate(CAPTION_JS, [c["words"], c["active"]])
            c.update(png=f"cap-{i:03d}.png", **m)
            if m["lines"] > 1 or m["left"] < 60 or m["right"] > 1020:
                bad.append(" ".join(c["words"]))
            cp.screenshot(path=os.path.join(work, "legendas", c["png"]), omit_background=True)
        for s in res["stickers"]:
            cp.goto(assets + "/componentes.html?" + urlencode({"c": "cta", "cta": s["texto"]}, quote_via=quote), wait_until="networkidle")
            cp.evaluate("document.fonts.ready")
            cp.wait_for_timeout(300)
            cp.screenshot(path=os.path.join(work, "stickers", s["png"]), omit_background=True)
        b.close()
    save(root, "work/timeline.json", tl)
    if bad:
        raise ProjectError(f"legenda passa de uma linha ou da margem: {bad[:5]} (encurte com 'grafias' ou quebre o trecho)")
    print(f"{len(res['scenes'])} cenas, {sum(1 for s in res['scenes'] if s['modo'] == 'S')} em tela dividida, "
          f"{len(tl['captions'])} legendas, {len(res['stickers'])} stickers, {len(res['events'])} momentos de som")


def main(root):
    proj, tl, res = build(root)
    render(root, proj, tl, res)


if __name__ == "__main__":
    run_main(main)
