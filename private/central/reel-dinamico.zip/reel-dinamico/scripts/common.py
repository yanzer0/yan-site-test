"""Shared helpers for the reel-dinamico pipeline: project files, word anchors, easing."""
import json
import os
import re
import sys
import unicodedata

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FPS, WIDTH, HEIGHT = 30, 1080, 1920
SEAM = 960  # split-screen seam = caption baseline

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


class ProjectError(Exception):
    """A project file is missing or inconsistent; the message says what to fix."""


def project_dir(argv):
    if len(argv) < 2:
        raise ProjectError("uso: python scripts/<etapa>.py PASTA_DO_PROJETO")
    root = os.path.abspath(argv[1])
    if not os.path.exists(os.path.join(root, "projeto.json")):
        raise ProjectError(f"{root} não tem projeto.json (modelo em references/projeto.md)")
    os.makedirs(os.path.join(root, "work"), exist_ok=True)
    return root


def load(root, name):
    path = os.path.join(root, name) if not os.path.isabs(name) else name
    if not os.path.exists(path):
        raise ProjectError(f"falta {path}: rode a etapa anterior")
    return json.load(open(path, encoding="utf-8"))


def save(root, name, data):
    with open(os.path.join(root, name), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def norm(word):
    """Lower-case, no accents, no punctuation: the key a word anchor is matched on."""
    w = unicodedata.normalize("NFD", word.lower())
    return re.sub(r"[^a-z0-9-]", "", "".join(c for c in w if unicodedata.category(c) != "Mn"))


class Anchors:
    """Resolves 'palavra', 'palavra#2' or 'palavra#2+0.4' to a time on the edited timeline."""

    def __init__(self, timeline):
        self.words = [(norm(c["words"][c["active"]]), c["t_in"]) for c in timeline["captions"]]
        self.segments = {s["id"]: s for s in timeline["segments"]}

    def __call__(self, ref):
        if isinstance(ref, (int, float)):
            return float(ref)
        m = re.fullmatch(r"(.+?)(?:#(\d+))?([+-][\d.]+)?", ref.strip())
        if not m:
            raise ProjectError(f"âncora inválida: {ref!r}")
        key, n, off = norm(m.group(1)), int(m.group(2) or 1), float(m.group(3) or 0)
        hits = [t for w, t in self.words if w == key]
        if len(hits) < n:
            raise ProjectError(f"âncora {ref!r}: a palavra aparece {len(hits)} vez(es) na legenda")
        return round(hits[n - 1] + off, 3)

    def segment_start(self, seg_id):
        if seg_id not in self.segments:
            raise ProjectError(f"trecho {seg_id!r} não está entre os mantidos no projeto.json")
        return self.segments[seg_id]["out_in"]


def bezier(u, x1=.2, y1=.7, x2=.2, y2=1):
    """CSS cubic-bezier(.2,.7,.2,1): the one easing of the series."""
    if u <= 0:
        return 0.0
    if u >= 1:
        return 1.0
    t = u
    for _ in range(8):
        x = 3 * (1 - t) ** 2 * t * x1 + 3 * (1 - t) * t * t * x2 + t ** 3 - u
        dx = 3 * (1 - t) ** 2 * x1 + 6 * (1 - t) * t * (x2 - x1) + 3 * t * t * (1 - x2)
        if abs(dx) < 1e-6:
            break
        t -= x / dx
    return 3 * (1 - t) ** 2 * t * y1 + 3 * (1 - t) * t * t * y2 + t ** 3


def run_main(fn):
    try:
        fn(project_dir(sys.argv))
    except ProjectError as e:
        sys.exit(f"ERRO: {e}")
