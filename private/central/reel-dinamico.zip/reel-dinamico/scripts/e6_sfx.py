"""Etapa 6: SFX real. Biblioteca CC0 (Openverse/Freesound) baixada uma vez, cada som classificado pelo earshot
(nome de arquivo mente), um cue por momento da cena, mix pela real-sfx com a voz protegida, críticas das duas ferramentas.
Saídas: <saida>.mp4 final (-14 LUFS), work/sfx/ (relatório, faixa só de SFX, cues resolvidos)."""
import itertools
import json
import os
import re
import subprocess
import time
import urllib.parse
import urllib.request

from common import ProjectError, load, run_main, save

HOME = os.path.join(os.path.expanduser("~"), ".reel-dinamico")
LIB = os.environ.get("REEL_SFX_LIB", os.path.join(HOME, "sfx-lib"))
REAL_SFX = os.environ.get("REAL_SFX_DIR", os.path.join(HOME, "real-sfx"))
EARSHOT_PY = os.environ.get("EARSHOT_PYTHON", os.path.join(HOME, "earshot", ".venv", "Scripts", "python.exe"))

QUERIES = {"whoosh": (["whoosh", "swoosh", "swish transition"], 1600), "pop": (["pop", "bubble pop", "cork pop"], 700),
           "typing": (["keyboard typing", "mechanical keyboard typing"], 12000), "click": (["mouse click", "button click"], 600),
           "hit": (["cinematic impact", "punch hit", "boom impact"], 2500), "riser": (["riser", "whoosh riser"], 4000),
           "ding": (["ding", "notification bell", "success chime"], 2000), "paper": (["paper slide", "card flip"], 1200)}
# earshot's first reading -> what the file really is
KINDS = [("whoosh", r"whoosh|swoosh|swish|swung"), ("hit", r"impact|thud|kick drum|boom"), ("pop", r"\bpop\b|bloop"),
         ("ding", r"chime|ding|ting|triangle|bell"), ("typing", r"typing"), ("key", r"key press|key release|enter key|mouse click|latch|switch")]
ROLE = {"whoosh": "whoosh", "hit": "hit", "pop": "pop", "ding": "chime", "typing": "keys", "key": "click"}
# sound name used in work/cenas.json -> (kind, gain dB, extra cue fields)
RECIPE = {"whoosh": ("whoosh", -5, {"max_dur": 0.8}), "pop": ("pop", -3, {}), "key": ("key", -3, {}), "ding": ("ding", -5, {}),
          "ding+": ("ding", 3, {}), "hit": ("hit", -3, {"max_dur": 0.8, "highpass": 150}),
          "hit-": ("hit", -6, {"max_dur": 0.7, "highpass": 150})}
UA = {"User-Agent": "infuser-reel-dinamico/1.0 (personal video edit)"}


def fetch_library():
    """Downloads ~60 CC0 sounds once (Openverse anonymous limit: 20 requests/min, 200/day)."""
    manifest = []
    for role, (terms, max_ms) in QUERIES.items():
        os.makedirs(os.path.join(LIB, role), exist_ok=True)
        got = 0
        for term in terms:
            url = "https://api.openverse.org/v1/audio/?" + urllib.parse.urlencode({"q": term, "license": "cc0", "page_size": 20})
            data = json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30).read())
            time.sleep(3.2)
            for r in data["results"]:
                d = r.get("duration") or 0
                if got >= 8 or not (80 <= d <= max_ms) or r.get("license") != "cc0":
                    continue
                name = f"{role}/{role}-{got:02d}-{r['id'][:8]}.mp3"
                try:
                    data_ = urllib.request.urlopen(urllib.request.Request(r["url"], headers=UA), timeout=30).read()
                except OSError as e:
                    print("pulei", r["url"], e)
                    continue
                open(os.path.join(LIB, name), "wb").write(data_)
                manifest.append({"file": name, "title": r["title"], "creator": r.get("creator"), "license": "CC0 1.0",
                                 "source": r.get("foreign_landing_url")})
                got += 1
            if got >= 8:
                break
    json.dump(manifest, open(os.path.join(LIB, "manifest.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def classify():
    """earshot describes every file once; the reading is cached in classified.json."""
    cache_path = os.path.join(LIB, "classified.json")
    cache = json.load(open(cache_path, encoding="utf-8")) if os.path.exists(cache_path) else {}
    for entry in json.load(open(os.path.join(LIB, "manifest.json"), encoding="utf-8")):
        f = entry["file"]
        if f in cache:
            continue
        out = subprocess.run([EARSHOT_PY, "-m", "earshot", "describe", os.path.join(LIB, f)], capture_output=True, text=True,
                             encoding="utf-8", errors="replace").stdout
        m, d = re.search(r"Sounds most like: ([^\[]*)", out), re.match(r"\s*([\d.]+) s", out)
        first = m.group(1).split(",")[0] if m else ""
        kind = next((k for k, rx in KINDS if re.search(rx, first)), None)
        cache[f] = {"kind": kind, "dur": float(d.group(1)) if d else None, "reading": m.group(1).strip() if m else ""}
        json.dump(cache, open(cache_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"{f:40s} -> {kind}  ({first.strip()})")
    return cache


def build_cues(root, cache):
    res = load(root, "work/cenas.json")
    pool = {}
    for f, c in sorted(cache.items(), key=lambda x: x[1]["dur"] or 9):
        kind = c["kind"]
        if f.startswith("typing/") and (c["dur"] or 0) > 1.5 and re.search("key|typ", c["reading"]):
            kind = "typing"  # a long keyboard run reads as "key press" to earshot; it is still typing
        if kind:
            pool.setdefault(kind, []).append(f)
    missing = [k for k in ("whoosh", "pop", "ding", "hit", "typing", "key") if k not in pool]
    if missing:
        raise ProjectError(f"a biblioteca não tem som de {missing}: rode de novo com REEL_SFX_REFETCH=1 ou acrescente termos em QUERIES")
    cycle, used = {k: itertools.cycle(v) for k, v in pool.items()}, {}

    def lib(kind):
        for _ in range(40):  # each recording at most twice in one film
            f = next(cycle[kind])
            if used.get(f, 0) < 2:
                break
        used[f] = used.get(f, 0) + 1
        return os.path.join(LIB, f).replace(os.sep, "/")

    cues = []
    for e in res["events"]:
        som, t = e["som"], e["t"]
        base = {"t": t, "label": e["rotulo"]}
        if som.startswith("ui:"):
            cues.append({**base, "uisfx": som[3:], "pack": "studio", "gain_db": -4})
        elif som.startswith("typing:"):
            cues.append({**base, "file": lib("typing"), "role": "keys", "gain_db": -8, "max_dur": float(som[7:]), "anchor": "start"})
        elif som == "pop2":
            cues += [{**base, "t": round(t + dt, 3), "file": lib("pop"), "role": "pop", "gain_db": -6} for dt in (0, .28)]
        elif som in RECIPE:
            kind, gain, extra = RECIPE[som]
            cues.append({**base, "file": lib(kind), "role": ROLE[kind], "gain_db": gain, **extra})
        else:
            raise ProjectError(f"som desconhecido {som!r} em {e['rotulo']} (veja references/sfx.md)")
    sheet = {"video": os.path.join(root, "work", "imagem.mov").replace(os.sep, "/"), "keep_audio": "yes",
             "cues": sorted(cues, key=lambda c: c["t"])}
    save(root, "work/cues.json", sheet)
    return len(cues)


def main(root):
    proj = load(root, "projeto.json")
    for path, what in ((REAL_SFX, "real-sfx (REAL_SFX_DIR)"), (EARSHOT_PY, "earshot (EARSHOT_PYTHON)")):
        if not os.path.exists(path):
            raise ProjectError(f"{what} não encontrado em {path}: veja references/setup.md")
    if os.environ.get("REEL_SFX_REFETCH") or not os.path.exists(os.path.join(LIB, "manifest.json")):
        fetch_library()
    n = build_cues(root, classify())
    out_dir = os.path.join(root, "work", "sfx")
    os.makedirs(out_dir, exist_ok=True)
    mixed = os.path.join(out_dir, "final_sfx.mp4")
    env = {**os.environ, "PYTHONUTF8": "1"}
    py = "python"
    subprocess.run([py, "scripts/mix.py", os.path.join(root, "work", "cues.json"), "--out", mixed, "--voice-safe", "--target-lufs", "-14"],
                   cwd=REAL_SFX, env=env, check=True)
    resolved, track = mixed.replace(".mp4", "_resolved_cues.json"), mixed.replace(".mp4", "_sfx_track.wav")
    crit = subprocess.run([py, "scripts/critique.py", resolved, track], cwd=REAL_SFX, env=env, capture_output=True, text=True).stdout
    ears = subprocess.run([EARSHOT_PY, "-m", "earshot", "critique", mixed], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    open(os.path.join(out_dir, "criticas.txt"), "w", encoding="utf-8").write(crit + "\n\n=== earshot ===\n" + ears)
    name = proj.get("saida", "final")
    final = os.path.join(root, name + ".mp4")
    os.replace(mixed, final)
    os.replace(os.path.join(root, "work", "capa.png"), os.path.join(root, f"capa-{name}.png"))
    print(f"{n} cues; final em {final}")
    print("\n".join(l for l in crit.splitlines() if l.startswith("| ") or l.startswith("**FIX")))
    print("\n".join(l for l in ears.splitlines() if "[critical]" in l or "[major]" in l or l.startswith("VERDICT")))


if __name__ == "__main__":
    run_main(main)
