"""Etapa 5: monta a imagem. Tela dividida (painel em cima, rosto embaixo), rosto cheio com punch-in, mosaico de fecho,
stickers e legenda. Saídas: work/imagem.mov (com a voz) e work/capa.png (quadro do gancho, sem legenda)."""
import os
import subprocess

import cv2
import numpy as np
from PIL import Image

from common import FPS, HEIGHT, SEAM, WIDTH, bezier, load, run_main

ENTER, PUNCH_Z, FACE_ZOOM, SPLIT_ZOOM = 0.32, 1.07, 1.40, (1.10, 1.16)
COVER_T = 1.2


def crop_zoom(img, cx, cy, z, out_w, out_h):
    """Crops around (cx, cy) at zoom z (1 = full width) into out_w x out_h."""
    w = WIDTH / z
    h = w * out_h / out_w
    x0 = min(max(cx - w / 2, 0), WIDTH - w)
    y0 = min(max(cy - h / 2, 0), HEIGHT - h)
    m = np.float32([[out_w / w, 0, -x0 * out_w / w], [0, out_h / h, -y0 * out_h / h]])
    return cv2.warpAffine(img, m, (out_w, out_h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


class Layer:
    """RGBA overlay cropped to its visible box."""

    def __init__(self, path):
        im = np.asarray(Image.open(path).convert("RGBA")).astype(np.float32)
        ys, xs = np.nonzero(im[:, :, 3])
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        self.rgb, self.a, self.x, self.y = im[y0:y1, x0:x1, :3], im[y0:y1, x0:x1, 3:] / 255.0, x0, y0

    def draw(self, dst, op=1.0, dy=0):
        if op <= 0:
            return
        y = int(round(self.y + dy))
        h, w = self.a.shape[:2]
        a = self.a * op
        r = dst[y:y + h, self.x:self.x + w]
        r[:] = self.rgb * a + r * (1 - a)


class Composer:
    def __init__(self, root, captions=True):
        self.root, self.work = root, os.path.join(root, "work")
        self.res, tl = load(root, "work/cenas.json"), load(root, "work/timeline.json")
        self.total = self.res["total"]
        self.fx, self.fy = self.res["face"]
        self.caps = tl["captions"] if captions else []
        self.cap_layers, self.snapshots = {}, {}
        self.stickers = [(s, Layer(os.path.join(self.work, "stickers", s["png"]))) for s in self.res["stickers"]]

    def scene(self, t):
        for k, s in enumerate(self.res["scenes"]):
            if s["t0"] <= t < s["t1"]:
                return k, s
        return len(self.res["scenes"]) - 1, self.res["scenes"][-1]

    def punch(self, t, s):
        for p in self.res["punches"]:
            if s["t0"] <= p <= t < s["t1"]:
                return 1 + (PUNCH_Z - 1) * bezier((t - p) / .2)
        return 1.0

    def frame(self, f, i):
        t = i / FPS
        k, s = self.scene(t)
        f = f.astype(np.float32)
        u = (t - s["t0"]) / max(s["t1"] - s["t0"], 1e-3)
        mid = abs(t - (s["t0"] + s["t1"]) / 2) < .5 / FPS
        if s["modo"] == "S":
            img = np.empty((HEIGHT, WIDTH, 3), np.float32)
            panel = cv2.imread(os.path.join(self.work, "painel", f"f{i:05d}.jpg"))
            img[:SEAM] = cv2.cvtColor(panel, cv2.COLOR_BGR2RGB)
            img[SEAM:] = crop_zoom(f, self.fx, self.fy + 30, SPLIT_ZOOM[0] + (SPLIT_ZOOM[1] - SPLIT_ZOOM[0]) * u, WIDTH, HEIGHT - SEAM)
        elif s["modo"] == "F":  # face centre lands at y 700; small settle on every cut, punch on the impact word
            z = FACE_ZOOM * self.punch(t, s) * (1 + .04 * (1 - bezier((t - s["t0"]) / .3)))
            img = crop_zoom(f, self.fx, self.fy + (HEIGHT / 2 - 700) / FACE_ZOOM, z, WIDTH, HEIGHT)
        else:  # mosaic: every scene as a tile, the live face in the centre 2x2, pulling back
            tiles = [self.snapshots[j] for j in sorted(self.snapshots)]
            img = np.full((HEIGHT, WIDTH, 3), 2, np.float32)
            slots = [(c, r) for r in range(4) for c in range(4) if not (c in (1, 2) and r in (1, 2))]
            for n, (c, r) in enumerate(slots):
                if tiles:
                    img[r * 480:(r + 1) * 480, c * 270:(c + 1) * 270] = tiles[n % len(tiles)]
            img[480:1440, 270:810] = crop_zoom(f, self.fx, self.fy + 30, 1.25, 540, 960)
            img[480:1440, 268:272] = img[480:1440, 808:812] = 2
            img[478:482, 270:810] = img[1438:1442, 270:810] = 2
            img = crop_zoom(img, 540, 960, 1 + .9 * (1 - bezier((t - s["t0"]) / .7)), WIDTH, HEIGHT)
        if mid and s["modo"] != "M":
            self.snapshots[k] = cv2.resize(img, (270, 480), interpolation=cv2.INTER_AREA)
        for st, lay in self.stickers:
            if st["t0"] <= t < st["t1"]:
                p = bezier((t - st["t0"]) / ENTER) if st["entrada"] else 1.0
                lay.draw(img, p, 40 * (1 - p))
        for c in self.caps:
            if c["t_in"] <= t < c["t_out"]:
                if c["png"] not in self.cap_layers:
                    self.cap_layers[c["png"]] = Layer(os.path.join(self.work, "legendas", c["png"]))
                self.cap_layers[c["png"]].draw(img)
                break
        return np.clip(img, 0, 255).astype(np.uint8)


def frames(work):
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-i", os.path.join(work, "base_video.mp4"), "-vf",
                          "scale=in_color_matrix=bt709:in_range=tv", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    n = WIDTH * HEIGHT * 3
    while True:
        b = p.stdout.read(n)
        if len(b) < n:
            p.stdout.close()
            return
        yield np.frombuffer(b, np.uint8).reshape(HEIGHT, WIDTH, 3)


def main(root):
    work = os.path.join(root, "work")
    comp, cover = Composer(root), Composer(root, captions=False)
    nframes = int(round(comp.total * FPS))
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{WIDTH}x{HEIGHT}",
                            "-r", str(FPS), "-i", "-", "-i", os.path.join(work, "base_audio.wav"), "-map", "0:v", "-map", "1:a",
                            "-vf", "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p", "-c:v", "libx264", "-crf", "18",
                            "-preset", "slow", "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
                            "-c:a", "pcm_s16le", "-t", f"{nframes / FPS:.3f}", os.path.join(work, "imagem.mov")], stdin=subprocess.PIPE)
    last, i = None, -1
    for i, f in enumerate(frames(work)):
        if i >= nframes:
            break
        enc.stdin.write(comp.frame(f, i).tobytes())
        if i == int(round(COVER_T * FPS)):
            Image.fromarray(cover.frame(f, i)).save(os.path.join(work, "capa.png"))
        last = f
    for j in range(i + 1, nframes):
        enc.stdin.write(comp.frame(last, j).tobytes())
    enc.stdin.close()
    enc.wait()
    print(f"imagem pronta: {nframes} quadros, capa em work/capa.png")


if __name__ == "__main__":
    run_main(main)
