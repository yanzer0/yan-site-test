"""Etapa 3: aplica os cortes no bruto, converte HDR (HLG/PQ do iPhone) para SDR bt709 e normaliza a voz em -14 LUFS."""
import json
import os
import subprocess

from common import load, run_main

FADE = 0.012  # tiny audio fades so a cut never clicks


def is_hdr(video):
    info = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer",
                           "-of", "csv=p=0", video], capture_output=True, text=True, check=True).stdout.strip().strip(",")
    return info in ("arib-std-b67", "smpte2084")


def main(root):
    proj, tl = load(root, "projeto.json"), load(root, "work/timeline.json")
    work = os.path.join(root, "work")
    v, a = [], []
    for i, s in enumerate(tl["segments"]):
        d = s["src_out"] - s["src_in"]
        v.append(f"[0:v]trim=start={s['src_in']}:end={s['src_out']},setpts=PTS-STARTPTS[v{i}]")
        a.append(f"[0:a]atrim=start={s['src_in']}:end={s['src_out']},asetpts=PTS-STARTPTS,"
                 f"afade=t=in:d={FADE},afade=t=out:st={d - FADE:.3f}:d={FADE}[a{i}]")
    n = len(tl["segments"])
    fc = ";".join(v + a)
    fc += ";" + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[vc]"
    fc += ";" + "".join(f"[a{i}]" for i in range(n)) + f"concat=n={n}:v=0:a=1[ac]"
    if is_hdr(proj["video"]):
        fc += (";[vc]zscale=w=1080:h=1920:f=spline36:t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,"
               "tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,fps=30[vout]")
    else:
        fc += ";[vc]scale=1080:1920:flags=lanczos,format=yuv420p,fps=30[vout]"
    raw = os.path.join(work, "base_audio_raw.wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", proj["video"], "-filter_complex", fc,
                    "-map", "[vout]", "-c:v", "libx264", "-crf", "10", "-preset", "veryfast",
                    "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709", os.path.join(work, "base_video.mp4"),
                    "-map", "[ac]", "-ar", "48000", "-c:a", "pcm_s16le", raw], check=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", raw, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json",
                        "-f", "null", "-"], capture_output=True, text=True)
    m = json.loads(r.stderr[r.stderr.rindex("{"):r.stderr.rindex("}") + 1])
    af = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}"
          f":measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true,aresample=48000")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-af", af, "-c:a", "pcm_s16le", os.path.join(work, "base_audio.wav")], check=True)
    print(f"base pronta: {tl['total']:.2f} s, HDR convertido: {is_hdr(proj['video'])}, voz medida {m['input_i']} LUFS -> -14")


if __name__ == "__main__":
    run_main(main)
