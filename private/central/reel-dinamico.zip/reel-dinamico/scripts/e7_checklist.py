"""Etapa 7: checklist em quadros exportados (1 por segundo) e nos dados do render. Grava work/checklist.md e as folhas de contato."""
import json
import os
import re
import subprocess

from PIL import Image

from common import load, run_main

CUT_EVERY_MAX = 3.5   # longest a split-screen scene may stay (references measured ~2.3 s per scene)


def main(root):
    proj, tl, res = load(root, "projeto.json"), load(root, "work/timeline.json"), load(root, "work/cenas.json")
    name = proj.get("saida", "final")
    final = os.path.join(root, name + ".mp4")
    fr = os.path.join(root, "work", "checagem")
    os.makedirs(fr, exist_ok=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", final, "-vf", "fps=1", os.path.join(fr, "f%02d.png")], check=True)
    frames = sorted(f for f in os.listdir(fr) if f.startswith("f"))
    for k in range(0, len(frames), 12):
        sheet = Image.new("RGB", (270 * 6, 480 * 2), (40, 40, 40))
        for i, f in enumerate(frames[k:k + 12]):
            sheet.paste(Image.open(os.path.join(fr, f)).resize((270, 480)), ((i % 6) * 270, (i // 6) * 480))
        sheet.save(os.path.join(root, "work", f"folha-{k // 12 + 1}.png"))
    rows = []

    def check(item, ok, detail):
        rows.append(f"| {'OK' if ok else 'FALHA'} | {item} | {detail} |")

    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", final],
                               capture_output=True, text=True).stdout)
    check("Duração 38 a 52 s", 38 <= dur <= 52, f"{dur:.2f} s")
    eb = subprocess.run(["ffmpeg", "-hide_banner", "-i", final, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    lufs, peak = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", eb)[-1]), float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", eb)[-1])
    check("-14 LUFS, sem estourar", abs(lufs + 14) <= 1 and peak < -1, f"{lufs} LUFS, pico {peak} dBTP")
    caps = tl["captions"]
    bad = [c for c in caps if c.get("lines", 1) != 1 or c.get("left", 60) < 60 or c.get("right", 1020) > 1020]
    check("Legenda numa linha, base na emenda (y 960)", not bad, f"{len(caps)} estados, {len(bad)} fora")
    long_s = [(s["tipo"], round(s["t1"] - s["t0"], 1)) for s in res["scenes"] if s["modo"] == "S" and s["t1"] - s["t0"] > CUT_EVERY_MAX + 1.8]
    check("Ritmo: nenhuma cena parada demais", not long_s, f"{len(res['scenes'])} cenas em {res['total']:.1f} s; longas: {long_s or 'nenhuma'}")
    check("Abre em tela dividida com o título", res["scenes"][0]["tipo"] == "gancho", res["scenes"][0]["tipo"])
    check("Fecha com mosaico e 'Segue pro dia'", res["scenes"][-1]["modo"] == "M", res["stickers"][-1]["texto"])
    texts = json.dumps(load(root, "cenas.json"), ensure_ascii=False) + " ".join(" ".join(c["words"]) for c in caps)
    found = set(re.findall("[\u2014\u2013\U0001F300-\U0001FAFF]", texts))
    check("Sem travessão longo nem emoji", not found, str(found or "nenhum"))
    crit = open(os.path.join(root, "work", "sfx", "criticas.txt"), encoding="utf-8").read()
    axes = dict(re.findall(r"^\| (\w+) \| ([\d.]+|n/a) \|", crit, re.M))
    weak = {k: v for k, v in axes.items() if v != "n/a" and float(v) < 8 and k != "balance"}
    check("SFX: eixos da real-sfx >= 8 (balance fica de fora, SFX abaixo da voz é de propósito)", not weak, str(axes))
    report = "| | Item | Detalhe |\n|---|---|---|\n" + "\n".join(rows)
    open(os.path.join(root, "work", "checklist.md"), "w", encoding="utf-8").write(report + "\n")
    print(report)
    print("\nOlhe as folhas work/folha-*.png antes de entregar: rosto, legenda e painel em cada segundo.")


if __name__ == "__main__":
    run_main(main)
