"""Roda o pipeline inteiro (ou a partir de uma etapa): python scripts/reel.py PASTA [--de 2]

Etapa 1 para sozinha: depois dela alguém precisa ler work/ilhas.json e escrever "manter" no projeto.json."""
import argparse
import os
import subprocess
import sys

STEPS = ["e1_transcrever", "e2_plano", "e3_base", "e4_graficos", "e5_compor", "e6_sfx", "e7_checklist"]
HERE = os.path.dirname(os.path.abspath(__file__))

ap = argparse.ArgumentParser()
ap.add_argument("pasta")
ap.add_argument("--de", type=int, default=2, help="etapa inicial (1 a 7); padrão 2, porque a 1 pede decisão de cortes")
ap.add_argument("--ate", type=int, default=7)
a = ap.parse_args()
for n in range(a.de, a.ate + 1):
    print(f"\n=== etapa {n}: {STEPS[n - 1]} ===", flush=True)
    r = subprocess.run([sys.executable, "-X", "utf8", os.path.join(HERE, STEPS[n - 1] + ".py"), a.pasta])
    if r.returncode:
        sys.exit(f"parou na etapa {n} ({STEPS[n - 1]})")
    if n == 1:
        sys.exit("etapa 1 pronta: escreva \"manter\" no projeto.json e rode com --de 2")
