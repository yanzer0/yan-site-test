"""Etapa 1: acha as ilhas de fala do bruto e transcreve CADA UMA SOZINHA, com tempo por palavra (GPU).

Transcrever ilha por ilha é o que expõe tropeço: rodando o vídeo inteiro, o whisper cola o take ruim no bom
("ele faz a... ele te faz as perguntas") e o tropeço some da transcrição. Saída: work/ilhas.json + tabela no terminal.
"""
import os
import re
import subprocess

from common import load, run_main, save

PAD = 0.08            # audio kept around each island when transcribing it
SILENCE_DB, SILENCE_S = -38, 0.25


def islands(wav):
    log = subprocess.run(["ffmpeg", "-hide_banner", "-i", wav, "-af", f"silencedetect=noise={SILENCE_DB}dB:d={SILENCE_S}",
                          "-f", "null", "-"], capture_output=True, text=True).stderr
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", wav],
                               capture_output=True, text=True, check=True).stdout)
    edges, cursor = [], 0.0
    for s, e in zip(starts, ends + [dur]):
        if s - cursor > 0.12:
            edges.append((round(cursor, 3), round(s, 3)))
        cursor = e
    if dur - cursor > 0.12:
        edges.append((round(cursor, 3), round(dur, 3)))
    return edges


def main(root):
    proj = load(root, "projeto.json")
    work = os.path.join(root, "work")
    wav = os.path.join(work, "audio16k.wav")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", proj["video"], "-vn", "-ar", "16000", "-ac", "1", wav], check=True)
    from faster_whisper import WhisperModel
    model = WhisperModel("large-v3", device="cuda", compute_type="float16")
    out = []
    for n, (a, b) in enumerate(islands(wav), 1):
        clip = os.path.join(work, "_ilha.wav")
        sa = max(0.0, a - PAD)
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", str(sa), "-to", str(b + PAD), "-i", wav, clip], check=True)
        segs, _ = model.transcribe(clip, language="pt", word_timestamps=True, vad_filter=False, beam_size=5,
                                   condition_on_previous_text=False, no_repeat_ngram_size=3, repetition_penalty=1.15)
        words = [{"w": w.word.strip(), "s": round(w.start + sa, 3), "e": round(w.end + sa, 3)} for s in segs for w in s.words]
        out.append({"id": f"i{n:02d}", "start": a, "end": b, "text": " ".join(w["w"] for w in words), "words": words})
        print(f"i{n:02d} {a:7.2f}-{b:7.2f}  {out[-1]['text'] or '(sem fala)'}")
    os.remove(clip)
    save(root, "work/ilhas.json", out)
    print("\nPróximo: compare com o roteiro e escreva em projeto.json -> \"manter\": [ids na ordem]. Tropeço, take repetido"
          " (fica o ÚLTIMO), comentário fora do roteiro e ilha sem fala ficam de fora.")


if __name__ == "__main__":
    run_main(main)
