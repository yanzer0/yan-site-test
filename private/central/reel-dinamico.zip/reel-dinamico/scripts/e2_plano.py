"""Etapa 2: corta (ilhas mantidas + respiro de 0,12 s), monta a linha do tempo e os blocos de legenda (1 a 3 palavras)."""
from common import load, norm, run_main, save

PRE, POST, TAIL = 0.06, 0.06, 0.60   # 0.12 s breath at every join; the last word holds 0.6 s for "Segue pro dia N"
MAX_LETTERS = 19                      # longest caption block that fits one line at Inter 800 66 px


def apply_spelling(words, rules):
    """Fixes names the transcription misses: [["cloud", "Claude"], ["skill creator", "skill-creator"], ["a criadora", "CRIADOR"]]."""
    out, i = [], 0
    parsed = [([norm(x) for x in de.split()], para) for de, para in rules]
    while i < len(words):
        for keys, para in parsed:
            span = words[i:i + len(keys)]
            if len(span) == len(keys) and [norm(w["w"]) for w in span] == keys:
                tail = span[-1]["w"][len(span[-1]["w"].rstrip(",.?!")):]
                out.append({"w": para + tail, "s": span[0]["s"], "e": span[-1]["e"]})
                i += len(keys)
                break
        else:
            out.append(words[i])
            i += 1
    return out


def main(root):
    proj = load(root, "projeto.json")
    ilhas = {x["id"]: x for x in load(root, "work/ilhas.json")}
    keep = proj.get("manter") or []
    if not keep:
        raise SystemExit("ERRO: projeto.json sem \"manter\": leia work/ilhas.json e liste as ilhas que ficam")
    segs, cw, t = [], [], 0.0
    for n, k in enumerate(keep):
        isl = ilhas[k["id"] if isinstance(k, dict) else k]
        a = (k.get("inicio") if isinstance(k, dict) else None) or isl["start"]
        b = (k.get("fim") if isinstance(k, dict) else None) or isl["end"]
        sa, sb = a - PRE, b + (TAIL if n == len(keep) - 1 else POST)
        seg = {"id": isl["id"], "src_in": round(sa, 3), "src_out": round(sb, 3), "out_in": round(t, 3), "out_out": round(t + sb - sa, 3)}
        words = [w for w in isl["words"] if w["e"] > sa + 0.03 and w["s"] < sb - 0.03]
        words = apply_spelling(words, proj.get("grafias", []))
        if words:  # whisper stamps a phrase's first word late; the speech starts where the island starts
            words[0] = {**words[0], "s": min(words[0]["s"], a)}
        for w in words:
            cw.append({"w": w["w"], "s": round(seg["out_in"] + max(w["s"], sa) - sa, 3),
                       "e": round(seg["out_in"] + min(w["e"], sb) - sa, 3), "seg": seg["id"]})
        seg["text"] = " ".join(w["w"] for w in words)
        segs.append(seg)
        t += sb - sa
    total = round(t, 3)

    groups, cur = [], []
    for i, w in enumerate(cw):
        cur.append(w)
        nxt = cw[i + 1] if i + 1 < len(cw) else None
        letters = sum(len(x["w"]) + 1 for x in cur)
        if (nxt is None or len(cur) == 3 or nxt["seg"] != w["seg"] or w["w"][-1] in ",.?!"
                or nxt["s"] - w["e"] > 0.30 or letters + len(nxt["w"]) > MAX_LETTERS):
            groups.append(cur)
            cur = []
    caps = []
    for gi, g in enumerate(groups):
        end = groups[gi + 1][0]["s"] if gi + 1 < len(groups) else total
        end = min(end, g[-1]["e"] + 0.35)
        for k, w in enumerate(g):
            caps.append({"words": [x["w"] for x in g], "active": k, "t_in": w["s"],
                         "t_out": round(g[k + 1]["s"] if k + 1 < len(g) else end, 3)})
    save(root, "work/timeline.json", {"total": total, "segments": segs, "captions": caps})
    for s in segs:
        print(f"{s['id']} {s['out_in']:6.2f}-{s['out_out']:6.2f}  {s['text']}")
    print(f"\ntotal {total:.2f} s (meta 38 a 52), {len(groups)} blocos de legenda")


if __name__ == "__main__":
    run_main(main)
