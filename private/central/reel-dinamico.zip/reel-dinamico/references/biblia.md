# Bíblia visual (identidade Infuser v2, igual em todos os vídeos)

- **Cores**: Onyx #020202, Carbon #171717, Warm White #F0F0E4, Lime #C6FF34 (destaque), Teal #3BD0A0 /
  #2FA084 (apoio, links, passado), cinzas #C7CAC2 / #9A9D95. Sem roxo, azul, gradiente colorido, sombra colorida.
- **Fontes**: Inter 800/900 (títulos, legenda), Onest 500/600 (apoio), Geist Mono 500/700 (comandos, números,
  rótulos). Google Fonts.
- **Proibido**: emoji, travessão longo, meme ou trecho de filme, música no arquivo (o Yan escolhe no app),
  transição de giro ou zoom estourado.

## Quadro
| faixa (y) | modo S (tela dividida) | modo F (rosto cheio) |
|---|---|---|
| 0 a 220 | painel, só fundo (interface do IG cobre) | rosto |
| 230 a 930 | conteúdo do painel | rosto |
| 960 | emenda = linha de base da legenda | legenda |
| 960 a 1920 | rosto (zoom lento) | rosto; sticker no topo (y 250) |

- **Legenda**: Inter 800, 66 px, CAIXA ALTA, Warm White, contorno 5 px #020202 a 60%, sombra 0 4 18
  rgba(0,0,0,.6); 1 a 3 palavras; a palavra falada em Lime; base em y 960; nunca duas linhas.
- **Movimento**: entrada 320 ms (sobe 40 px + opacidade, cubic-bezier .2,.7,.2,1); pop de elemento 260 ms;
  só posição, escala leve e opacidade. Corte seco entre cenas, com whoosh.
- **Ritmo** (medido nas referências): cena nova a cada ~2 a 2,5 s; dentro da cena, um elemento novo a cada 0,5
  a 1 s; rosto cheio em 3 a 5 momentos; mosaico no fecho com "Segue pro dia N".
- **Painel**: fundo Carbon com vinheta escura; cartões `.glass`; Lime no destaque de cada cena; ilustrativo
  leva "exemplo" (Geist Mono 22 px, canto).
- **Capa**: quadro do gancho em 1,2 s, sem legenda.
