# SFX

Som real, nunca sintetizado (regra da real-sfx), com uma exceção: momentos de interface (balão de chat,
enviar, colar, notificação) usam o uisfx, pacote CC0 de sons de UI que vem dentro da real-sfx.

## Biblioteca
`~/.reel-dinamico/sfx-lib` (ou `REEL_SFX_LIB`). Na primeira execução a etapa 6 baixa ~60 sons CC0 do
Openverse (Freesound), 8 por papel: whoosh, pop, digitação, clique, impacto, riser, sino, papel. Sem chave
(limite anônimo 20 req/min, 200/dia). `manifest.json` guarda autor e link de cada som. `REEL_SFX_REFETCH=1`
baixa de novo.

## Classificação
O earshot descreve cada arquivo uma vez (`classified.json`, cache). O tipo vem da 1ª leitura dele, não do nome
do arquivo (num lote, um "click" era estalo de boca e outro era sino de sucesso). Digitação longa que o earshot
lê como "key press" continua digitação.

## Sons (`"som"` no cenas.json)
| valor | o que toca |
|---|---|
| `whoosh` | whoosh curto (corte de cena, padrão) |
| `pop`, `pop2` | pop; `pop2` = dois pops com 0,28 s |
| `key` | tecla / clique |
| `ding`, `ding+` | sino; `ding+` 8 dB mais alto (gravação fina) |
| `hit`, `hit-` | impacto com highpass 150 Hz; `hit-` mais baixo (punch do rosto) |
| `typing:1.1` | digitação, duração em segundos, ancorada no começo |
| `nenhum` | momento sem som (ex.: punch de rosto que não pede impacto; deixe impacto só em 2 ou 3 viradas) |
| `ui:<nome>` | uisfx pack studio: `paste`, `copy`, `send`, `receive`, `drop`, `notification`, `mention`, `success`... |

## Mix e críticas
`real-sfx/scripts/mix.py --voice-safe --target-lufs -14`: SFX abaixo da voz quando ela fala, final em -14 LUFS.
Depois, `critique.py` (real-sfx) e `earshot critique`. Metas: todos os eixos da real-sfx em 8 ou mais, exceto
`balance` (SFX ~9 dB abaixo da voz é a escolha). Do earshot, ignore "sem música" (o Yan põe no app) e
"salient hits demais" (vem da fala). O resto se corrige no `cenas.json` (`som`) ou nos `RECIPE` da etapa 6.

Ninguém aqui ouve: a crítica lista 3 a 4 momentos para o Yan ouvir no celular. Repasse a lista.
