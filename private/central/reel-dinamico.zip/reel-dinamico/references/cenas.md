# Catálogo de cenas (`cenas.json`)

Lista em ordem. Cada cena começa num trecho mantido (`"trecho": "i07"`) ou numa palavra (`"inicio": "marca"`)
e termina onde a próxima começa. A primeira começa em 0. Parâmetros ficam em `"p"`.

## Âncoras de tempo
Toda chave `em` ou `em_*` é uma palavra da legenda: `"marca"` (1ª vez), `"te#2"` (2ª vez), `"aponta+0.1"`
(0,1 s depois). Acento, maiúscula e pontuação não importam (`"le"` acha "lê"). Se a palavra não existe, a
etapa 4 para e diz quantas vezes ela aparece. Texto com `*palavra*` (só no título do gancho) fica Lime.

`"som"` dentro de qualquer item troca o som padrão daquele momento (valores em `sfx.md`).

## Modos de quadro
- **S, tela dividida**: painel animado 1080x960 em cima, rosto embaixo (zoom lento 1,10 → 1,16). Todas as cenas
  abaixo, menos `rosto` e `mosaico`.
- **F, rosto cheio** (`rosto`): zoom 1,40, pequeno assentamento a cada corte, punch-in de 1,07 na palavra de
  impacto. Use em 3 a 5 momentos de ênfase, nunca dois seguidos.
- **M, mosaico** (`mosaico`): fecho; todas as cenas viram azulejos, rosto ao vivo no centro, câmera recua.

## Cenas

| tipo | uso | parâmetros |
|---|---|---|
| `gancho` | abre o vídeo: selo da série + título no frame 0 + linhas iguais empilhando | `linhas[{rotulo, texto, em}]` (a 1ª em = 1ª palavra), `contador` ("colado {n}x"), `exemplo` |
| `rosto` | ênfase, sticker de topo | `punch{em}`, `sticker{texto, em, dur}` |
| `nascer` | 1 vira muitos | `centro`, `rotulo`, `arquivo`, `itens[até 6]`, `em` |
| `card` | card do dia (dados do projeto), trilha acende | `em_trilha` |
| `grade` | calendário da série; passados Teal, hoje Lime | `em_aceso`, `rotulo`, `selo{texto, em}` |
| `chat` | blocos colados chegando numa conversa | `titulo`, `tecla{texto[], em}`, `itens[{texto, rotulo, em}]`, `exemplo` |
| `limpar` | botão clicado, tudo cai, frase grande | `botao`, `em_clique`, `itens[]`, `placeholder`, `frase{texto, em}` |
| `arvore` | árvore de arquivos digitando + prévia | `linhas[]`, `em`, `destaque` (índice), `em_destaque`, `previa[]`, `selo{texto, em}` |
| `tela` | screenshot real (README, site) com zoom lento e selos | `img` (relativo à pasta), `url`, `selos[{texto, em, x, y, rot}]` |
| `pedido` | caixa de mensagem digitando e enviando | `texto`, `em`, `em_enviar`, `rotulo` |
| `perguntas` | pedido no topo + perguntas do Claude chegando | `pedido`, `rotulo`, `itens[{texto, em}]` |
| `fluxo` | passos acendendo no tempo do verbo | `rotulo`, `passos[{nome, em}]` (até 4), `ok{texto, em}`, `selo{texto, em}` |
| `terminal` | comandos reais digitando | `linhas[{cmd, em}]`, `rotulo`, `fonte` (26; baixe se o comando não couber) |
| `versao` | antes e depois de um arquivo | `arquivo`, `de`, `para`, `em_barra`, `selo{texto, em}` |
| `frase` | uma palavra grande no lugar de meme (máx. 2 por vídeo) | `texto`, `em`, `apoio`, `tamanho` |
| `mosaico` | fecho | nenhum |

Som padrão de cada momento: corte de cena = whoosh; `gancho.linhas` = colar (UI); `nascer` = dois pops;
`card`/`grade`/`arvore.selo`/`versao.selo` = sino; `chat.tecla` = copiar (UI); `chat.itens` = chegada (UI,
alternando); `limpar.em_clique` = tecla, `limpar.frase` = impacto; `arvore.em`/`pedido.em`/`terminal` =
digitação; `pedido.em_enviar` = enviar (UI); `perguntas.itens` = notificação (UI, alternando);
`fluxo.passos` = tecla, `fluxo.ok` = sino forte; `tela.selos`/`*.selo`/sticker = pop; `rosto.punch` =
impacto leve; `frase` = impacto.

## Cena nova (quando o mapa visual pedir algo que não existe)
Acrescente o tipo em `assets/cenas.html` (função em `S`, mesma paleta, `pop`/`fade`/`typed` para movimento),
o som padrão em `SOUNDS` de `scripts/e4_graficos.py` e a linha nesta tabela, no mesmo commit.
