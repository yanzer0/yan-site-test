# Prompt curto por vídeo

O pedido de cada vídeo leva só o que é dele: dados (nome, tagline, link, palavra-chave do CTA, título do gancho), o roteiro e o mapa frase -> tela. O padrão de edição mora nesta skill. Ao montar o cenas.json, cada linha do mapa vira um tipo do catálogo (references/cenas.md).
