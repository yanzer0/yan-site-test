# Setup da máquina (uma vez)

| precisa | como confere |
|---|---|
| ffmpeg/ffprobe com zscale e tonemap | `ffmpeg -filters | grep zscale` |
| Python com faster-whisper CUDA, numpy, opencv-python, pillow, playwright (chromium) | `python -c "import faster_whisper, cv2, PIL, playwright"` |
| GPU NVIDIA (transcrição large-v3) | a etapa 1 usa `device="cuda"` |
| real-sfx em `~/.reel-dinamico/real-sfx` (ou `REAL_SFX_DIR`) | `python scripts/setup.py check` dentro dela |
| earshot com venv em `~/.reel-dinamico/earshot` (ou `EARSHOT_PYTHON`) | `.venv/Scripts/python -m earshot doctor --load` |

As duas ferramentas de som são abertas: real-sfx (github.com/Clipwing/skills, pasta skills/real-sfx) e earshot (github.com/Leonxlnx/earshot). Instale em ~/.reel-dinamico/real-sfx e ~/.reel-dinamico/earshot, ou aponte REAL_SFX_DIR e EARSHOT_PYTHON para onde estiverem. Leia o código das duas antes de instalar: o earshot baixa modelos de ~1,1 GB na primeira vez.
