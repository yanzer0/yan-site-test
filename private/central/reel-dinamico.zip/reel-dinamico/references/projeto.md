# `projeto.json`

```json
{
 "video": "C:/caminho/do/seu/video.MOV",
 "saida": "dia-01-final",
 "dia": 1,
 "total_dias": 30,
 "serie": "SKILLS DO CLAUDE",
 "skill": "skill-creator",
 "tagline": "A skill que cria todas as outras",
 "repo": "github.com/anthropics/skills",
 "estrelas": "★ 187 mil",
 "titulo_gancho": "Pare de *repetir* o prompt",
 "cta": {"texto": "Comenta <span class=\"kw\">CRIADOR</span>", "em": "comenta"},
 "segue": "Segue pro dia 2",
 "grafias": [["cloud", "Claude"], ["skill creator", "skill-creator"], ["a criadora", "CRIADOR"]],
 "rosto": [540, 1030],
 "manter": ["i01", "i02", {"id": "i08", "inicio": 30.5, "fim": 33.2}]
}
```

| campo | o que é |
|---|---|
| `video` | bruto, caminho absoluto |
| `saida` | nome do MP4 final (a capa vira `capa-<saida>.png`) |
| `dia`, `total_dias`, `serie` | selo, card, grade e trilha |
| `skill`, `tagline`, `repo`, `estrelas` | card do dia (vêm dos DADOS do card; `estrelas` vazio esconde o selo) |
| `titulo_gancho` | título no frame 0; `*palavra*` fica Lime; até ~24 caracteres para caber numa linha |
| `cta` | sticker do CTA até o fim; `em` = palavra onde ele entra; a palavra-chave vai em `<span class="kw">` |
| `segue` | opcional; padrão "Segue pro dia N+1" (no último dia, "Segue pra mais") |
| `grafias` | correções da transcrição, aplicadas a sequências de palavras: `["de", "para"]` |
| `rosto` | centro do rosto no quadro 1080x1920 do bruto (meça num quadro se a pessoa estiver deslocada) |
| `manter` | ilhas da etapa 1 que ficam, em ordem; objeto com `inicio`/`fim` (segundos do bruto) apara uma ilha |
