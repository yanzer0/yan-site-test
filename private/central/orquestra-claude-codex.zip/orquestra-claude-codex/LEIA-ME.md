# Orquestra Claude + Codex

Dois agentes trabalhando na mesma tarefa sem um aprovar o proprio servico: o Codex executa a
fatia, o Claude escreve a ordem, reproduz cada prova por conta propria e da o veredito.

## Instalar (1 minuto)

1. Descompacte esta pasta.
2. Abra o Claude Code na pasta do seu projeto.
3. Diga: **"instala a skill orquestra claude codex"**.

O agente roda o comando abaixo e mostra o que escreveu. Prefere fazer na mao? E o mesmo comando:

```bash
node orquestra-claude-codex/instalar.mjs
```

Isso instala so no projeto atual. Pra valer em todos os seus projetos, use `--global`. Reinicie
a sessao depois. Node 18 ou superior, nada pra baixar.

## O problema que isso resolve

Agente que executa e depois diz "pronto, testei, passou" e o pior arranjo possivel: quem escreveu
o codigo e a mesma parte que decide se o codigo presta. O resultado e o falso-verde, e voce so
descobre em producao.

Aqui a execucao e a validacao ficam em modelos diferentes, e a regra e uma so: **nada e aceito
por declaracao**. O Codex nao termina dizendo que passou, ele para e entrega as saidas literais.
O Claude entao volta o repositorio pro commit anterior ao conserto, roda o teste de novo pra ver
o problema acontecendo, roda a suite inteira, le o diff linha a linha e conta quantos asserts
foram removidos. Se algo nao bate, volta pro executor como item de correcao, nao se conserta por
cima.

Nos 7 ciclos que originaram este metodo, 5 releases passaram no gate de primeira e 2 falharam de
verdade. As duas falhas foram o executor reportando o proprio FAIL sem tentar salvar a aparencia,
que e exatamente o comportamento que o metodo compra.

## Como usar no dia a dia

| Voce diz | Acontece |
|---|---|
| "monta a work order da fatia X" | O Claude escreve o contrato da fatia: escopo, o que e proibido, arquivos que podem ser tocados, criterios de aceite com a prova exigida de cada um |
| "despacha pro Codex" | O Codex roda headless (`codex exec`), diagnostica, escreve o teste que reproduz o problema, conserta, roda a suite e PARA aguardando validacao |
| "valida" | O Claude reproduz tudo do zero e escreve o veredito na propria ordem |
| "fica de vigia e segue ate o final" | O ciclo inteiro sem voce no meio, com parada obrigatoria se o veredito vier vermelho |

A skill carrega os 11 blocos do metodo, incluindo o bootstrap num projeto novo, o isolamento por
worktree, o formato do relatorio, a regua de validacao e os niveis de autonomia.

## Pre-requisitos

- Claude Code (e onde a skill roda).
- Codex CLI 0.149 ou maior, logado. O metodo usa `codex exec`, o modo nao-interativo.
- Um repositorio com git e um comando unico que roda a suite de testes. Sem suite, a primeira
  fatia e criar a suite.

O instalador checa os tres e imprime o que faltou.

## A fronteira honesta

Isto **nao** e um plugin que roda sozinho no seu lugar. E um metodo escrito, e o que ele garante
e que o agente pare nos lugares certos: antes do release, antes de escrever pela primeira vez num
sistema externo, e diante de qualquer resultado que nao foi reproduzido.

Isto **nao** torna dois agentes mais baratos que um. Voce paga a execucao e paga a validacao. O
que voce compra com essa diferenca e nao subir codigo que ninguem conferiu.

E o metodo assume uma cultura antes de qualquer ferramenta: FAIL honesto vale mais que verde
maquiado. Se o seu combinado com o agente for "me traz sempre boa noticia", nenhum harness segura.

---

Feito pela [Infuser](https://useinfuser.com) - consultoria de IA.
