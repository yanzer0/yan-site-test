#!/usr/bin/env node
// instalar.mjs - instala a skill "Orquestra Claude + Codex".
//
// Idempotente: rodar duas vezes nao duplica nada. Faz backup datado se ja existir uma versao.
//
//   node instalar.mjs                 instala no projeto atual (.claude/skills/)
//   node instalar.mjs --global        instala pra todos os projetos (~/.claude/skills/)
//   node instalar.mjs --projeto X     instala no projeto X
//   node instalar.mjs --dry           mostra o que faria, sem escrever
//   node instalar.mjs --remover       desinstala a skill
//
// No fim ele NAO diz apenas "instalado": le o arquivo instalado de volta, confere o nome no
// frontmatter e as 11 secoes do metodo, e checa os pre-requisitos do Codex na maquina.

import cp from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PACOTE = path.dirname(fileURLToPath(import.meta.url));
const NOME = 'orquestra-claude-codex';
const ORIGEM = path.join(PACOTE, 'skills', NOME, 'SKILL.md');

const argv = process.argv.slice(2);
const dry = argv.includes('--dry');
const remover = argv.includes('--remover');
const global_ = argv.includes('--global');
const projetoArg = (() => {
  const i = argv.indexOf('--projeto');
  return i > -1 ? argv[i + 1] : null;
})();

const RAIZ = global_
  ? path.join(os.homedir(), '.claude')
  : path.join(path.resolve(projetoArg || process.cwd()), '.claude');
const DESTINO = path.join(RAIZ, 'skills', NOME);
const ARQUIVO = path.join(DESTINO, 'SKILL.md');

const log = (m) => console.log(m);

log('Orquestra Claude + Codex - instalacao');
log('destino: ' + ARQUIVO + (global_ ? '  (vale em todos os projetos)' : '  (vale so neste projeto)'));
log('');

if (remover) {
  if (!fs.existsSync(DESTINO)) { log('nada pra remover (nao estava instalada aqui).'); process.exit(0); }
  if (dry) { log('removeria: ' + DESTINO); process.exit(0); }
  fs.rmSync(DESTINO, { recursive: true, force: true });
  log('REMOVIDA: ' + DESTINO);
  log('Reinicie a sessao do Claude Code.');
  process.exit(0);
}

if (!fs.existsSync(ORIGEM)) {
  console.error('FALHA: nao achei ' + ORIGEM + ' - rode este script de dentro da pasta descompactada.');
  process.exit(1);
}

if (fs.existsSync(ARQUIVO) && !dry) {
  const bak = ARQUIVO + '.bak-' + new Date().toISOString().slice(0, 10);
  fs.copyFileSync(ARQUIVO, bak);
  log('ja existia uma versao; backup em ' + path.basename(bak));
}

if (dry) {
  log('escreveria: ' + ARQUIVO + ' (--dry, nada foi escrito)');
} else {
  fs.mkdirSync(DESTINO, { recursive: true });
  fs.copyFileSync(ORIGEM, ARQUIVO);
  log('ESCRITO: ' + ARQUIVO);
}

// ---------------------------------------------------------------- prova do que foi escrito
if (!dry) {
  const txt = fs.readFileSync(ARQUIVO, 'utf8');
  const nome = (txt.match(/^name:\s*(\S+)/m) || [])[1];
  const secoes = (txt.match(/^## /gm) || []).length;
  if (nome !== NOME) { console.error('PROVA FALHOU: frontmatter diz name: ' + nome); process.exit(1); }
  if (secoes < 11) { console.error('PROVA FALHOU: so ' + secoes + ' secoes no arquivo instalado.'); process.exit(1); }
  log('PROVA: skill "' + nome + '" instalada com as ' + secoes + ' secoes do metodo.');
}

// ---------------------------------------------------------------- pre-requisitos (so leitura)
log('');
log('PRE-REQUISITOS na sua maquina:');

const codex = cp.spawnSync('codex', ['--version'], { encoding: 'utf8', shell: true, windowsHide: true });
const versao = (codex.stdout || '').trim();
if (codex.status !== 0 || !versao) {
  log('  [ ] Codex CLI: nao encontrado no PATH. Instale e faca login (`codex login`).');
} else {
  log('  [x] Codex CLI: ' + versao + '  (o metodo precisa de `codex exec`, CLI 0.149 ou maior)');
}

const cfg = path.join(os.homedir(), '.codex', 'config.toml');
if (!fs.existsSync(cfg)) {
  log('  [ ] ~/.codex/config.toml: nao existe. Sem model/effort definidos, o exec roda no padrao.');
} else {
  const t = fs.readFileSync(cfg, 'utf8');
  const modelo = (t.match(/^\s*model\s*=\s*"([^"]+)"/m) || [])[1];
  const esforco = (t.match(/^\s*model_reasoning_effort\s*=\s*"([^"]+)"/m) || [])[1];
  log('  [' + (modelo ? 'x' : ' ') + '] model = ' + (modelo || 'nao definido  (o metodo foi provado com o topo de linha do Codex)'));
  log('  [' + (esforco === 'xhigh' ? 'x' : ' ') + '] model_reasoning_effort = ' + (esforco || 'nao definido') + (esforco === 'xhigh' ? '' : '  (o metodo foi provado com "xhigh")'));
}

log('');
log('Reinicie a sessao do Claude Code pra skill entrar no contexto.');
log('Depois peca, no Claude: "monta a work order da fatia X e despacha pro Codex".');
