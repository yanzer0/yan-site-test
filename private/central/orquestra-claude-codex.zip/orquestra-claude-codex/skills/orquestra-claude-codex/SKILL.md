---
name: orquestra-claude-codex
description: >-
  Método de orquestração do duo Claude (Fable 5, orquestrador/autor/validador/release) + Codex
  (gpt-5.6-sol xhigh, executor headless via codex exec) para fatias de engenharia com validação
  independente. Use SEMPRE que pedirem pra orquestrar/despachar trabalho pro Codex, montar work
  order de fatia, rodar pipeline autônomo ("fica de vigia", "segue até o final", "monta a fatia
  X"), ou aplicar este modelo num projeto novo. Provada em 7 ciclos completos num sistema B2B em
  produção (31/08-02/09/2026): 5 releases com gate de primeira, 2 FAILs honestos arbitrados,
  zero falso-verde.
---

# Orquestra Claude + Codex

> Divisão provada: **Claude (Fable 5)** escreve a ordem, valida de forma independente, executa
> release/config e dá o veredito. **Codex (gpt-5.6-sol, reasoning xhigh)** executa a fatia.
> A regra que sustenta tudo: **quem executa nunca valida o próprio trabalho, e nada é aceito
> por declaração** - todo resultado do executor é REPRODUZIDO pelo validador.

## 0. Bootstrap num projeto novo (verificar ANTES do 1º ciclo)

1. `codex --version` e `codex login status` (CLI ≥0.149 tem `codex exec` não-interativo).
2. `~/.codex/config.toml`: `model = "gpt-5.6-sol"`, `model_reasoning_effort = "xhigh"` (o exec
   herda o config; não passe `-m` sem motivo).
3. O repo tem: comando de suíte única (ex: `npm run test:ci`), caminho de deploy conhecido
   (push = deploy? manual?), `.env` local, e um lugar pra work orders (`.planning/work-orders/`
   é a convenção). Sem suíte = criar a primeira fatia PRA existir suíte.
4. Autonomia combinada COM O DONO por escrito antes de agir (ver §7).

## 1. A unidade de trabalho: work order de FATIA

Fatia estreita, uma por vez, com contrato completo no próprio arquivo:

- **authority_source**: a autorização VERBATIM do dono (quote + data) - a ordem carrega a prova
  de quem mandou.
- **scope** de uma frase; **fora do escopo** explícito (o que é PROIBIDO nesta ordem).
- **allowed_write_globs**: lista fechada de arquivos que a fatia pode tocar (mesmo sem guard
  automático, o validador cobra no diff).
- **base_commit** REAL (SHA completo de `git rev-parse`, nunca placeholder zerado).
- **Lei da fatia**: 3-5 regras que decidem todo empate (fail-closed; o que nunca afrouxa).
- **ACs numerados** (Fase A offline + Fase B produção) com a PROVA exigida de cada um.
- Fluxo do arquivo: Claude escreve a fonte → posiciona no worktree → executor preenche base e
  ativa. Fonte vira ponteiro depois da cópia conferida (diff zero além do placeholder).

## 2. O ciclo de uma fatia

```
Fase 0 (executor, read-only)  → diagnóstico dirigido: causa com arquivo:linha, medições na
                                 produção real com CAPS (custo teto, ≤N execuções), snapshot
                                 baseline se a fatia compara antes/depois, tokens temporários
                                 REVOGADOS com prova. SEMPRE antes de qualquer código.
Spec delta (executor)         → atualizar a definição de engenharia ANTES do código.
RED (executor)                → teste que REPRODUZ o problema real (estados exatos da produção).
Ramos + contra-fixtures       → o fix, com contra-provas de que não abriu porta nova.
Suíte + rodada SEM .env       → suíte completa + selftests tocados com env limpo/cwd fora do
                                 repo (o gate de build não tem o .env da máquina).
Relatório + PARADA            → formato consagrado (ver §5); executor para em
                                 awaiting_independent_validation. NUNCA pusha/deploya.
Validação independente (Claude, §6) → veredito com F-itens ou aprovação.
Release (Claude, §8)          → micro-ordem própria; bump; push=deploy; confirmar no caminho REAL.
Fase B (executor, produção)   → provar os ACs na produção viva; FAIL honesto se algo não passou.
Veredito final (Claude)       → arbitra, roteia residuais pra próxima fatia, fecha a ordem,
                                 propaga documentação/brain.
```

## 3. Despacho headless (Claude dispara o Codex, sem humano colando)

```bash
codex exec -C "<worktree>" --add-dir "<repo-principal>/.git" --approve-for-me --color never - < prompt.md
```

- `-s/--sandbox` NÃO combina com `--approve-for-me` (conflito de flags; approve-for-me já usa
  workspace-write). O erro sai com exit 0 - leia a saída, nunca confie no exit.
- `--add-dir <principal>/.git` é obrigatório em worktree: os commits escrevem no .git de lá.
- **O prompt é uma sessão NOVA sem memória do chat**: autossuficiente - caminhos absolutos, o
  que ler (a work order + vereditos anteriores + learnings), primeiro ato, mapa da execução,
  inegociáveis. Rode em background e guarde o task id.
- **Prova de vida obrigatória**: exec disparado ≠ exec rodando. Confirme por efeito (status da
  WO flipou, processo existe, primeiro commit) - o buffer do pipe segura a saída até o fim.
- Fases encadeadas sem humano: sincronize por SINAL EXTERNO verificável (ex: o executor faz
  poll do /health até a versão nova aparecer → começa a Fase B sozinho), sempre com timeout
  que PARA E REPORTA (nunca força).
- Correção pequena pós-veredito = micro-despacho novo com contexto mínimo (mesmo worktree,
  "não mude o status", tarefa única, PARE).

## 4. Isolamento físico e coreografia de slot

- **Um worktree por fatia**: `git worktree add ../<repo>-<fatia> -b codex/<fatia> master` +
  copiar `.env` (git-ignored). Executor commita na branch e NUNCA pusha; o Claude faz
  ff/merge no master e pusha. Árvore principal pode estar ocupada por outra sessão - nunca
  trocar branch de checkout alheio; se um commit cair em branch alheia, ff do master pro SHA
  (`git push . <sha>:master`), nunca rebase de trabalho alheio.
- Se o repo tem regra de work-order única ativa (scope lock): pausar a WO vizinha e ativar a
  sua NO MESMO commit (estado staged nunca tem 2 ativas); reativação da vizinha é ato de
  FECHAMENTO do pipeline, pelo Claude, documentado.
- Worktree novo no Windows: `core.autocrlf=true` REESCREVE LF→CRLF no checkout e corrompe
  fixtures byte-sensíveis - `git config core.autocrlf false` + re-checkout antes de testar.
- `npx tsx` pode não resolver por junction de node_modules: use
  `node node_modules/tsx/dist/cli.mjs` como caminho explícito.

## 5. Relatório do executor (formato consagrado)

Frontmatter com: report_status, base_commit, code_artifact_commit (o SHA EXATO validável),
passed/pending ACs, e booleans de efeito (push/deploy/write/POST executados). Corpo com: mapa
de commits (1 linha cada), Fase 0 com custo real do ledger + revogação de tokens com prova,
RED e GREEN com as saídas literais, contra-fixtures em tabela, gates finais (suíte N/N +
tempo), rodada sem .env, varreduras negativas (paths fora do escopo = 0, migração = 0, writes
= 0 com contadores), achados novos DEFERIDOS (nunca hotfix por conta própria) e a PARADA.
**Zero nunca vira sucesso**: requisito que não aconteceu = FAIL declarado, mesmo com o resto
verde. FAIL honesto é o harness funcionando, não defeito do executor.

## 6. Validação independente (a régua do Claude - nada por declaração)

1. **RED reproduzido**: worktree no commit PRÉ-fix, rodar o teste, exigir o sintoma EXATO da
   produção (não qualquer falha - o log de RED confere estado a estado).
2. **GREEN + sem .env próprios**: os selftests tocados, cwd fora do repo, env limpa.
3. **Suíte completa própria** (em background enquanto lê o diff).
4. **Diff semântico** do range inteiro: fail-closed preservado? porta nova? escopo dentro dos
   globs? Contar asserts REMOVIDOS (`diff | grep '^-.*assert'`) - flip de expectativa só vale
   se ENDURECE pro comportamento desenhado; evolução de contrato exige autoridade citada e
   invariantes sobreviventes verbatim.
5. **Varreduras**: PII/segredo em tudo que nasceu (fixture nova = de-para byte-preservante;
   nomes de pessoa incluídos - já escapou um), dependências, migrações.
6. Veredito escrito NA work order: reproduzido → confirmado → F-itens obrigatórios (com o
   conserto exato) ou aprovação. F-item volta pro EXECUTOR (micro-despacho), não se conserta
   por cima - exceto camada de release/config, que é do Claude.
7. As 3 camadas de fixture (lição paga 3x): fixture de função NÃO prova documento; fixture de
   documento NÃO prova fluxo; fixture de componente NÃO prova projeção HTTP. Mudança que
   atravessa camadas exige teste da camada REAL (e2e do endpoint, ciclo completo com dublês).

## 7. Autonomia: níveis de go, sempre POR ESCRITO antes de agir

- **Go por fase** (default): validação → avisar o dono → go explícito → release.
- **Go condicional** ("se a revalidação passar, pode subir"): registrar o quote e executar sem
  novo ask QUANDO a condição fechar.
- **Fluxo integral** ("segue até o final"): validação verde = go; vermelho = para e reporta.
- O nível vale pro CICLO que o recebeu - morre no fechamento; ciclo novo, combinado novo.
- **Nunca delegáveis sem go nominal específico**: primeira escrita num sistema EXTERNO
  (ERP/canal do cliente), mensagem client-facing, mudança de contrato de contenção. Escrita
  externa nova nasce atrás de flag default OFF e sobe DARK; ligar é decisão do dono.
- Registrar autorizações no registro do projeto (decisão/nota datada com o quote) ANTES do ato.

## 8. Release e configuração (sempre do Claude, nunca do executor)

- Micro work order de release própria (globs: o próprio arquivo + bump + arquivos de deploy),
  base real, evidência de fechamento (run de CI + confirmação viva).
- Confirmar SEMPRE no caminho real: run do CI concluído + endpoint de versão/health com o
  valor novo - exit de comando não prova nada; um /health 200 com código velho já aconteceu.
- Config de produção: mudar env exige que o deploy REPASSE a var (compose/manifest) - flag que
  chega ao processo é diferente de flag que existe no host; gates podem ter DUAS camadas
  (feature flag + ativação de rotina). Recreate manual de container só pela ferramenta
  sancionada do repo, com a tag da imagem VIVA; sempre backup do env antes de editar.
- Commits de documentação levam `[skip ci]`; o commit de bump NÃO (ele é o deploy). O HEAD do
  push é quem decide o CI.

## 9. Vigias (monitors de arquivo, não de fé)

- Loop por polling nos ARQUIVOS (status da WO por linha `^status:`, md5 dos relatórios),
  emitindo só transições; condição terminal explícita + cobertura de FALHA (silêncio parece
  progresso). Um vigia por perna do ciclo.
- Gotchas: `$?` depois de pipe é do último comando (echo EXIT explícito ou PIPESTATUS);
  primeira leitura é BASELINE, não evento; saída do exec só aparece no fim (tail bufferiza) -
  liveness por efeito, não por output.

## 10. Cultura que faz o modelo funcionar

- FAIL honesto > verde maquiado. O executor que reporta o próprio FAIL sem hotfix está CERTO;
  o Claude arbitra: resolve na camada dele (config/release), roteia pra fatia seguinte
  (residual NOMEADO com família e remédio), ou reprova. Nada é varrido pra debaixo do placar.
- Residual vira ENTRADA da próxima fatia (o FAIL de hoje é o RED de amanhã).
- Cada lição nova de processo vira learning/guard no mesmo dia - o método só se manteve barato
  porque os erros não repetem.
- Documentar EM TEMPO REAL na work order e no registro do projeto: veredito, autorização,
  evidência - a ordem fechada é auditável sozinha, sem o chat.

## Provenance

Destilado de 7 ciclos completos num sistema B2B multi-tenant em produção (31/08-02/09/2026):
5 releases consecutivas passando no gate de primeira, um pipeline noturno rodando 100% sozinho,
2 FAILs honestos arbitrados, zero falso-verde. As quatro lições que mais custaram caro e viraram
regra aqui dentro:

- fixture de função NÃO prova documento, e documento NÃO prova fluxo (§6.7);
- selftest que lê o `.env` da máquina passa sozinho e quebra no build limpo (§2);
- deploy disparado em background NÃO é deploy: confirme na versão viva (§8);
- rotina que deu erro devolvendo zero não é sucesso: zero nunca vira verde (§5).
