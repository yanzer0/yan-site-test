---
name: video-transcricao-gpu
description: "Transcreva áudio e vídeo localmente com GPU NVIDIA/CUDA usando faster-whisper, extraia frames com timestamps e inspecione o conteúdo visual. Use quando houver pedido de transcrição offline, análise de um vídeo, leitura de telas ou apresentação visual presente em vídeo."
---

# Vídeo: transcrição GPU e frames

Processar vídeo localmente, sem enviar o arquivo a serviços externos. Usar a GPU somente quando a verificação indicar CUDA funcional. Antes de interpretar uma interface, apresentação, planilha ou demo, extrair e abrir frames representativos.

## Preparar

1. Confirmar os requisitos:

   ```powershell
   powershell -ExecutionPolicy Bypass -File "<pasta-da-skill>/scripts/check-gpu-transcription.ps1"
   ```

2. Se o resultado for `GPU RECOMENDADO`, continuar. Se CUDA, `faster-whisper` ou `ffmpeg` estiverem ausentes, corrigir a dependência indicada antes de iniciar.

3. Garantir que não exista outra transcrição desta skill em execução. Executar uma transcrição por GPU de cada vez.

## Transcrever

Executar em segundo plano quando o ambiente suportar processos em background:

```powershell
python "<pasta-da-skill>/scripts/transcribe-gpu.py" "C:\caminho\video.mp4"
```

Usar `--lang pt` para português, `--model large-v3` quando houver VRAM suficiente e `--out "C:\pasta\saida"` para escolher o destino. O script grava `<nome>-transcript.txt` e `<nome>-transcript.json`, este último com timestamps por segmento.

Ler o sinal final do processo:

- `GPU_DONE` - ler o transcript e seguir com a análise solicitada.
- `GPU_BUSY` - aguardar a outra transcrição terminar e tentar novamente, sem paralelizar.
- `GPU_ERROR` - informar o erro objetivo e corrigir a causa antes de repetir.

Não remover os parâmetros anti-repetição do script. Eles reduzem loops e trechos inventados pelo modelo.

## Ver frames

Extrair frames antes de comentar conteúdo visual:

```powershell
python "<pasta-da-skill>/scripts/extract-frames.py" "C:\caminho\video.mp4" --count 12
```

Para investigar um momento específico, passar timestamps:

```powershell
python "<pasta-da-skill>/scripts/extract-frames.py" "C:\caminho\video.mp4" --timestamps "12.5,48,103.2"
```

O comando cria a pasta `<nome>-frames/`, com JPEGs cujo nome contém o timestamp e um `frames.json` de mapeamento. Abrir as imagens com a ferramenta de visualização disponível no ambiente antes de descrever telas, textos, gráficos, pessoas ou cortes. Tratar o que aparece nos frames como evidência visual; não inferir detalhes que não estão legíveis.

## Entregar

Separar claramente no resultado:

- O que a transcrição diz, com timestamp quando relevante.
- O que é visível nos frames, citando o arquivo/timestamp.
- Interpretações ou recomendações, quando houver, como inferência.

