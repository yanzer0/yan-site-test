# check-gpu-transcription.ps1
# Decide se a maquina compensa transcrever video na GPU ou fica no CPU.
# Rodar uma vez por maquina, ou quando o ambiente mudar.
# Uso:  powershell -ExecutionPolicy Bypass -File check-gpu-transcription.ps1

$ErrorActionPreference = "SilentlyContinue"
Write-Output "=== Verificacao GPU para transcricao de video ==="
Write-Output ""

# 1) GPU NVIDIA presente?
$smi = Get-Command nvidia-smi -ErrorAction SilentlyContinue
$gpuName = $null; $freeVram = 0
if ($smi) {
    $gpuName  = (& nvidia-smi --query-gpu=name --format=csv,noheader 2>$null | Select-Object -First 1)
    $freeRaw  = (& nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits 2>$null | Select-Object -First 1)
    if ($freeRaw) { $freeVram = [int]$freeRaw / 1024.0 }  # MiB -> GiB
    Write-Output ("GPU NVIDIA      : {0}" -f $gpuName)
    Write-Output ("VRAM livre      : {0:N1} GB" -f $freeVram)
} else {
    Write-Output "GPU NVIDIA      : NAO detectada (nvidia-smi ausente)"
}

# 2) Python + libs
$py = (Get-Command python -ErrorAction SilentlyContinue)
$cudaOk = $false; $fwOk = $false
if ($py) {
    $pyver = (& python --version 2>&1)
    Write-Output ("Python          : {0}" -f $pyver)
    $cudaOk = ((& python -c "import torch,sys; sys.stdout.write('1' if torch.cuda.is_available() else '0')" 2>$null) -eq "1")
    $fwOk   = ((& python -c "import faster_whisper,sys; sys.stdout.write('1')" 2>$null) -eq "1")
    Write-Output ("torch.cuda      : {0}" -f $(if ($cudaOk) {"OK"} else {"indisponivel"}))
    Write-Output ("faster-whisper  : {0}" -f $(if ($fwOk) {"instalado"} else {"AUSENTE"}))
} else {
    Write-Output "Python          : NAO encontrado"
}

# 3) ffmpeg
$ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue)
Write-Output ("ffmpeg          : {0}" -f $(if ($ff) {"OK"} else {"AUSENTE"}))
Write-Output ""

# 4) Veredito
Write-Output "=== VEREDITO ==="
if (-not $smi) {
    Write-Output "USAR CPU. Sem GPU NVIDIA nesta maquina. Use uma ferramenta local de Whisper em CPU."
}
elseif (-not $cudaOk -or -not $fwOk) {
    Write-Output "GPU PRESENTE, mas faltam libs. Instale e ganhe ~5-6x de velocidade:"
    Write-Output "    pip install faster-whisper"
    Write-Output "    (torch CUDA: https://pytorch.org/get-started/locally  -> escolher CUDA)"
    Write-Output "Enquanto nao instalar, use uma ferramenta local de transcricao em CPU."
}
elseif (-not $ff) {
    Write-Output "GPU OK, mas falta ffmpeg. Instale: winget install Gyan.FFmpeg   (depois roda de novo)."
}
elseif ($freeVram -ge 3.5) {
    Write-Output ("GPU RECOMENDADO (float16, large-v3). VRAM livre {0:N1}GB sobra." -f $freeVram)
    Write-Output "Transcreva com: python transcribe-gpu.py `"<video>`""
}
elseif ($freeVram -ge 2.0) {
    Write-Output ("GPU RECOMENDADO (int8_float16). VRAM {0:N1}GB e justa mas funciona; o script escolhe a precisao sozinho." -f $freeVram)
}
else {
    Write-Output ("MARGINAL. So {0:N1}GB de VRAM livre -> o ganho some. Feche apps pesados e rode de novo, ou use uma ferramenta local de Whisper em CPU." -f $freeVram)
}
Write-Output ""
Write-Output "Regra pratica: maquina com GPU NVIDIA capaz -> GPU costuma ser mais rapida. Sem GPU -> use Whisper em CPU."
