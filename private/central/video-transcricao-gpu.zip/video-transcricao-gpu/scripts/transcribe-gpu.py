#!/usr/bin/env python3
"""
Transcrição de vídeo/áudio na GPU (faster-whisper / CUDA).
Ferramenta local e independente para transcrição em GPU.

Uso:
    python transcribe-gpu.py "C:\\caminho\\video.mp4"
    python transcribe-gpu.py "video.mp4" --model large-v3 --lang pt --out "C:\\saida"

Saída: <nome>-transcript.txt (texto) + <nome>-transcript.json (com timestamps),
gravados ao lado do arquivo de entrada (ou em --out).

CONTRATO DE SINAL (pra auto-retomada do agente via run_in_background):
  o processo SEMPRE termina (sai) com UMA destas linhas + exit code:
    GPU_DONE  ...   exit 0   -> sucesso, transcript escrito
    GPU_ERROR: ...  exit 1/2/3 -> falhou (msg na linha)
    GPU_BUSY: ...   exit 4   -> outra transcrição GPU rodando (lock); rodar em sequência
  => nunca trava-silencioso. Quando o ambiente suportar, rode em background e
     trate o sinal final como o gatilho para ler o transcript ou investigar o erro.

Pré-requisitos: faster-whisper, torch+CUDA, ffmpeg no PATH, GPU NVIDIA.
Rode check-gpu-transcription.ps1 antes pra confirmar que a máquina aguenta.
"""
import argparse, json, os, subprocess, sys, tempfile, time

# stdout do Windows é cp1252: caractere alucinado pelo whisper (ex: CJK) derrubava o
# processo no print() ANTES de salvar o transcript (learning transcricao-stdout-utf8).
# reconfigure + errors="replace" garante que log NUNCA mata a transcrição.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def log(m): print(m, flush=True)

# ---------- lock de GPU (impede 2 transcrições simultâneas = deadlock de VRAM) ----------
LOCK = os.path.join(tempfile.gettempdir(), "video-transcricao-gpu.lock")
STALE_S = 4 * 3600  # lock mais velho que isso = presumido zumbi

def _pid_alive(pid):
    try:
        if os.name == "nt":
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False

def _write_lock():
    fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.write(fd, f"{os.getpid()} {int(time.time())}".encode())
    os.close(fd)

def acquire_lock():
    """True se conseguiu o lock; senão imprime GPU_BUSY e retorna False."""
    try:
        _write_lock()
        return True
    except FileExistsError:
        opid, ts = 0, 0
        try:
            parts = open(LOCK).read().split()
            opid = int(parts[0]); ts = int(parts[1]) if len(parts) > 1 else 0
        except Exception:
            pass
        fresh = ts and (time.time() - ts) < STALE_S
        if opid and _pid_alive(opid) and fresh:
            log(f"GPU_BUSY: outra transcrição GPU em andamento (pid {opid}). Rodar em SEQUÊNCIA, nunca em paralelo (deadlock de VRAM).")
            return False
        # lock zumbi (processo morto ou velho) -> rouba
        try: os.remove(LOCK)
        except Exception: pass
        try:
            _write_lock()
            return True
        except Exception:
            log("GPU_BUSY: lock de GPU em disputa, tente de novo em sequência.")
            return False

def release_lock():
    try:
        parts = open(LOCK).read().split()
        if parts and int(parts[0]) == os.getpid():
            os.remove(LOCK)
    except Exception:
        pass

# ---------- transcrição ----------
def pick_compute_type():
    """Escolhe precisão conforme VRAM livre — robustez em GPUs menores."""
    try:
        import torch
        if not torch.cuda.is_available():
            return None, 0.0
        free, _total = torch.cuda.mem_get_info()
        free_gb = free / (1024 ** 3)
        if free_gb >= 3.5:
            return "float16", free_gb       # large-v3 fp16 ~3GB
        if free_gb >= 2.0:
            return "int8_float16", free_gb  # cabe em GPU mais apertada
        return "int8", free_gb              # último recurso na GPU
    except Exception as e:
        log(f"[warn] não consegui medir VRAM: {e}")
        return "float16", 0.0

def extract_audio(src, workdir):
    wav = os.path.join(workdir, "audio.wav")
    log("extraindo áudio 16kHz mono (ffmpeg)...")
    subprocess.run(
        ["ffmpeg", "-y", "-i", src, "-ar", "16000", "-ac", "1",
         "-c:a", "pcm_s16le", wav],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return wav

def transcribe(args):
    src = os.path.abspath(args.input)
    if not os.path.exists(src):
        log(f"GPU_ERROR: arquivo não existe: {src}"); sys.exit(2)

    compute_type, free_gb = pick_compute_type()
    if compute_type is None:
        log("GPU_ERROR: CUDA indisponível nesta máquina. Instale uma solução de transcrição em CPU ou use uma GPU NVIDIA compatível."); sys.exit(3)

    from faster_whisper import WhisperModel
    t0 = time.time()
    log(f"GPU detectada · VRAM livre ~{free_gb:.1f}GB · compute_type={compute_type} · modelo={args.model}")
    model = WhisperModel(args.model, device="cuda", compute_type=compute_type)
    log(f"modelo carregado em {time.time()-t0:.1f}s")

    with tempfile.TemporaryDirectory() as workdir:
        audio = extract_audio(src, workdir)
        segments, info = model.transcribe(
            audio, language=args.lang, beam_size=5, vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500),
            # FIDELIDADE: anti-alucinação sempre ligada.
            # Sem isso o whisper repete a mesma linha 5-20x (loop) e "completa" o que
            # não ouviu. Toda transcrição de áudio/vídeo deve ser fiel.
            condition_on_previous_text=False,   # não realimenta texto anterior (fonte dos loops)
            no_repeat_ngram_size=3,             # proíbe repetir trigramas
            repetition_penalty=1.15,            # penaliza repetição
            temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],  # fallback de decodificação
            compression_ratio_threshold=2.4,   # descarta segmento repetitivo demais
        )
        log(f"lang={info.language} p={info.language_probability:.3f} dur={info.duration:.0f}s — transcrevendo...")

        txt_lines, seg_list = [], []
        for s in segments:
            log(f"[{s.start:7.2f} --> {s.end:7.2f}] {s.text}")
            txt_lines.append(s.text.strip())
            seg_list.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()})

    out_dir = os.path.abspath(args.out) if args.out else os.path.dirname(src)
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(src))[0]
    txt_path = os.path.join(out_dir, f"{base}-transcript.txt")
    json_path = os.path.join(out_dir, f"{base}-transcript.json")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(txt_lines))
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({"language": info.language, "duration": info.duration,
                   "compute_type": compute_type, "segments": seg_list},
                  f, ensure_ascii=False, indent=2)

    wall = time.time() - t0
    rt = info.duration / wall if wall else 0
    log(f"\nGPU_DONE segs={len(seg_list)} wall={wall:.0f}s (~{rt:.1f}x real-time)")
    log(f"txt:  {txt_path}")
    log(f"json: {json_path}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="vídeo ou áudio")
    ap.add_argument("--model", default="large-v3")
    ap.add_argument("--lang", default="pt")
    ap.add_argument("--out", default=None, help="dir de saída (padrão: ao lado do input)")
    args = ap.parse_args()

    if not acquire_lock():
        sys.exit(4)  # GPU_BUSY já impresso
    try:
        transcribe(args)
    except SystemExit:
        raise
    except Exception as e:
        import traceback
        log(f"GPU_ERROR: {type(e).__name__}: {e}")
        log(traceback.format_exc())
        sys.exit(1)
    finally:
        release_lock()

if __name__ == "__main__":
    main()
