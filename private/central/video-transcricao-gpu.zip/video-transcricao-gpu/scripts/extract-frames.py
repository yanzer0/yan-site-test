#!/usr/bin/env python3
"""Extract timestamped representative frames from a local video with ffmpeg."""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run(command):
    return subprocess.run(command, check=True, capture_output=True, text=True, encoding="utf-8", errors="replace")


def duration_seconds(video_path):
    result = run([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "json", str(video_path),
    ])
    payload = json.loads(result.stdout)
    duration = float(payload["format"]["duration"])
    if duration <= 0:
        raise ValueError("ffprobe não encontrou uma duração válida")
    return duration


def parse_timestamps(raw):
    try:
        values = [float(value.strip()) for value in raw.split(",") if value.strip()]
    except ValueError as exc:
        raise ValueError("--timestamps deve conter segundos separados por vírgula") from exc
    if not values or any(value < 0 for value in values):
        raise ValueError("--timestamps precisa ter ao menos um valor maior ou igual a zero")
    return values


def select_timestamps(duration, count, every, explicit):
    if explicit:
        return [value for value in parse_timestamps(explicit) if value <= duration]
    if every:
        return [round(value, 3) for value in range(0, int(duration) + 1, every)]
    return [round(duration * (index + 0.5) / count, 3) for index in range(count)]


def main():
    parser = argparse.ArgumentParser(description="Extrai frames JPEG com timestamps de um vídeo local.")
    parser.add_argument("input", help="caminho para o vídeo")
    parser.add_argument("--out", help="pasta de saída (padrão: <video>-frames)")
    parser.add_argument("--count", type=int, default=12, help="quantidade uniforme de frames (padrão: 12)")
    parser.add_argument("--every", type=int, help="extrair um frame a cada N segundos")
    parser.add_argument("--timestamps", help="segundos específicos, separados por vírgula")
    parser.add_argument("--width", type=int, default=1280, help="largura em pixels (padrão: 1280)")
    args = parser.parse_args()

    video = Path(args.input).expanduser().resolve()
    if not video.is_file():
        parser.error(f"arquivo não existe: {video}")
    if args.count < 1 or args.width < 1 or (args.every is not None and args.every < 1):
        parser.error("--count, --width e --every precisam ser maiores que zero")

    try:
        duration = duration_seconds(video)
        timestamps = select_timestamps(duration, args.count, args.every, args.timestamps)
    except (subprocess.CalledProcessError, json.JSONDecodeError, KeyError, ValueError) as exc:
        print(f"FRAMES_ERROR: não foi possível ler o vídeo: {exc}", file=sys.stderr)
        return 1

    if not timestamps:
        print("FRAMES_ERROR: nenhum timestamp válido ficou dentro da duração do vídeo", file=sys.stderr)
        return 1

    output = Path(args.out).expanduser().resolve() if args.out else video.with_name(f"{video.stem}-frames")
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"source": str(video), "duration_seconds": round(duration, 3), "frames": []}

    for index, timestamp in enumerate(timestamps, start=1):
        filename = f"frame-{index:03d}-t{timestamp:010.3f}s.jpg"
        destination = output / filename
        command = [
            "ffmpeg", "-y", "-ss", f"{timestamp:.3f}", "-i", str(video),
            "-frames:v", "1", "-vf", f"scale={args.width}:-2",
            "-q:v", "2", str(destination),
        ]
        try:
            run(command)
        except subprocess.CalledProcessError as exc:
            print(f"FRAMES_ERROR: ffmpeg falhou em {timestamp:.3f}s: {exc.stderr.strip()}", file=sys.stderr)
            return 1
        manifest["frames"].append({"timestamp_seconds": timestamp, "file": filename})
        print(f"FRAME_DONE t={timestamp:.3f}s file={destination}")

    manifest_path = output / "frames.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"FRAMES_DONE count={len(manifest['frames'])} dir={output}")
    print(f"manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
