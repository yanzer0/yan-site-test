# Instalar a skill Vídeo: transcrição GPU e frames

Você é uma IA instalando uma skill local. Copie a pasta `video-transcricao-gpu/` inteira, sem recriar os arquivos, para um destes destinos:

- Codex: `~/.codex/skills/video-transcricao-gpu/`
- Claude Code: `~/.claude/skills/video-transcricao-gpu/`

Preserve `SKILL.md`, `agents/` e `scripts/`. Depois, reabra o Codex ou Claude Code. Para usar, peça para transcrever/analisar um vídeo ou invoque `$video-transcricao-gpu`.

Não execute transcrição em GPU sem antes rodar `scripts/check-gpu-transcription.ps1`. A extração de frames funciona com `ffmpeg` mesmo sem GPU.

