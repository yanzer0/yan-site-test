# Como escrever um aprendizado

Cada arquivo `.md` nesta pasta e uma licao que volta sozinha. O frontmatter e o que faz ela voltar.

```markdown
---
titulo: Nome curto e especifico do erro
created: 2026-08-29
updated: 2026-08-29
severity: alta          # alta | media | baixa - alta surfaca primeiro
hits: 1                 # sobe sozinho quando o erro reincide
checavel: true          # existe guard que BLOQUEIA a repeticao?
guard: scripts/check-x.js
area: src/api           # RELATIVA ao projeto, nunca absoluta
triggers: [webhook, retry, idempotencia]
surface: "A frase imperativa que vai ser injetada no contexto do agente."
---

# Nome curto e especifico do erro

## O que aconteceu
O caso concreto, com arquivo e linha.

## A licao
A regra generalizada.

## Como aplicar da proxima vez
A acao especifica.
```

## Os 3 campos que decidem se serve pra alguma coisa

**`surface`** e o texto que o agente le. Escreva em imperativo e cabendo em uma linha. Se estiver
vazio, o motor usa a primeira frase do corpo, que quase sempre e pior.

**`triggers`** trazem a licao de volta pelo ASSUNTO da conversa. Prefira termo especifico
(`webhook retry`) a generico (`codigo`, `erro`). Trigger generico casa em tudo, vira ruido, e ruido
treina a equipe a ignorar o bloco inteiro - inclusive quando ele esta certo.

**`area`** traz a licao de volta pelo ARQUIVO que esta sendo editado. Sempre relativa
(`src/api`). Caminho absoluto casa nesta maquina e para de casar na proxima, sem erro nenhum -
por isso o guard bloqueia.

## Quando marcar `checavel: true`

So quando existe guard de verdade escrito e provado. `checavel: true` sem `guard:` e bloqueado
pelo checker, porque promete um bloqueio que nao existe - e quem le confia.
