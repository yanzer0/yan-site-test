---
titulo: Comando de deploy com exit 0 nao prova que a versao subiu
created: 2026-08-29
updated: 2026-08-29
severity: alta
hits: 3
checavel: false
triggers: [deploy, subir versao, producao, prod, rollout, publicar]
surface: "Depois de deployar, confirme a versao VIVA no caminho real (health, log, execucao). Exit 0 do comando nao e prova."
---

# Comando de deploy com exit 0 nao prova que a versao subiu

## O que aconteceu

O comando de deploy terminou com exit 0 e a mensagem de sucesso. O container antigo continuou
servindo (a imagem nova nem chegou a nascer, o build falhou num passo que nao propagou o codigo de
erro). Duas horas depois de "ja esta no ar", o bug reportado continuava exatamente igual.

## A licao

Exit code mede se o COMANDO rodou, nunca se o SISTEMA mudou. Sao duas afirmacoes diferentes e a
segunda e a unica que interessa pra quem esta esperando o fix.

## Como aplicar da proxima vez

Depois de qualquer deploy, confirme no caminho real antes de dizer que subiu:

- `curl` no endpoint de health lendo a VERSAO que voltou;
- ou o processo/container rodando com a imagem nova;
- ou a execucao real da rotina, com o comportamento novo observado.

Nao deu pra confirmar? Diga "deployei mas nao consegui confirmar" - nunca "esta no ar".

Este e um exemplo que ja vem instalado pra voce ver o formato funcionando. Pode apagar quando
tiver os seus.
