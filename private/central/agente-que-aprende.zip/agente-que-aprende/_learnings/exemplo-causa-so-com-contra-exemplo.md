---
titulo: Nao afirme causa sem achar um caso parecido que funciona
created: 2026-08-29
updated: 2026-08-29
severity: alta
hits: 2
checavel: false
triggers: [causa, por que quebrou, diagnostico, root cause, culpado, motivo]
surface: "Antes de afirmar por que X falhou, ache um Y do mesmo tipo que FUNCIONA e explique por que. Sem o contra-exemplo, a causa nao sai."
---

# Nao afirme causa sem achar um caso parecido que funciona

## O que aconteceu

Diagnostiquei que a integracao falhava "porque o formato do payload mudou". Soava certo e a
pessoa repassou pro cliente. O cliente respondeu com um caso do MESMO dia, MESMO formato, que
funcionou. A causa real era outra e estava a duas linhas de distancia no log.

## A licao

Explicacao plausivel nao e causa. O teste barato que separa as duas: se existe um caso parecido
que funciona e eu nao consigo explicar por que aquele funciona, minha explicacao esta incompleta.

## Como aplicar da proxima vez

1. Ache o contra-exemplo (o caso que funciona) ANTES de falar.
2. Separe explicitamente o que foi VERIFICADO (com o comando ou `arquivo:linha` que provou) do
   que foi INFERIDO. Quem le nao consegue distinguir e assume que tudo e fato.
3. Texto que vai ser repassado pra outra pessoa so leva o verificado.

Sinal de parada: se a explicacao depende de "provavelmente mudou alguma coisa", pare e va no dado
bruto. Mudanca de comportamento tem causa localizavel - ache a linha antes de falar.

Este e um exemplo que ja vem instalado pra voce ver o formato funcionando. Pode apagar quando
tiver os seus.
