#!/usr/bin/env node
'use strict';
// checar-learnings.js - ETAPA 4 do loop, a parte que nao depende de boa vontade.
//
// Roda no evento Stop (fim do turno) e no pre-commit. Sai com codigo 2 quando acha estado que
// QUEBRA a memoria em silencio - que e o unico modo de falha perigoso deste sistema: o learning
// existe, parece saudavel, e nunca surfaca. Ninguem descobre, porque nao ha erro.
//
// O que ele bloqueia (tudo mecanico - nada de julgamento):
//   1. `area` absoluta (C:/... ou /home/...) - casa nesta maquina e morre na proxima
//   2. learning sem `surface` e sem corpo aproveitavel - injeta linha vazia no contexto
//   3. `checavel: true` sem `guard:` - promete bloqueio que nao existe
//   4. frontmatter ausente - o arquivo nao entra no motor
//
// O que ele NAO faz: julgar se a licao e boa. Isso e humano. Guard so cobre o mecanico -
// guard que erra no caso legitimo e guard que a pessoa aprende a burlar.

const fs = require('node:fs');
const path = require('node:path');
const L = require(path.join(__dirname, '..', 'lib', 'learnings.js'));

const projeto = L.acharRaiz(process.env.CLAUDE_PROJECT_DIR || process.cwd()) || L.raizPadrao();
if (!projeto) process.exit(0);

const dir = path.join(projeto, '_learnings');
const problemas = [];

let arquivos = [];
try {
  arquivos = fs.readdirSync(dir).filter((f) => f.endsWith('.md') && f !== 'INDEX.md' && f !== 'COMO-ESCREVER.md');
} catch { process.exit(0); }

for (const nome of arquivos) {
  const texto = fs.readFileSync(path.join(dir, nome), 'utf8');
  const { fm, corpo } = L.parseFrontmatter(texto);

  if (!Object.keys(fm).length) {
    problemas.push(nome + ': sem frontmatter - o motor nao le este arquivo, a licao esta invisivel');
    continue;
  }
  if (fm.area && /^([A-Za-z]:|[/~])/.test(String(fm.area))) {
    problemas.push(nome + ': area absoluta (' + fm.area + ') - use caminho relativo ao projeto');
  }
  if (!fm.surface && corpo.trim().length < 40) {
    problemas.push(nome + ': sem `surface` e sem corpo - nao ha o que injetar no contexto');
  }
  if (String(fm.checavel || '').toLowerCase() === 'true' && !fm.guard) {
    problemas.push(nome + ': checavel: true sem `guard:` - promete bloqueio que nao existe');
  }
}

if (!problemas.length) process.exit(0);

const LF = String.fromCharCode(10);
process.stderr.write([
  '',
  'MEMORIA DO AGENTE QUEBRADA - bloqueando o fim do turno.',
  '',
  ...problemas.map((p) => '  - ' + p),
  '',
  'Cada item acima e um aprendizado que NUNCA vai chegar no contexto na hora certa.',
  'Corrija no arquivo em _learnings/ e feche o turno de novo.',
  '',
].join(LF));
process.exit(2);
