#!/usr/bin/env node
'use strict';
// recuperar-memoria.js - ETAPA 2 do loop. Roda em DOIS momentos e serve o mesmo proposito:
// colocar o que ja foi aprendido na frente do agente ANTES dele agir.
//
//   UserPromptSubmit  -> casa o ASSUNTO da mensagem com os `triggers` dos learnings
//   PreToolUse        -> casa o ARQUIVO que vai ser editado com a `area` dos learnings
//
// Vale pro Claude Code e pro Codex: os dois mandam JSON no stdin e aceitam a resposta em
// `hookSpecificOutput.additionalContext`. Emitir JSON nos dois casos e o denominador comum.
//
// NUNCA BLOQUEIA e NUNCA QUEBRA: qualquer falha sai 0 e em silencio. Hook que derruba a
// ferramenta e pior que hook que nao existe.

const path = require('node:path');
const L = require(path.join(__dirname, '..', 'lib', 'learnings.js'));

const MAX_ASSUNTO = 3;   // mais que isso vira parede de texto e o agente ignora tudo
const MAX_AREA = 2;

function lerEntrada() {
  try { return JSON.parse(require('node:fs').readFileSync(0, 'utf8')); } catch { return {}; }
}

function emitir(evento, contexto) {
  if (!contexto) process.exit(0);
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: evento,
      permissionDecision: 'allow',
      additionalContext: contexto,
    },
  }));
  process.exit(0);
}

/**
 * Dedup por sessao: repetir o mesmo learning a cada edicao treina o agente a ignorar o bloco.
 *
 * A chave inclui o PROJETO, nao so a sessao: sem isso, uma sessao que passa por dois projetos
 * (monorepo, repo irmao) marca o slug como "ja mostrado" no primeiro e cala a licao no segundo.
 * E um id de sessao reaproveitado herda o cache do run anterior, que e falha silenciosa.
 */
function jaMostrados(sessao, projeto) {
  const fs = require('node:fs');
  const os = require('node:os');
  const crypto = require('node:crypto');
  const marca = crypto.createHash('sha1').update(String(projeto || '')).digest('hex').slice(0, 8);
  const id = String(sessao || 'sem-sessao').replace(/[^a-zA-Z0-9_-]/g, '');
  const arq = path.join(os.tmpdir(), 'agente-learnings-' + id + '-' + marca + '.json');
  let vistos = [];
  try { vistos = JSON.parse(fs.readFileSync(arq, 'utf8')); } catch { /* primeira vez */ }
  return {
    filtrar: (lista) => lista.filter((l) => !vistos.includes(l.slug)),
    marcar: (lista) => {
      try {
        fs.writeFileSync(arq, JSON.stringify([...new Set(vistos.concat(lista.map((l) => l.slug)))]));
      } catch { /* cache e conveniencia, nunca requisito */ }
    },
  };
}

function linha(l, comFonte) {
  const guard = l.checavel ? ' (guard duro ativo - nao burle)' : '';
  return '- ' + l.titulo + ': ' + l.surface + guard + (comFonte ? ' [' + l.arquivo + ']' : '');
}

function main() {
  const dados = lerEntrada();
  const raiz = process.env.CLAUDE_PROJECT_DIR || dados.cwd || process.cwd();
  const projeto = L.acharRaiz(raiz) || L.raizPadrao();
  if (!projeto) process.exit(0);

  const todos = L.coletar(projeto);
  if (!todos.length) process.exit(0);

  const arquivoAlvo = dados.tool_input && dados.tool_input.file_path;
  const evento = dados.hook_event_name || (arquivoAlvo ? 'PreToolUse' : 'UserPromptSubmit');

  if (evento === 'PreToolUse') {
    if (!arquivoAlvo) process.exit(0);
    const cache = jaMostrados(dados.session_id, projeto);
    const novos = cache.filtrar(L.ordenar(L.casarPorArea(arquivoAlvo, todos, projeto))).slice(0, MAX_AREA);
    if (!novos.length) process.exit(0);
    cache.marcar(novos);
    emitir('PreToolUse', 'MEMORIA DO AGENTE - area "' + novos[0].area + '". Erro ja cometido aqui antes:\n'
      + novos.map((l) => linha(l, true)).join('\n')
      + '\nAplique antes de escrever a primeira linha.');
  }

  const casados = L.ordenar(L.casarPorTexto(dados.prompt || '', todos)).slice(0, MAX_ASSUNTO);
  if (!casados.length) process.exit(0);
  emitir('UserPromptSubmit', 'MEMORIA DO AGENTE - o assunto ja tem licao registrada:\n'
    + casados.map((l) => linha(l, true)).join('\n')
    + '\nRELEMBRE e aplique ANTES de agir.');
}

try { main(); } catch { process.exit(0); }
