#!/usr/bin/env node
// aprendi.mjs - ETAPA 5 do loop: transformar o que acabou de acontecer em memoria que volta.
//
// Uso (o agente chama sozinho quando voce corrige ele; voce tambem pode chamar):
//   node harness/aprendi.mjs "titulo curto do erro" --surface "a regra em 1 frase imperativa" \
//        --triggers "webhook, retry" --area "src/api" --severity alta [--guard "caminho/do/guard.js"]
//
// Se ja existe learning com o mesmo slug, ele NAO duplica: incrementa `hits` e atualiza a data.
// Erro que reincide vira UM learning mais forte (surfaca antes), nunca dois fracos concorrentes.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = path.dirname(fileURLToPath(import.meta.url));

function acharRaiz(inicio) {
  let dir = path.resolve(inicio);
  for (let i = 0; i < 12; i += 1) {
    if (fs.existsSync(path.join(dir, '_learnings'))) return dir;
    const pai = path.dirname(dir);
    if (pai === dir) break;
    dir = pai;
  }
  return null;
}

function opcao(nome, padrao = '') {
  const i = process.argv.indexOf('--' + nome);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : padrao;
}

function slugificar(titulo) {
  return titulo.toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

const titulo = process.argv[2];
if (!titulo || titulo.startsWith('--')) {
  console.error('uso: node harness/aprendi.mjs "titulo do aprendizado" --surface "regra em 1 frase" [--triggers "a, b"] [--area caminho] [--severity alta|media|baixa] [--guard caminho]');
  process.exit(1);
}

const projeto = acharRaiz(process.env.AGENTE_PROJETO_DIR || AQUI) || acharRaiz(process.cwd());
if (!projeto) {
  console.error('FALHA: nao achei a pasta _learnings/ subindo a arvore. Rode o instalar.mjs primeiro.');
  process.exit(1);
}

const hoje = new Date().toISOString().slice(0, 10);
const slug = slugificar(titulo);
const alvo = path.join(projeto, '_learnings', slug + '.md');

if (fs.existsSync(alvo)) {
  const atual = fs.readFileSync(alvo, 'utf8');
  const hits = Number((/^hits:\s*(\d+)/m.exec(atual) || [])[1] || 1) + 1;
  const novo = atual
    .replace(/^hits:.*$/m, 'hits: ' + hits)
    .replace(/^updated:.*$/m, 'updated: ' + hoje);
  fs.writeFileSync(alvo, /^hits:/m.test(atual) ? novo : novo.replace(/^---$/m, '---\nhits: ' + hits));
  console.log('REFORCADO (hits=' + hits + '): ' + path.relative(projeto, alvo));
  console.log('Erro que volta vira UM aprendizado mais forte, nunca dois fracos.');
  process.exit(0);
}

const surface = opcao('surface') || titulo;
const triggers = opcao('triggers').split(',').map((s) => s.trim()).filter(Boolean);
const area = opcao('area');
const severity = opcao('severity', 'media');
const guard = opcao('guard');

if (area && /^([A-Za-z]:|[/~])/.test(area)) {
  console.error('FALHA: --area tem que ser RELATIVA ao projeto (ex: src/api), nunca caminho absoluto.');
  console.error('Caminho absoluto funciona nesta maquina e para de funcionar na proxima, em silencio.');
  process.exit(1);
}

const fm = [
  '---',
  'titulo: ' + titulo,
  'created: ' + hoje,
  'updated: ' + hoje,
  'severity: ' + severity,
  'hits: 1',
  'checavel: ' + (guard ? 'true' : 'false'),
  guard ? 'guard: ' + guard : null,
  area ? 'area: ' + area : null,
  triggers.length ? 'triggers: [' + triggers.join(', ') + ']' : null,
  'surface: "' + surface.replace(/"/g, "'") + '"',
  '---',
].filter(Boolean).join('\n');

const corpo = [
  '',
  '# ' + titulo,
  '',
  '## O que aconteceu',
  '',
  '(o caso concreto: o que eu fiz, o que quebrou, como apareceu)',
  '',
  '## A licao',
  '',
  surface,
  '',
  '## Como aplicar da proxima vez',
  '',
  '(a acao especifica, nao a intencao generica)',
  '',
].join('\n');

fs.writeFileSync(alvo, fm + corpo);
console.log('APRENDIDO: ' + path.relative(projeto, alvo));
if (triggers.length) console.log('  volta quando o assunto tocar em: ' + triggers.join(', '));
if (area) console.log('  volta quando alguem editar: ' + area);
if (!triggers.length && !area) {
  console.log('  AVISO: sem `triggers` nem `area`, este aprendizado so volta por sorte.');
  console.log('  Os triggers derivados do titulo ajudam, mas declarar e o que faz voltar sempre.');
}
