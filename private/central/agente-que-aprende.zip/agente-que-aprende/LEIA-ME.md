# Agente que Aprende

Um agente que resolve cada problema mais rapido que o anterior, porque o que ele aprende volta
sozinho na hora certa - sem voce lembrar de nada.

## Instalar (1 minuto)

1. Descompacte esta pasta dentro do seu projeto.
2. Abra o Claude Code (ou o Codex) na pasta do projeto.
3. Diga: **"instala o agente que aprende"**.

O agente roda `node agente-que-aprende/instalar.mjs` e mostra o que escreveu. Prefere fazer na
mao? E o mesmo comando:

```bash
node agente-que-aprende/instalar.mjs
```

Reinicie a sessao depois. Node 18 ou superior, nenhuma dependencia pra baixar.

## O que ele faz

Todo trabalho em codigo passa por 5 etapas, e a quinta e a que quase todo agente pula:

1. **Analisar** - entender o problema e achar o contra-exemplo antes de acusar uma causa
2. **Recuperar memoria** - as licoes que casam com o assunto e com o arquivo entram no contexto
   ANTES dele agir, automaticamente
3. **Planejar e programar** - planta antes da linha, reuso antes de codigo novo
4. **Validar e testar** - prova com saida real, nunca "deve funcionar"
5. **Aprender e armazenar** - o erro corrigido vira memoria com gatilho de retorno

A diferenca em relacao a um arquivo de anotacoes: **ninguem precisa lembrar de abrir**. Um hook
injeta a licao certa no momento da decisao, por assunto e por area de arquivo.

## Como usar no dia a dia

| Voce faz | Acontece |
|---|---|
| `/codar resolve o timeout do webhook` | O ciclo completo, com a memoria da area de webhook ja no contexto |
| Corrige um erro do agente | Ele registra a licao (ou voce chama `/aprendi`) |
| Volta no mesmo tipo de problema semanas depois | A licao aparece sozinha, antes dele escrever a primeira linha |
| Mesmo erro reincide | O aprendizado ganha forca (`hits+1`) e passa a surfacar primeiro |

## O que fica no seu projeto

```
.agente/harness/        o motor + os hooks (zero dependencia)
.claude/commands/       /codar e /aprendi
.claude/skills/         a disciplina do ciclo
.claude/settings.json   os hooks ligados (mesclado, com backup do que ja existia)
.codex/hooks.json       o equivalente pro Codex
_learnings/             a memoria: um arquivo por licao, em markdown legivel
```

`_learnings/` e seu, em texto puro e versionavel no git. Se voce desinstalar
(`node agente-que-aprende/instalar.mjs --remover`), a memoria fica.

## Codex: dois passos que ninguem avisa

O Codex ignora projeto nao-confiado **em silencio** - a instalacao parece viva e nao faz nada.
Depois de instalar:

1. no `~/.codex/config.toml`, garanta o bloco que o instalador imprime (`trust_level = "trusted"`);
2. aprove os hooks em Configuracoes > Hooks (a confianca e por hash: mudou o arquivo, aprova de novo).

## A fronteira honesta

Isto **garante** duas coisas: o que foi registrado volta no gatilho certo, e erro mecanico com
guard nao se repete (o guard bloqueia).

Isto **nao garante** que toda licao vai ser capturada - decidir "isto merece virar aprendizado"
continua sendo julgamento humano. O que o sistema faz e tornar a captura barata (um comando) e o
retorno automatico (um hook), que e exatamente onde os outros sistemas de memoria morrem.

Nao e um modelo treinado, nao manda dado pra lugar nenhum, e nao roda nada em background. E um
motor de 200 linhas lendo markdown da sua propria pasta.

---

Feito pela [Infuser](https://useinfuser.com) - consultoria de IA.
