// ciclo.test.mjs - prova o loop inteiro num projeto descartavel:
// instalar -> aprender -> recuperar por assunto -> recuperar por area -> guard bloquear.
//
// Roda com:  node --test testes/ciclo.test.mjs
//
// Nao e teste de unidade do motor: e a prova de que o PRODUTO faz o que a capa promete.
// Instalador que so imprime "sucesso" e o modo de falha mais comum deste tipo de pacote.

import assert from 'node:assert/strict';
import cp from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const PACOTE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function projetoTemporario(t) {
  const raiz = fs.mkdtempSync(path.join(os.tmpdir(), 'agente-aprende-'));
  t.after(() => fs.rmSync(raiz, { recursive: true, force: true }));
  fs.cpSync(PACOTE, path.join(raiz, 'agente-que-aprende'), { recursive: true });
  return raiz;
}

function rodar(comando, args, cwd) {
  const r = cp.spawnSync(comando, args, { cwd, encoding: 'utf8', windowsHide: true });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || '') };
}

function instalar(raiz) {
  return rodar(process.execPath, [path.join(raiz, 'agente-que-aprende', 'instalar.mjs')], raiz);
}

test('instala, copia o motor e prova que a memoria carrega', (t) => {
  const raiz = projetoTemporario(t);
  const r = instalar(raiz);
  assert.equal(r.code, 0, r.out);
  assert.ok(fs.existsSync(path.join(raiz, '.agente', 'harness', 'lib', 'learnings.js')), 'motor nao foi copiado');
  assert.ok(fs.existsSync(path.join(raiz, '_learnings')), '_learnings nao foi criado');
  assert.match(r.out, /PROVA: \d+ aprendizado/, 'o instalador nao provou que a memoria carrega');
});

test('hooks entram no Claude e no Codex sem duplicar em duas instalacoes', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);
  instalar(raiz);

  const claude = JSON.parse(fs.readFileSync(path.join(raiz, '.claude', 'settings.json'), 'utf8'));
  const codex = JSON.parse(fs.readFileSync(path.join(raiz, '.codex', 'hooks.json'), 'utf8'));

  const conta = (obj) => (JSON.stringify(obj).match(/recuperar-memoria/g) || []).length;
  assert.equal(conta(claude.hooks.UserPromptSubmit), 1, 'duplicou hook no Claude');
  assert.equal(conta(codex.hooks.UserPromptSubmit), 1, 'duplicou hook no Codex');
  assert.ok(JSON.stringify(claude.hooks.Stop).includes('checar-learnings'), 'guard nao foi ligado');

  // O parser do Codex e estrito: qualquer chave desconhecida no topo derruba o arquivo INTEIRO
  // e nenhum hook carrega, com erro visivel so na tela de Hooks do app.
  assert.deepEqual(Object.keys(codex).sort(), ['description', 'hooks']);
});

test('config existente e preservada, com backup', (t) => {
  const raiz = projetoTemporario(t);
  fs.mkdirSync(path.join(raiz, '.claude'), { recursive: true });
  fs.writeFileSync(
    path.join(raiz, '.claude', 'settings.json'),
    JSON.stringify({ permissions: { allow: ['Bash(ls)'] }, hooks: { Stop: [{ hooks: [{ type: 'command', command: 'echo meu' }] }] } }, null, 2),
  );

  instalar(raiz);
  const claude = JSON.parse(fs.readFileSync(path.join(raiz, '.claude', 'settings.json'), 'utf8'));
  assert.deepEqual(claude.permissions.allow, ['Bash(ls)'], 'apagou config que nao era dele');
  assert.ok(JSON.stringify(claude.hooks.Stop).includes('echo meu'), 'apagou hook que ja existia');
  assert.ok(fs.readdirSync(path.join(raiz, '.claude')).some((f) => f.includes('.bak-')), 'nao fez backup');
});

test('aprende, e a licao volta por ASSUNTO', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);

  const r = rodar(process.execPath, [
    path.join(raiz, '.agente', 'harness', 'aprendi.mjs'),
    'Fila do rabbit precisa de dead letter',
    '--surface', 'Toda fila nasce com dead letter queue, senao mensagem quebrada some.',
    '--triggers', 'rabbit, fila, dead letter',
    '--area', 'src/fila',
    '--severity', 'alta',
  ], raiz);
  assert.equal(r.code, 0, r.out);

  const hook = path.join(raiz, '.agente', 'harness', 'hooks', 'recuperar-memoria.js');
  const surface = cp.spawnSync(process.execPath, [hook], {
    cwd: raiz,
    input: JSON.stringify({ hook_event_name: 'UserPromptSubmit', prompt: 'preciso mexer na fila do rabbit hoje', cwd: raiz }),
    encoding: 'utf8',
  });
  assert.match(surface.stdout, /dead letter/, 'a licao nao voltou pelo assunto: ' + surface.stdout);
});

test('a licao volta por AREA do arquivo editado, com caminho absoluto', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);
  rodar(process.execPath, [
    path.join(raiz, '.agente', 'harness', 'aprendi.mjs'),
    'Handler de pagamento sempre idempotente',
    '--surface', 'Todo handler de pagamento e idempotente por chave de requisicao.',
    '--area', 'src/pagamento',
  ], raiz);

  const hook = path.join(raiz, '.agente', 'harness', 'hooks', 'recuperar-memoria.js');
  const alvo = path.join(raiz, 'src', 'pagamento', 'webhook.ts');
  const surface = cp.spawnSync(process.execPath, [hook], {
    cwd: raiz,
    // id unico por execucao: o dedup guarda o que ja mostrou num arquivo do tmp, e id fixo
    // faria a segunda rodada da suite herdar o cache da primeira e falhar sem motivo real.
    input: JSON.stringify({ hook_event_name: 'PreToolUse', session_id: 'teste-area-' + process.pid, cwd: raiz, tool_input: { file_path: alvo } }),
    encoding: 'utf8',
  });
  assert.match(surface.stdout, /idempotente/, 'a licao nao voltou pela area: ' + surface.stdout);
});

test('reforca em vez de duplicar quando o erro reincide', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);
  const args = [path.join(raiz, '.agente', 'harness', 'aprendi.mjs'), 'Timeout curto demais no cliente http', '--surface', 'Timeout de cliente http nunca fica no default.'];
  rodar(process.execPath, args, raiz);
  const segundo = rodar(process.execPath, args, raiz);

  assert.match(segundo.out, /REFORCADO \(hits=2\)/, segundo.out);
  const arquivos = fs.readdirSync(path.join(raiz, '_learnings')).filter((f) => f.includes('timeout'));
  assert.equal(arquivos.length, 1, 'duplicou o aprendizado em vez de reforcar');
});

test('guard BLOQUEIA memoria quebrada (area absoluta)', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);
  fs.writeFileSync(path.join(raiz, '_learnings', 'quebrado.md'), [
    '---',
    'titulo: Learning com area absoluta',
    'area: C:/Users/alguem/projeto/src',
    'surface: "isto nunca vai casar na proxima maquina"',
    '---',
    '',
    '# Learning com area absoluta',
    '',
  ].join('\n'));

  const guard = rodar(process.execPath, [path.join(raiz, '.agente', 'harness', 'hooks', 'checar-learnings.js')], raiz);
  assert.equal(guard.code, 2, 'o guard deixou passar area absoluta');
  assert.match(guard.out, /area absoluta/);

  fs.rmSync(path.join(raiz, '_learnings', 'quebrado.md'));
  const limpo = rodar(process.execPath, [path.join(raiz, '.agente', 'harness', 'hooks', 'checar-learnings.js')], raiz);
  assert.equal(limpo.code, 0, 'o guard bloqueia estado saudavel: ' + limpo.out);
});

test('desinstalar tira os hooks e preserva a memoria', (t) => {
  const raiz = projetoTemporario(t);
  instalar(raiz);
  const r = rodar(process.execPath, [path.join(raiz, 'agente-que-aprende', 'instalar.mjs'), '--remover'], raiz);
  assert.equal(r.code, 0, r.out);

  const claude = JSON.parse(fs.readFileSync(path.join(raiz, '.claude', 'settings.json'), 'utf8'));
  assert.ok(!JSON.stringify(claude.hooks || {}).includes('recuperar-memoria'), 'hook ficou pra tras');
  assert.ok(fs.existsSync(path.join(raiz, '_learnings')), 'apagou a memoria do usuario');
});
