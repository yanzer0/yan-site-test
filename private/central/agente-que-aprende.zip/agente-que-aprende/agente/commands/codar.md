---
description: O ciclo de 5 etapas do agente que aprende - analisar, recuperar memoria, planejar e programar, validar, aprender.
argument-hint: "[a tarefa: bug, feature, refactor, revisao]"
---

# /codar

Voce vai executar a tarefa `$ARGUMENTS` seguindo o ciclo abaixo, **na ordem**, sem pular etapa.

A regra que sustenta o ciclo inteiro: **cada problema resolvido tem que deixar o proximo mais
facil**. Se voce terminar a tarefa e nao tiver mudado nada na memoria do projeto, o proximo
problema vai custar o mesmo que este custou.

---

## 1. Analisar

Antes de qualquer coisa, entenda o problema de verdade:

- Qual e o comportamento observado e qual e o esperado? Cite o arquivo e a linha.
- Isso e um bug, uma feature, um refactor ou uma decisao de arquitetura? Cada um pede rigor diferente.
- **Ache o contra-exemplo**: existe um caso parecido que FUNCIONA? Se existe e voce nao consegue
  explicar por que aquele funciona, sua causa esta incompleta e nao sai da sua boca ainda.

Separe sempre **o que voce VERIFICOU** (com o comando ou o `arquivo:linha` que provou) do que voce
**INFERIU**. Quem le nao tem como distinguir os dois, e vai tratar tudo como fato.

## 2. Recuperar memoria

O hook `recuperar-memoria` ja injetou no seu contexto os aprendizados que casam com o assunto e
com a area do arquivo. **Leia e aplique antes de escrever a primeira linha.**

Se aparecer um bloco `MEMORIA DO AGENTE`, ele nao e decorativo:

- item com `guard duro ativo` = existe codigo que BLOQUEIA a repeticao. Nao tente contornar.
- item sem guard = licao de julgamento. Aplique mesmo assim.

Nao apareceu nada e voce SABE que ja passou por isso? Isso e um sinal: falta trigger ou area no
aprendizado. Corrija o frontmatter dele na etapa 5.

## 3. Planejar e programar

Planta antes da linha. Para qualquer coisa maior que uma correcao obvia, escreva primeiro:

1. o que muda (arquivos e contratos),
2. o que pode quebrar junto (quem chama isso),
3. como voce vai provar que funcionou.

So entao escreva o codigo. Enquanto escreve:

- **Escada de reuso**: ja existe no repo? esta na stdlib? cabe em uma linha? Pare no primeiro
  degrau que resolve. Nunca adicione dependencia pro que 5 linhas fazem.
- **Dois chapeus**: ou voce ADICIONA comportamento, ou voce REFATORA. Nunca os dois no mesmo passo.
- Nome que diz a intencao, funcao com um trabalho so, erro com contexto (nunca `catch` vazio),
  entrada externa sempre validada, query sempre parametrizada, segredo nunca no codigo.

## 4. Validar e testar

Nao entregue nada com "deve funcionar":

- rode o teste, o build, o lint. Cole a saida REAL, nao o resumo dela.
- para bug: escreva o teste que FALHA antes do fix e passa depois. Sem isso voce nao provou a causa.
- deployou? confirme no caminho real (health, log, execucao), nunca pelo exit code do comando.

Se nao deu pra verificar, **diga isso explicitamente** e pare. Chute confiante e o erro mais caro
que um agente comete, porque ele e indistinguivel de uma resposta certa.

## 5. Aprender e armazenar

Esta e a etapa que quase todo agente pula, e e a unica que faz a proxima vez ser mais barata.

Registre quando: o usuario te corrigiu; voce quebrou a cara com um comportamento nao-obvio; voce
descobriu um gotcha que vai morder de novo.

```bash
node .agente/harness/aprendi.mjs "titulo curto do erro" \
  --surface "a regra em uma frase imperativa" \
  --triggers "palavra, outra palavra" \
  --area "src/caminho" \
  --severity alta
```

Duas decisoes importam mais que o texto:

- **`triggers` e `area`** sao o que faz o aprendizado VOLTAR. Sem eles, ele so volta por sorte.
- **Erro mecanico** (detectavel por regex, lint ou teste) nao vira so texto: vira **guard** que
  bloqueia a repeticao. Aprendizado que depende de eu lembrar e a versao fraca; guard e a forte.

Se o aprendizado ja existe, o comando reforca (`hits+1`) em vez de duplicar. Erro que reincide
vira UM aprendizado mais forte, que passa a surfacar antes dos outros.

---

## Fronteira honesta

Este ciclo **garante** que o que foi registrado volta no momento certo, e que erro mecanico com
guard nao se repete. Ele **nao garante** que voce vai capturar todo aprendizado - decidir "isto e
uma licao" continua sendo julgamento. O sistema torna a captura barata e o retorno automatico;
o gatilho continua sendo seu.
