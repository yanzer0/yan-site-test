---
description: Transforma a correcao que acabou de acontecer em memoria que volta sozinha no momento certo.
argument-hint: "[o que aprendemos agora]"
---

# /aprendi

Contexto: `$ARGUMENTS`

Voce vai registrar isto como aprendizado permanente do projeto. Siga os 4 passos.

## 1. Escreva a licao, nao o relato

Um aprendizado util responde tres coisas em uma frase cada:

- **O que aconteceu** (o caso concreto, com arquivo e linha se houver)
- **A licao** (a regra generalizada, em imperativo: "faca X", "nunca Y")
- **Como aplicar** (a acao especifica da proxima vez, nao a intencao generica)

"Ter mais cuidado com datas" nao e aprendizado. "Converter dia da semana em data sempre validando
com o calendario antes de gravar" e.

## 2. Escolha o gatilho de retorno

Esta e a decisao que define se o aprendizado serve pra alguma coisa:

- **`triggers`**: as palavras que, aparecendo na conversa, trazem a licao de volta. Prefira termos
  especificos ("webhook retry", "migration") a genericos ("codigo", "erro") - trigger generico casa
  em tudo e vira ruido, e ruido treina todo mundo a ignorar o bloco.
- **`area`**: o caminho cujo arquivo, ao ser editado, traz a licao de volta. **Sempre relativo**
  ao projeto (`src/api`), nunca absoluto - caminho absoluto funciona nesta maquina e morre na proxima.

## 3. Registre

```bash
node .agente/harness/aprendi.mjs "titulo curto" \
  --surface "a regra em uma frase imperativa" \
  --triggers "termo, outro termo" \
  --area "src/caminho" \
  --severity alta|media|baixa
```

Ja existe aprendizado sobre isso? O comando REFORCA (hits+1) em vez de duplicar, e ele passa a
surfacar na frente. Nao crie um segundo arquivo sobre o mesmo erro.

## 4. Se for mecanico, vire guard

Erro que uma regex, um lint ou um teste conseguem detectar **nao pode depender de eu lembrar**.
Escreva o guard, aponte `--guard <caminho>` no registro, e **prove**: force o estado errado de
proposito e confirme que o guard bloqueia (exit 2). Guard nao provado e guard que voce acha que tem.

Nao vire guard o que exige julgamento (tom, prioridade, decisao de design): guard que dispara no
caso legitimo e guard que a equipe aprende a burlar, e ai ele para de valer pro caso real tambem.
