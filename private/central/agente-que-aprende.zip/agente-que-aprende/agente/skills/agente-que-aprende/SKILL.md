---
name: agente-que-aprende
description: O ciclo de trabalho em codigo que fica mais rapido a cada problema resolvido - analisar, recuperar memoria, planejar e programar, validar e testar, aprender e armazenar. Use SEMPRE que for escrever, corrigir, refatorar ou revisar codigo, e SEMPRE que o usuario corrigir um erro seu (ai a etapa 5 e obrigatoria). Dispara em - "resolve esse bug", "implementa", "refatora", "revisa esse codigo", "por que isso quebrou", "voce errou", "nao e assim que funciona".
---

# Agente que Aprende

A maioria dos agentes resolve o mesmo problema com o mesmo custo pra sempre: cada sessao comeca do
zero, e o erro corrigido ontem volta amanha. A diferenca aqui e uma so - **o que foi aprendido
volta sozinho no momento da decisao**, sem ninguem precisar lembrar de procurar.

## O ciclo

| Etapa | O que voce faz | O que o sistema faz por voce |
|---|---|---|
| 1. Analisar | Entender o problema e achar o contra-exemplo | - |
| 2. Recuperar memoria | Ler e aplicar o bloco `MEMORIA DO AGENTE` | Hook injeta os aprendizados que casam com o assunto e a area |
| 3. Planejar e programar | Planta antes da linha; escada de reuso; dois chapeus | - |
| 4. Validar e testar | Provar com saida real, nunca "deve funcionar" | Guard bloqueia memoria quebrada no fim do turno |
| 5. Aprender e armazenar | Registrar a licao com gatilho de retorno | Reforca em vez de duplicar; sobe a prioridade do que reincide |

Detalhe operacional de cada etapa: comando `/codar`. Ritual de captura: comando `/aprendi`.

## As 3 regras que sustentam tudo

**1. Memoria que nao chega no momento da decisao nao existe.** Um `APRENDIZADOS.md` que ninguem
abre nao previne nada. Por isso o retorno e por hook (automatico), nunca por disciplina.

**2. Erro mecanico vira guard, erro de julgamento vira contexto.** Se uma regex, um lint ou um
teste conseguem detectar, escreva o guard e prove que ele bloqueia. Se depende de tom, prioridade
ou design, injete como contexto e aceite que e probabilistico. Confundir os dois produz guard que
dispara no caso legitimo - e guard assim a equipe aprende a burlar.

**3. Erro que reincide vira UM aprendizado mais forte, nunca dois fracos.** Registrar de novo o
mesmo erro reforca (`hits+1`) e sobe a prioridade dele na fila de surface.

## Quando a etapa 5 e obrigatoria

- o usuario te corrigiu (esse e o caso mais valioso: alguem pagou o custo do seu erro);
- um comportamento nao-obvio te mordeu (config estrita, API que mente, ordem de execucao);
- voce descobriu algo que so se aprende quebrando.

Nao registre: o que ja esta escrito no README, o que o `git log` conta melhor, e o que so valeu
pra esta conversa.

## Fronteira honesta

O sistema **garante** que o registrado volta no gatilho certo, e que o mecanico com guard nao se
repete. Ele **nao garante** que voce vai capturar todo aprendizado - "isto merece virar licao"
continua sendo julgamento seu. O que ele faz e tornar a captura barata e o retorno automatico,
que e onde a maioria dos sistemas de memoria morre.
