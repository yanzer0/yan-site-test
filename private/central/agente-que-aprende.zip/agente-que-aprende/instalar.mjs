#!/usr/bin/env node
// instalar.mjs - instala o Agente que Aprende no projeto.
//
// Roda no Claude Code e no Codex. Idempotente: rodar duas vezes nao duplica nada.
// Faz backup datado de qualquer config que ja exista antes de tocar nela.
//
//   node instalar.mjs                 instala no projeto (a pasta que contem este pacote)
//   node instalar.mjs --projeto X     instala em X
//   node instalar.mjs --dry           mostra o que faria, sem escrever
//   node instalar.mjs --remover       desinstala os hooks (a memoria em _learnings/ fica)
//
// NAO faz nada escondido: no fim ele lista o que escreveu e RODA UM TESTE que prova que a
// memoria volta. Instalador que so diz "instalado com sucesso" nao provou nada.

import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);

const PACOTE = path.dirname(fileURLToPath(import.meta.url));
const dry = process.argv.includes('--dry');
const remover = process.argv.includes('--remover');
const alvoArg = (() => {
  const i = process.argv.indexOf('--projeto');
  return i > -1 ? process.argv[i + 1] : null;
})();

const PROJETO = path.resolve(alvoArg || path.dirname(PACOTE));
const escritos = [];
const avisos = [];

function log(msg) { console.log(msg); }

function garantirPasta(p) {
  if (dry || fs.existsSync(p)) return;
  fs.mkdirSync(p, { recursive: true });
}

function backup(arquivo) {
  if (dry || !fs.existsSync(arquivo)) return null;
  const b = arquivo + '.bak-' + new Date().toISOString().slice(0, 10);
  fs.copyFileSync(arquivo, b);
  return b;
}

function escrever(destino, conteudo) {
  if (dry) { escritos.push(destino + ' (nao escrito: --dry)'); return; }
  garantirPasta(path.dirname(destino));
  fs.writeFileSync(destino, conteudo);
  escritos.push(path.relative(PROJETO, destino));
}

function copiarPasta(origem, destino) {
  for (const item of fs.readdirSync(origem, { withFileTypes: true })) {
    const de = path.join(origem, item.name);
    const para = path.join(destino, item.name);
    if (item.isDirectory()) { copiarPasta(de, para); continue; }
    if (dry) { escritos.push(path.relative(PROJETO, para) + ' (nao escrito: --dry)'); continue; }
    garantirPasta(path.dirname(para));
    fs.copyFileSync(de, para);
    escritos.push(path.relative(PROJETO, para));
  }
}

function lerJson(arquivo) {
  try { return JSON.parse(fs.readFileSync(arquivo, 'utf8')); } catch { return null; }
}

// ---------------------------------------------------------------- caminhos instalados
const DESTINO_HARNESS = path.join(PROJETO, '.agente', 'harness');
const HOOK = path.join(DESTINO_HARNESS, 'hooks', 'recuperar-memoria.js').split(path.sep).join('/');
const GUARD = path.join(DESTINO_HARNESS, 'hooks', 'checar-learnings.js').split(path.sep).join('/');
const CMD_HOOK = 'node "' + HOOK + '"';
const CMD_GUARD = 'node "' + GUARD + '"';

// ---------------------------------------------------------------- Claude Code
function instalarClaude() {
  const arquivo = path.join(PROJETO, '.claude', 'settings.json');
  const cfg = lerJson(arquivo) || {};
  cfg.hooks = cfg.hooks || {};

  const temHook = (evento, marca) => JSON.stringify(cfg.hooks[evento] || []).includes(marca);

  if (remover) {
    for (const ev of Object.keys(cfg.hooks)) {
      cfg.hooks[ev] = cfg.hooks[ev].filter((b) => !JSON.stringify(b).includes('.agente/harness'));
      if (!cfg.hooks[ev].length) delete cfg.hooks[ev];
    }
  } else {
    if (!temHook('UserPromptSubmit', 'recuperar-memoria')) {
      (cfg.hooks.UserPromptSubmit = cfg.hooks.UserPromptSubmit || [])
        .push({ hooks: [{ type: 'command', command: CMD_HOOK, timeout: 15 }] });
    }
    if (!temHook('PreToolUse', 'recuperar-memoria')) {
      (cfg.hooks.PreToolUse = cfg.hooks.PreToolUse || [])
        .push({ matcher: 'Edit|Write|NotebookEdit', hooks: [{ type: 'command', command: CMD_HOOK, timeout: 15 }] });
    }
    if (!temHook('Stop', 'checar-learnings')) {
      (cfg.hooks.Stop = cfg.hooks.Stop || [])
        .push({ hooks: [{ type: 'command', command: CMD_GUARD, timeout: 30 }] });
    }
  }

  const b = backup(arquivo);
  if (b) avisos.push('backup do settings do Claude: ' + path.basename(b));
  escrever(arquivo, JSON.stringify(cfg, null, 2) + '\n');
}

// ---------------------------------------------------------------- Codex
function instalarCodex() {
  const arquivo = path.join(PROJETO, '.codex', 'hooks.json');
  const cfg = lerJson(arquivo) || { description: 'Agente que Aprende - recuperar memoria + guard da memoria.', hooks: {} };
  cfg.hooks = cfg.hooks || {};

  // O parser do Codex e ESTRITO: campo desconhecido no topo derruba o ARQUIVO INTEIRO e NENHUM
  // hook carrega - e o erro so aparece na tela de Hooks do app, silencio total pro agente.
  // Por isso a saida so pode ter `description` e `hooks`, e nada de chave comentario.
  for (const chave of Object.keys(cfg)) {
    if (chave !== 'description' && chave !== 'hooks') delete cfg[chave];
  }

  const temHook = (evento, marca) => JSON.stringify(cfg.hooks[evento] || []).includes(marca);

  if (remover) {
    for (const ev of Object.keys(cfg.hooks)) {
      cfg.hooks[ev] = cfg.hooks[ev].filter((b) => !JSON.stringify(b).includes('.agente/harness'));
      if (!cfg.hooks[ev].length) delete cfg.hooks[ev];
    }
  } else {
    if (!temHook('UserPromptSubmit', 'recuperar-memoria')) {
      (cfg.hooks.UserPromptSubmit = cfg.hooks.UserPromptSubmit || [])
        .push({ hooks: [{ type: 'command', command: CMD_HOOK, timeout: 15, additionalContextLimit: 4000 }] });
    }
    if (!temHook('PreToolUse', 'recuperar-memoria')) {
      (cfg.hooks.PreToolUse = cfg.hooks.PreToolUse || [])
        .push({ matcher: 'Edit|Write', hooks: [{ type: 'command', command: CMD_HOOK, timeout: 15, additionalContextLimit: 4000 }] });
    }
  }

  const b = backup(arquivo);
  if (b) avisos.push('backup do hooks.json do Codex: ' + path.basename(b));
  escrever(arquivo, JSON.stringify(cfg, null, 2) + '\n');

  if (!remover) {
    avisos.push('CODEX: projeto nao-confiado e IGNORADO em silencio. Garanta no ~/.codex/config.toml:');
    avisos.push('       [projects."' + PROJETO.split(path.sep).join('/') + '"]');
    avisos.push('       trust_level = "trusted"');
    avisos.push('CODEX: depois aprove os 2 hooks em Configuracoes > Hooks (a confianca e por hash do arquivo).');
  }
}

// ---------------------------------------------------------------- prova
/**
 * Instalador que so imprime "sucesso" nao provou nada. Este carrega o motor recem-instalado,
 * le a memoria do projeto e confirma que o casamento por assunto realmente retorna alguma coisa.
 */
function provar() {
  const L = require(path.join(DESTINO_HARNESS, 'lib', 'learnings.js'));
  const todos = L.coletar(PROJETO);
  if (!todos.length) return 'nenhum aprendizado ainda (normal numa instalacao nova)';
  const alvo = todos[0].triggers[0] || todos[0].titulo;
  const casados = L.casarPorTexto(alvo, todos);
  if (!casados.length) throw new Error('o motor carregou ' + todos.length + ' aprendizado(s) mas nao casou nenhum com "' + alvo + '"');
  return todos.length + ' aprendizado(s) carregado(s); "' + alvo + '" casou ' + casados.length;
}

// ---------------------------------------------------------------- execucao
log('Agente que Aprende - instalacao');
log('projeto: ' + PROJETO);
log('');

if (!remover) {
  copiarPasta(path.join(PACOTE, 'harness'), DESTINO_HARNESS);
  copiarPasta(path.join(PACOTE, 'agente', 'commands'), path.join(PROJETO, '.claude', 'commands'));
  copiarPasta(path.join(PACOTE, 'agente', 'skills'), path.join(PROJETO, '.claude', 'skills'));

  const destinoLearnings = path.join(PROJETO, '_learnings');
  if (!fs.existsSync(destinoLearnings)) {
    copiarPasta(path.join(PACOTE, '_learnings'), destinoLearnings);
  } else {
    avisos.push('_learnings/ ja existia - preservado inteiro (memoria nunca e sobrescrita)');
  }
}

instalarClaude();
instalarCodex();

log(remover ? 'REMOVIDO dos hooks:' : 'ESCRITO:');
for (const e of escritos) log('  ' + e);
if (avisos.length) {
  log('');
  log('ATENCAO:');
  for (const a of avisos) log('  ' + a);
}

if (!remover && !dry) {
  log('');
  try { log('PROVA: ' + provar()); } catch (e) { log('PROVA FALHOU: ' + e.message); }
  log('');
  log('Reinicie a sessao do agente pra config nova valer.');
  log('Depois: peca "/codar <sua tarefa>" e, quando eu errar, corrija - o erro vira memoria.');
}
