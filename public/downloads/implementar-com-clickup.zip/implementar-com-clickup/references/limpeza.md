---
tags: [skill, clickup, git, limpeza]
status: vigente
created: 2026-10-11
updated: 2026-10-11
---

# Limpeza da frente concluída

Executar somente para recursos identificados da frente encerrada, com autorização vigente e integração comprovada. Não limpar recursos de outros projetos por parecerem antigos.

Neste guia, entidade significa o registro canônico do projeto definido em SKILL.md. Seguir os formatos locais de pendência e isolamento.

## Pré-condições

1. Identificar repositório, branch da frente, destino de integração, worktree e paths absolutos. Confirmar que não são o checkout principal, branch principal/protegida ou recurso compartilhado em uso.
2. Confirmar aceites e integração na referência atual do destino. Para merge comum, `git merge-base --is-ancestor <commit-da-frente> <destino>` fornece prova de ancestralidade. Quando houver remoto pertinente, conferir sua atualização; não usar tracking antigo como prova atual.
3. Em squash/rebase/cherry-pick, ancestralidade pode não servir. Conferir PR, commits e equivalência do conteúdo. Se permanecer dúvida, preservar e registrar o que falta confirmar. Não forçar exclusão para compensar ausência de prova.
4. Examinar arquivos rastreados, não rastreados e ignorados, processos que usam o checkout e sessões que dependem dele. Estado Git limpo não prova ausência de arquivos ignorados necessários.
5. Preservar evidências, dados únicos e arquivos necessários em destino durável fora do checkout. Registrar destino e conferir integridade. Dependências/builds regeneráveis não precisam virar cópia permanente só por existir.

No Windows, verificar que qualquer alvo de remoção/movimentação recursiva resolve dentro do diretório pretendido. Inspecionar junctions/symlinks para não alcançar recursos externos. Não compor exclusão atravessando PowerShell, cmd e outro shell.

## Worktree gerenciado pelo Codex

Consultar `list_artifacts` da conversa e usar `archive_worktree` com o identificador exato. O arquivamento guarda snapshot recuperável e remove o checkout; ignorados necessários devem ser preservados antes. A ferramenta pode recusar worktree principal, compartilhado, fixado ou com estruturas não suportadas. Respeitar a recusa.

Depois, verificar o caminho no disco, `git worktree list` e a branch. Arquivar um vínculo não prova por si só que a branch foi removida. Não usar `remove_artifact` de PR como mecanismo de limpar worktree.

## Worktree Git comum

Estando fora do checkout a remover, usar `git worktree remove <path-verificado>`. Depois, remover a branch local elegível com `git branch -d <branch-verificada>`. Comandos são modelos: substituir somente por valores conferidos, com quoting adequado. Não usar `--force`, `-D`, `reset --hard` ou `clean -fdx` como rotina.

`git worktree prune` limpa metadados obsoletos; não remove uma pasta existente. Antes de usá-lo, revisar o dry-run e confirmar que não alcança registros de outras frentes, dispositivos desmontados ou checkouts ainda necessários.

Remover branch remota apenas quando for da frente encerrada, não tiver outros consumidores e a autorização cobrir essa remoção. Deletar branch local não comprova remoção remota nem libera o espaço ocupado pela pasta.

Não apagar metadados Git manualmente para contornar recusa de política ou ferramenta. Registrar erro, alvo e resíduo, e preservar o restante.

## Recibo e limites

Registrar no fechamento:

- commit/PR integrado e destino;
- diretório removido, com verificação de ausência;
- worktree ausente no inventário;
- branch local/remota removida ou justificadamente preservada;
- arquivos/evidências preservados e local;
- resíduos e motivo exato, se houver.

Não afirmar espaço liberado em GB sem medir. Se a entrega estiver concluída mas a limpeza não, manter a entrega comprovada e abrir/atualizar uma pendência específica de limpeza na entidade. O encerramento administrativo não fica completo até limpar ou registrar uma decisão explícita de preservação.

Fontes: [git-worktree](https://git-scm.com/docs/git-worktree) e [git-branch](https://git-scm.com/docs/git-branch). Aplicar também as regras do repositório atual.
