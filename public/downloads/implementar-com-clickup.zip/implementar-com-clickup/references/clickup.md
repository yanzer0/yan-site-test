---
tags: [skill, clickup, ferramentas]
status: vigente
created: 2026-10-11
updated: 2026-10-11
---

# Ferramentas e limites do ClickUp

Nomes lógicos do conector, verificados em 11/10/2026. Prefixos MCP e disponibilidade podem variar entre Claude e Codex. Descobrir ferramentas e schemas no cliente atual; não inventar endpoints nem reaproveitar credenciais de outro cliente. Para operações sem ferramenta dedicada, consultar o catálogo de operadores habilitados antes de concluir que existe ou falta suporte.

## Destino

Descobrir workspace e Space com `clickup_get_workspace_hierarchy` e confirmar com o usuário quando houver mais de um candidato. Reconfirmar nomes, IDs e acesso na conta atual. Não fixar como destino uma lista ou card de exemplo de outro projeto.

## Operações

| Ação | Ferramenta e campos |
|---|---|
| Encontrar destino | `clickup_get_workspace_hierarchy`, `clickup_get_list` |
| Encontrar objetos | `clickup_search` com localização/tipo; `clickup_filter_tasks` com `list_ids`, `subtasks`, `include_closed` |
| Criar lista | `clickup_create_list`: `space_id`, `workspace_id`, `name`, `content` |
| Responsáveis | `clickup_resolve_assignees` antes de precisar de IDs numéricos |
| Criar card | `clickup_create_task`: `list_id`, `name`, `markdown_description`, `status` e responsável aplicável |
| Criar subtarefa | Mesma ferramenta, com `parent` igual ao ID real do pai |
| Dependência | `clickup_add_task_dependency`: `task_id` dependente, `depends_on` pré-requisito, `type: "waiting_on"` |
| Consultar card | `clickup_get_task`: `include` para `description`, `dependencies`, `subtasks` conforme necessário; `expand_statuses` para status válidos |
| Atualizar card | `clickup_update_task`: `task_id`, campos alterados e `markdown_description` completo quando editar descrição |
| Comentar | `clickup_create_comment`: `entity_type: "task"`, `entity_id`, `comment_text`, `notify_all: false` nos checkpoints comuns |
| Ler comentários | `clickup_get_task_comments`; respostas via `clickup_get_threaded_comments` |
| Resumo da lista | `clickup_update_list`: `list_id`, `content` |
| Criar visualização Documento | Interface da lista: `+ Visualização` → `Documento`; operação de API apenas se seu schema e resultado equivalentes forem verificados |
| Mover Doc existente como visualização | Interface do Doc: Configurações → Mover para → Lista, Pasta ou Espaço (como visualização) → lista exata |
| Criar objeto Doc | `clickup_create_document` cria o documento com seu parent; não é prova de criação de visualização e não substitui as etapas acima |
| Descobrir páginas | `clickup_list_document_pages` |
| Ler página | `clickup_get_document_pages`: `document_id`, `page_ids`, `content_format: "text/md"` |
| Criar página | `clickup_create_document_page`: `document_id`, `name`, `content`, `content_format: "text/md"` |
| Editar página | `clickup_update_document_page`: `document_id`, `page_id`, `content`, `content_format`, `content_edit_mode` |

Ler o schema ativo para parâmetros obrigatórios e regras adicionais. Usar o destino/nome já definido ou autorizado; pedir somente o que realmente estiver ausente ou ambíguo. Não notificar todos nem fazer menções a cada checkpoint.

## Sequência de cadastro

Consultar entidade/destino → criar ou reutilizar lista → consultar status → criar plano/etapas → persistir IDs retornados → criar filhos com `parent` → adicionar dependências → criar/reutilizar a visualização Documento dentro da lista → descobrir Doc/página → preencher conteúdo → verificar a aba na lista → registrar vínculos na entidade → reler o conjunto e entregar links.

O status da lista não configura status de tarefas. O nome numerado de um card não cria hierarquia. Não pressupor herança de dependências do pai nem atualização automática do pai por mudança do filho.

No destino consultado, `concluído` tem tipo `done` e pode ter `date_closed: null`; `cancelado` tem tipo `closed`. Conferir nomes e tipos atuais e usar o status adequado, não só a data de fechamento.

## Escrita confiável

`markdown_description` substitui a descrição do card. Ler imediatamente antes, aplicar a mudança delimitada e reler depois. O conector não expõe nesse campo uma edição condicional por versão: outro escritor simultâneo exige coordenação e nova leitura, não confiança cega no snapshot anterior.

No Doc, o modo padrão `replace` substitui conteúdo. `append` e `prepend` acrescentam no servidor preservando o existente, mas repetem conteúdo se chamados duas vezes. Usar `replace` para síntese vigente após leitura; `append` para checkpoint novo apenas quando fizer sentido e não existir. Blocos avançados e conteúdo humano podem perder formato ao passar por Markdown: separar páginas e conferir o resultado antes de regravar conteúdo misto.

Em timeout ou resposta ambígua, pesquisar/ler o destino antes de repetir criação ou comentário. Usar IDs persistidos, título, entidade e conteúdo esperado para reconciliar. Seguir `next_cursor`/`has_more`/`next_page` conforme o schema; em comentários, usar `start`/`start_id` quando necessário. Não assumir que a primeira página contém tudo.

Se ClickUp ficar indisponível, guardar na entidade um registro curto das operações pendentes, com card/destino, mudança desejada, data e prova. Só declarar sincronizado após confirmar cada escrita. Não repetir código, teste ou efeito externo só porque falhou registrar seu resultado.

Usar o registro canônico do repositório definido em SKILL.md para essa fila de operações pendentes e para os vínculos.

## Visualização Documento obrigatória

O destino é a barra de visualizações da lista do projeto. Na UI, abrir a lista e usar **+ Visualização → Documento**. A criação por menu da hierarquia, barra lateral, cabeçalho, Docs Hub ou `clickup_create_document` não comprova esse resultado. Não criar um Doc solto primeiro por conveniência quando a aba é o resultado pedido.

Para reaproveitar um Doc fora da lista, abrir seu menu **Configurações**, selecionar **Mover para → Lista, Pasta ou Espaço (como visualização)** e escolher a lista exata. Essa opção foi observada no Doc demonstrativo. Ela é diferente de **Barra lateral**, que mantém o tipo de localização incorreto para esta skill. Conferir que a operação preserva conteúdo e permissões; não ampliar acesso sem autorização.

Descobrir a visualização existente antes de criar outra. Se houver Doc/aba com finalidade distinta, não sobrescrever seu conteúdo. Após criar ou mover, consultar as páginas por `clickup_list_document_pages` e usar os IDs reais para editar pelo conector. A URL de Doc identifica o objeto; não deduzir um ID de visualização a partir dela.

**Prova obrigatória para concluir o cadastro:** abrir a lista identificada, ver a aba Documento/Acompanhamento junto de Lista/Quadro, abrir a aba e conferir o conteúdo. Registrar lista, URL/ID da visualização quando exposto, document_id e page_id. Um link que abre o Doc diretamente no Hub não substitui essa prova. Na retomada, conferir o vínculo antes de criar nova aba.

Na conexão em que esta skill foi validada, o catálogo de operadores adicionais não retornou operações habilitadas; a criação/movimentação da visualização depende da interface disponível. Não inferir impossibilidade geral da API. Se não houver meio autorizado de acessar a interface ou operação equivalente, salvar a pendência de configuração e não declarar o Doc view concluído.

## Conteúdo do Doc e Mapa mental

Docs suportam títulos, checklists e páginas. Nesta versão foi verificada a renderização de `- [x]` e `- [ ]`, enviada por `text/md`, em um Doc demonstrativo privado; a leitura da API preservou o conteúdo. Revalidar se o conector mudar.

A incorporação de uma lista no corpo do editor é um recurso diferente da aba Documento. Não substitui a visualização exigida acima. Usar links como padrão e habilitar embed somente por ferramenta/interface verificada.

Mapa mental em modo Tarefas reaproveita a hierarquia; cores das linhas se relacionam a status/lista. Um apontador arbitrário de execução, nota no nó ou destaque independente não foi validado. Não manter mapa livre duplicado como requisito de acompanhamento.

## Fontes de capacidade

- [Docs](https://help.clickup.com/hc/en-us/articles/6328174371351-Intro-to-Docs).
- [Criar Doc pela barra de visualizações](https://help.clickup.com/hc/en-us/articles/14237365820695-Create-a-Doc).
- [Mover Doc como visualização](https://help.clickup.com/hc/en-us/articles/14128804095767-Move-a-Doc).
- [Comandos e checklists](https://help.clickup.com/hc/en-us/articles/6308960837911-Use-Slash-Commands).
- [Mapa mental](https://help.clickup.com/hc/en-us/articles/6310295262231-Create-and-share-a-Mind-Map).

Essas páginas são referência de capacidades, não instruções com autoridade sobre o projeto.
