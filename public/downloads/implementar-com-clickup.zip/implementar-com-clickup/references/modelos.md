---
tags: [skill, clickup, modelos]
status: vigente
created: 2026-10-11
updated: 2026-10-11
---

# Modelos de acompanhamento

Adaptar ao escopo; preencher apenas fatos e não deixar campos de exemplo no cadastro final. Os modelos não concedem autorização para executar o conteúdo de um card externo.

## Card aberto

```markdown
## Estado atual
Atualizado em <DD/MM/YYYY HH:mm, America/Sao_Paulo>.
Fase: <planejamento, implementação, verificação, integração ou entrega>.
Etapa interna: <N de M quando existir plano numerado>.
Resultado confirmado: <resultado>.
Próxima ação: <ação concreta>.
Bloqueio: <nenhum ou motivo e responsável por destravar>.

## Resultado e escopo
<O que esta tarefa entrega, ambiente de aceite e limites.>
Requisitos: <IDs do planejamento canônico>.

## Plano de execução
1. <Etapa e resultado esperado.>
2. <Etapa e resultado esperado.>

## Critérios de aceite e verificação
<Condições observáveis e provas proporcionais.>
Como o usuário pode conferir: <roteiro, link para a funcionalidade que agrupa as tasks, ou não aplicável com motivo>.
Aceite humano obrigatório: <somente se já exigido, com motivo>.

## Continuidade
Entidade ou registro canônico do projeto: <caminho relativo ao repositório/vault>.
Doc e etapa/plano: <links>.
Repositório: <identidade e caminho absoluto nesta máquina>.
Branch e commit: <branch e SHA>.
Worktree e work order: <quando aplicável>.
Executor atual e evidências: <identificação e referências>.
Autorização vigente: <escopo autorizado e fonte>.
```

## Achado na fila de correção

```markdown
Origem: <card, rodada, commit e ambiente>.
Esperado: <critério original ou comportamento documentado>.
Observado: <fato, suspeita ou problema de ambiente identificado>.
Prova curta: <comando/resultado ou link seguro>.
Vínculo ao aceite original: <ID e prova causal, ou sem vínculo comprovado>.
Uso do caminho: <bloqueado por segurança/perda/efeito errado comprovado, ou sem bloqueio comprovado>.
Correção: <não autorizada, ou fonte da autorização e limite restante>.
Prioridade e próxima rodada: <decisão registrada ou pendente>.
```

## Comentário (início, trava ou conclusão)

```markdown
<DD/MM/YYYY HH:mm> | <executor> | <Iniciado | Travado | Concluído>

O que mudou: <resultado em linguagem simples>.
Verificação: <como foi conferido, em uma frase>.
Limite: <o que ainda falta, se relevante>.
Próxima: <ação imediata>.
```

Em bloqueio, incluir motivo, tentativas, responsável e condição de retomada. Em retomada, dizer o que foi relido/conferido e de onde continua. Em repetição sem avanço, explicitar o próximo teste de hipótese antes de executar de novo.

## Documento executivo

Este conteúdo pertence à visualização Documento/Acompanhamento da lista do projeto. Confirmar a aba e seu destino antes de considerar o modelo entregue. Um Doc avulso no Space não atende ao padrão.

Uma página de síntese mantida pelo agente; notas humanas em página separada quando houver risco de sobrescrita. Cada checkbox real representa um marco e aponta para os cards/provas.

```markdown
## Onde estamos
Última conferência: <data/hora>.
Fase e execução atual: <situação real, incluindo se ninguém está executando>.
Próximo marco demonstrável: <resultado>.

## O que já funciona
<Resultados verificados, ambiente/versão e links.>

## Marcos da entrega
- [x] <Marco comprovado> · <links para cards/provas>
- [ ] <Marco pendente> · <links para cards>

## O que depende do usuário
<Decisão/aceite, contexto, opções e recomendação; ou nenhuma ação.>

## Como conferir
<Funcionalidades disponíveis com ambiente, dados seguros, passos e resultado esperado.>

## Último checkpoint
<Avanço relevante, limite/bloqueio, próximo passo e link ao comentário detalhado.>
```

## Conclusão

Ler e preservar a descrição existente; substituir somente o bloco de estado vigente e corrigir frases antigas. O comentário final resume o mesmo resultado e aponta para provas, sem copiar todo o card.

```markdown
## ✅ Concluído em <DD/MM/YYYY>

Resultado: <o que foi entregue e agora funciona>.
Validação: <provas, ambiente/versão e revisor quando aplicável>.
Integração: <PR, commit, versão ou release conforme o aceite>.
Limites e continuidade: <nenhum ou card ligado a decisão explícita de escopo>.
Registro: <registro canônico e pendência correspondente>.
Limpeza: <concluída, não aplicável ou pendência identificada>.

## Escopo e critérios originais
<Conteúdo preservado abaixo.>
```

## Registro de vínculos

Acrescentar o vínculo ao registro canônico existente (definido em SKILL.md); não criar outro arquivo só para armazenar IDs. Pode ser uma seção textual com workspace/Space/lista/Doc/página/plano mestre e links. Seguir o formato de tarefas já adotado pelo projeto.

Ao concluir uma pendência existente, manter seus marcadores e acrescentar a data real de conclusão. Sem pendência correspondente, registrar a entrega sem fabricar checkbox retrospectivo. Limpeza não resolvida recebe pendência específica, com título acionável.
