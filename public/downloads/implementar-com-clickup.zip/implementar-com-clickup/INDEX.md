---
tags: [index, skill, clickup]
status: vigente
created: 2026-10-11
updated: 2026-10-11
---

# Implementar com ClickUp

| Fonte | Quando ler |
|---|---|
| [SKILL.md](SKILL.md) | Aplicar acompanhamento durante planejamento, execução, retomada e fechamento |
| [Ferramentas](references/clickup.md) | Antes da primeira escrita pelo conector |
| [Modelos](references/modelos.md) | Ao criar/atualizar card, comentário e Doc |
| [Limpeza](references/limpeza.md) | Ao encerrar recursos de uma frente integrada |

`agents/openai.yaml` contém somente metadados de descoberta do Codex. O comportamento comum a Claude e Codex vive nas fontes acima.
