# Segundo Cérebro - instalador

Esta pasta é o instalador. O seu cérebro será criado em outra pasta, que você escolhe durante a instalação.

## Como instalar (sem terminal)

1. Abra esta pasta no app do Claude (aba Code, "Select folder") ou no app do Codex.
2. Durante a instalação, ajuste o controle de permissões na barra inferior. No Claude para Mac, clique em "Aceitar edições" e escolha **Automático**. No Codex, escolha **Acesso completo** e confirme a tela de risco. Esse modo permite ao Codex executar comandos, usar a internet e editar qualquer arquivo do computador sem pedir novamente. O macOS ainda pode pedir uma permissão própria; nesse caso, clique em "Permitir".
3. Digite: **instala meu segundo cérebro**
4. Responda as duas perguntas (onde guardar e por qual app você vai usar).
5. Quando terminar, ele te diz a pasta criada e o que fazer em seguida: abrir essa pasta no app e digitar `/comecar` no Claude ou `$comecar` no Codex.

Automático no Claude e Acesso completo no Codex evitam interrupções durante a instalação. Depois, você pode manter essa configuração ou voltar ao modo de permissão que preferir.

No Codex, descompacte o ZIP e abra a pasta descompactada como projeto. Ao criar o projeto, adicione também a pasta onde o cérebro será criado, normalmente `Documentos`, em "Pastas de origem". O modo de aprovação não dá ao projeto acesso a uma pasta que não foi adicionada.

Depois de instalar e abrir o cérebro no Codex, execute `$comecar` e espere a primeira pergunta. Só então abra Configurações > Hooks, revise o projeto e ligue os 8 hooks. Antes do primeiro task, essa tela pode aparecer vazia; o arquivo já está instalado, mas o app ainda não descobriu a configuração do projeto. Depois de aprovar, continue a entrevista e abra uma conversa nova para que o contexto inicial também seja carregado automaticamente.

O pacote comercial incluirá um guia passo a passo com cada tela. Siga por ele quando estiver disponível.

## O que tem aqui

- `cerebro/`: o modelo do seu cérebro (notas, comandos e o harness que o mantém sozinho).
- `instalar.ps1` (Windows) e `instalar.sh` (macOS e Linux): garantem o Node, criam a pasta e ligam tudo. O agente roda isso por você.
- `instalar.mjs`: o instalador em si.
- `INSTALAR-AGENTE.md`: o roteiro que o agente segue.

Nada aqui manda dado pra lugar nenhum. Se precisar baixar o Node (a única dependência), ele vem do site oficial e é conferido contra a assinatura de lá.
