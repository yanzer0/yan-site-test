---
tags: [projeto, exemplo]
status: template
description: Modelo de nota de projeto. Copie para cada projeto novo (o /comecar faz isso por você).
prioridade: media
proximo_passo: A ação concreta seguinte, em uma frase
prazo:
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Nome do projeto

> Uma nota por projeto. O frontmatter acima é a verdade sobre status e próximo passo: é dele que o estado e o briefing derivam. Status sugeridos: `em-andamento`, `pausado`, `concluido`, `cancelado`. O `prazo` só entra com data real (AAAA-MM-DD).

## Contexto

O que é, por que existe, o que seria "pronto".

## Como escrever uma pendência

Uma linha por item, na seção `## Pendências` abaixo:

```markdown
- [ ] (trigger:site,landing) (prio:alta) (prazo:2026-10-01) Publicar a landing page :: falta o texto da seção de preços
- [ ] (trigger:contador) Mandar as notas de agosto pro contador
- [x] (feito:2026-09-01) Escolher o domínio :: fechamos meunegocio.com.br
```

`trigger` são as palavras que fazem a pendência aparecer sozinha quando o assunto surgir na conversa. `prazo` é a única fonte de urgência; sem data real, sem marcador. Resolvida: `- [x]` com `(feito:)`, nunca apague.

## Decisões e histórico

### AAAA-MM-DD - o que aconteceu

Uma linha por acontecimento relevante.

## Pendências

- [x] (feito:2026-01-10) Exemplo de pendência resolvida :: fica marcada com [x] e a data em (feito:)
