---
tags: [learning, indice]
description: Catálogo da memória de aprendizados, com os gatilhos que fazem cada lição voltar (gerado).
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Memória de aprendizados

> Cada arquivo nesta pasta é uma lição que volta sozinha: por assunto (`triggers`) quando a conversa tocar nele, ou por área (`area`) quando um arquivo daquela pasta for editado. Como escrever uma: [COMO-ESCREVER](COMO-ESCREVER.md). Pra registrar uma nova: `/aprendi`.

<!-- AUTO:LEARNINGS:START | gerado por .harness/refresh.js | não edite aqui: mude a nota de origem -->

_Preenchido na primeira sessão._

<!-- AUTO:LEARNINGS:END -->
