---
tags: [learning, harness]
description: Status e próximo passo moram na nota do projeto, nunca em lista solta ou no resumo.
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
severity: alta
hits: 1
checavel: false
area: _memory
triggers: [próximo passo, proximo passo, next steps, lista de tarefas, current-state, o que falta]
surface: "Grave status, próximo passo e pendência na NOTA do projeto (frontmatter + seção Pendências), nunca no current-state ou em lista solta: o estado gerado só reflete o que está na origem."
---

# O estado vivo mora na nota, não no resumo

## O que aconteceu

O erro mais comum de todo segundo cérebro: o agente escreve "próximos passos" numa lista solta no fim da sessão, a lista envelhece, e três semanas depois o briefing repete tarefas que já foram feitas. Ninguém confia mais no cérebro.

## A lição

Estado vivo (status, próximo passo, pendência, prazo) mora na nota da coisa: `_projetos/<slug>.md` com frontmatter e seção `## Pendências`. O `_memory/current-state.md` recebe só narrativa histórica; a parte gerada dele deriva das notas e não pode ser editada.

## Como aplicar da próxima vez

Antes de escrever "próximo passo" em qualquer lugar, abra a nota do projeto e atualize `proximo_passo` no frontmatter e a pendência correspondente. Resolveu? `- [x]` com `(feito:AAAA-MM-DD)`. O resumo se regenera sozinho.
