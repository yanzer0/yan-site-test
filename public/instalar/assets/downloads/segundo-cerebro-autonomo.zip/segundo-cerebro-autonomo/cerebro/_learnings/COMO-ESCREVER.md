---
tags: [learning, guia]
description: Como escrever um aprendizado que volta sozinho no momento certo.
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Como escrever um aprendizado

Cada arquivo `.md` nesta pasta é uma lição que volta sozinha. O frontmatter é o que faz ela voltar.

```markdown
---
tags: [learning, tema]
description: A frase que resume a lição (vai pro índice)
created: 2026-09-04
updated: 2026-09-04
severity: alta          # alta | media | baixa. Alta aparece primeiro
hits: 1                 # sobe sozinho quando o erro reincide
checavel: false         # true só quando existe um guard de verdade
area: _projetos         # RELATIVA ao cérebro, nunca absoluta. Opcional
triggers: [proposta, orçamento, preço]
surface: "A frase imperativa que vai ser injetada no contexto do agente."
---

# Nome curto e específico do erro

## O que aconteceu
O caso concreto.

## A lição
A regra generalizada, em imperativo.

## Como aplicar da próxima vez
A ação específica, não a intenção genérica.
```

## Os 3 campos que decidem se serve pra alguma coisa

**`surface`** é o texto que o agente lê. Escreva em imperativo, cabendo em uma linha. Se estiver vazio, o motor usa a primeira frase do corpo, que quase sempre é pior.

**`triggers`** trazem a lição de volta pelo ASSUNTO da conversa. Prefira termo específico (`proposta de orçamento`) a genérico (`erro`, `texto`). Trigger genérico casa em tudo, vira ruído, e ruído ensina a ignorar o bloco inteiro, inclusive quando ele está certo.

**`area`** traz a lição de volta pelo ARQUIVO que está sendo editado. Sempre relativa (`_projetos`). Caminho absoluto funciona nesta máquina e para de funcionar na próxima, em silêncio; por isso o guard bloqueia.

## Quando marcar `checavel: true`

Só quando existe um guard de verdade escrito e provado. `checavel: true` sem `guard:` é bloqueado pelo guard do cérebro, porque promete um bloqueio que não existe.
