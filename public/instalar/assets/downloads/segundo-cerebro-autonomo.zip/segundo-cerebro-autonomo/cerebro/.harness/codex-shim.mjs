#!/usr/bin/env node
// codex-shim.mjs - adaptador dos hooks do cerebro pro Codex.
//
// Os contratos de Claude Code e Codex sao quase identicos (stdin JSON + exit 2 = bloqueio). Este
// shim cobre as diferencas reais, sem tocar nos scripts:
//   1. CLAUDE_PROJECT_DIR nao existe no Codex -> injeta a raiz do cerebro na env.
//   2. SessionStart/UserPromptSubmit no Codex so aceitam JSON -> embrulha texto puro.
//   3. Stop no Codex transforma bloqueio em prompt de continuacao -> respeita stop_hook_active.
//   4. permissionDecision "ask" nao existe no Codex -> vira "deny" com o motivo.
//
// Uso (em .codex/hooks.json): "<node>" "<raiz>/.harness/codex-shim.mjs" <script.js>
// FAIL-OPEN: erro DO SHIM sai 0 calado. Bloqueio so quando o script real pede (exit 2).

import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HARNESS = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HARNESS, '..');
const EVENTOS_TEXTO = new Set(['SessionStart', 'UserPromptSubmit', 'SubagentStart']);

function lerStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function traduzir(stdout, evento) {
  const bruto = (stdout || '').trim();
  if (!bruto) return '';
  let parsed = null;
  try { parsed = JSON.parse(bruto); } catch { parsed = null; }

  if (!parsed) {
    // Texto puro: vira contexto onde o Codex aceita; nos outros eventos e descartado (o
    // bloqueio de verdade viaja por exit 2 + stderr, repassados a parte).
    return EVENTOS_TEXTO.has(evento)
      ? JSON.stringify({ hookSpecificOutput: { hookEventName: evento, additionalContext: bruto } })
      : '';
  }

  const hso = parsed.hookSpecificOutput;
  if (hso && hso.permissionDecision === 'ask') {
    parsed.hookSpecificOutput = {
      hookEventName: hso.hookEventName || evento,
      permissionDecision: 'deny',
      permissionDecisionReason: hso.permissionDecisionReason || 'o guard do cerebro pediu confirmacao',
    };
  }
  return JSON.stringify(parsed);
}

function main() {
  const script = process.argv[2];
  if (!script) process.exit(0);
  const extras = process.argv.slice(3);

  const stdin = lerStdin();
  let payload = {};
  try { payload = JSON.parse(stdin) || {}; } catch { payload = {}; }
  const evento = payload.hook_event_name || '';

  if ((evento === 'Stop' || evento === 'SubagentStop') && payload.stop_hook_active === true) process.exit(0);

  const alvo = path.join(HARNESS, script);
  if (!fs.existsSync(alvo)) process.exit(0);

  const res = spawnSync(process.execPath, [alvo, ...extras], {
    input: stdin,
    cwd: ROOT,
    encoding: 'utf8',
    timeout: 300000,
    env: { ...process.env, CLAUDE_PROJECT_DIR: ROOT, HARNESS_CLIENT: 'codex' },
  });
  if (res.error) process.exit(0);

  const saida = traduzir(res.stdout, evento);
  if (saida) process.stdout.write(saida);
  if (res.stderr) process.stderr.write(res.stderr);
  process.exit(res.status === 2 ? 2 : 0);
}

try { main(); } catch { process.exit(0); }
