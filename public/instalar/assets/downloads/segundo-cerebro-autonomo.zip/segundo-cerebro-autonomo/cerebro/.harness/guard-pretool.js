#!/usr/bin/env node
'use strict';
// guard-pretool.js - hook PreToolUse (todas as ferramentas). Pega o erro ANTES da acao:
//   1. busca ampla (Grep/Glob sem pasta) sem ter aberto o INDEX.md nesta sessao -> deny
//      auto-curavel: ler qualquer INDEX.md desarma pelo resto da sessao
//   2. Edit/Write dentro de um bloco AUTO -> deny (e gerado; a mudanca certa e na nota de origem)
//   3. pendencia com (prazo:)/(feito:) invalido ou (feito:) em item aberto -> deny com o formato
//
// Saida: JSON com hookSpecificOutput. FAIL-OPEN: qualquer erro do proprio guard sai 0 calado.
// Um guard que derruba a sessao e pior que guard nenhum.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const b = require('./lib/brain');

let dados = {};
try { dados = JSON.parse(fs.readFileSync(0, 'utf8')); } catch { process.exit(0); }

const tool = String(dados.tool_name || '');
const input = dados.tool_input || {};
const sessao = String(dados.session_id || 'sem-sessao').replace(/[^a-zA-Z0-9_-]/g, '');
const marcaIndex = path.join(os.tmpdir(), `cerebro-index-lido-${sessao}`);

function negar(motivo) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: motivo },
  }));
  process.exit(0);
}

function norm(p) {
  return path.resolve(String(p)).replace(/\\/g, '/').toLowerCase();
}

function aoLer() {
  if (path.basename(String(input.file_path || '')).toLowerCase() === 'index.md') {
    try { fs.writeFileSync(marcaIndex, '1'); } catch { /* marcador e conveniencia */ }
  }
  process.exit(0);
}

function aoBuscar() {
  if (fs.existsSync(marcaIndex)) process.exit(0);
  const p = String(input.path || '').trim();
  const ampla = !p || norm(p) === norm(b.ROOT);
  if (!ampla) process.exit(0);
  negar('Busca AMPLA no cérebro sem abrir o INDEX.md nesta sessão. O INDEX.md (raiz) lista toda nota '
    + 'com uma descrição: abra ele, localize o assunto e vá direto na nota. Depois de ler qualquer '
    + 'INDEX.md esta busca passa (o guard se desarma sozinho). Busca dentro de uma pasta específica passa direto.');
}

function pendenciaMalformada(texto) {
  const linhas = String(texto || '').split(/\r?\n/);
  for (let i = 0; i < linhas.length; i += 1) {
    const p = b.parsePendenciaLine(linhas[i], i + 1);
    if (!p) continue;
    if (p.prazo !== null && !b.isRealIsoDate(p.prazo)) return `(prazo:${p.prazo}) não é data real AAAA-MM-DD`;
    if (p.feito !== null && !b.isRealIsoDate(p.feito)) return `(feito:${p.feito}) não é data real AAAA-MM-DD`;
    if (p.feito !== null && !p.done) return '(feito:) só existe em pendência resolvida (- [x])';
  }
  return null;
}

function tocaBlocoAuto(atual, regioes) {
  const conteudoNovo = String(input.content !== undefined ? input.content : (input.new_string || ''));
  if (tool === 'Edit') {
    const alvo = String(input.old_string || '');
    const pos = alvo ? atual.indexOf(alvo) : -1;
    return pos >= 0 && regioes.some((r) => pos < r.end && pos + alvo.length > r.start);
  }
  if (tool === 'Write') {
    const novas = b.autoRegions(conteudoNovo);
    return regioes.some((r) => {
      const n = novas.find((x) => x.name === r.name);
      return !n || conteudoNovo.slice(n.start, n.end) !== atual.slice(r.start, r.end);
    });
  }
  return false;
}

function aoEscrever() {
  const arquivo = String(input.file_path || '');
  if (!arquivo || !norm(arquivo).startsWith(norm(b.ROOT) + '/')) process.exit(0);

  const atual = b.read(arquivo);
  if (atual !== null) {
    const regioes = b.autoRegions(atual);
    if (regioes.length && tocaBlocoAuto(atual, regioes)) {
      negar(`${path.basename(arquivo)} tem bloco(s) AUTO gerado(s) (${regioes.map((r) => r.name).join(', ')}) e esta escrita `
        + 'mexe dentro dele. É trabalho perdido: o próximo refresh sobrescreve. Mude a NOTA DE ORIGEM (a nota do '
        + 'projeto, a pendencia, o frontmatter) e o bloco reflete sozinho. Texto manual FORA dos marcadores pode ser editado.');
    }
  }

  const textos = tool === 'MultiEdit' && Array.isArray(input.edits)
    ? input.edits.map((e) => String(e.new_string || ''))
    : [String(input.content !== undefined ? input.content : (input.new_string || ''))];
  for (const t of textos) {
    const problema = pendenciaMalformada(t);
    if (problema) {
      negar(`Pendência fora do formato: ${problema}. Formato: "- [ ] (trigger:a,b) (prio:alta|media|baixa) `
        + '(prazo:AAAA-MM-DD) Título acionável :: detalhe". Resolvida: "- [x] (feito:AAAA-MM-DD) Título :: detalhe". '
        + 'prazo e feito só com data real; sem data, sem marcador.');
    }
  }
  process.exit(0);
}

try {
  if (tool === 'Read') aoLer();
  else if (tool === 'Grep' || tool === 'Glob') aoBuscar();
  else if (tool === 'Edit' || tool === 'Write' || tool === 'MultiEdit') aoEscrever();
} catch { /* fail-open */ }
process.exit(0);
