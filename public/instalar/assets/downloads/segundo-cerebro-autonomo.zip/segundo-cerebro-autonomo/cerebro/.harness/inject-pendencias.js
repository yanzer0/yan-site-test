#!/usr/bin/env node
'use strict';
// inject-pendencias.js - hook UserPromptSubmit. Casa as palavras da mensagem com os
// (trigger:...) das pendencias abertas e injeta as relevantes no contexto ANTES da resposta.
// Transforma "o agente geralmente lembra da pendencia" em "o agente sempre ve".
// Saida em texto puro (o Claude injeta como contexto; no Codex o shim embrulha em JSON).

const fs = require('node:fs');
const b = require('./lib/brain');

const MAX = 6;

let entrada = '';
try { entrada = fs.readFileSync(0, 'utf8'); } catch { /* sem stdin */ }
let prompt = '';
try { prompt = JSON.parse(entrada).prompt || ''; } catch { prompt = entrada; }
const texto = String(prompt).toLowerCase();
if (!texto.trim()) process.exit(0);

// casamento por limite de palavra: "nf" nao casa dentro de "informe".
function bate(trigger) {
  const re = new RegExp('(^|[^a-z0-9])' + trigger.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z0-9]|$)', 'i');
  return re.test(texto);
}

let itens = [];
try { itens = b.collectPendencias(); } catch { process.exit(0); }
const casadas = b.ordenarPendencias(itens.filter((p) => p.triggers.some(bate)));
if (!casadas.length) process.exit(0);

const linhas = casadas.slice(0, MAX).map((p) => {
  const u = b.urgencia(p);
  const meta = [u ? u.toUpperCase() : null, p.prazo ? `prazo ${p.prazo}` : null].filter(Boolean).join(', ');
  return `- ${p.title}${p.desc ? ` :: ${p.desc}` : ''}${meta ? ` (${meta})` : ''} - em ${p.source.rel}`;
});
process.stdout.write(
  '[Pendências do cérebro] A mensagem tocou em assunto com pendência ABERTA. Traga à tona antes de seguir '
  + '(pergunte se já resolveu; se sim, marque - [x] na nota de origem com (feito:AAAA-MM-DD)):\n'
  + linhas.join('\n') + '\n',
);
process.exit(0);
