#!/usr/bin/env node
'use strict';
// check.js - o guard duro do cerebro. Roda no Stop (fim do turno do agente) e como CLI.
// exit 2 = bloqueia o fim do turno ate o agente corrigir na nota de origem.
//
// So checa o que e MECANICO (regex, data, marcador). Nada de julgamento:
//   1. nota sem frontmatter (o indice e a memoria nao a enxergam)
//   2. pendencia com (prazo:) ou (feito:) que nao e data real; (feito:) em item aberto
//   3. marcador de supersessao (status superseded/arquivado/...) ou pasta _arquivo-morto/
//      -> superou, apaga; historico e o git, doc morto no cerebro e armadilha
//   4. aprendizado quebrado (area absoluta, checavel sem guard, sem surface)
// Avisos (nao bloqueiam): `updated` no futuro ou malformado, bloco AUTO desatualizado.

const b = require('./lib/brain');
const L = require('./lib/learnings');

const SUPERADO = new Set(['superseded', 'arquivado', 'archived', 'obsoleto']);
const FRONTMATTER_EXEMPLO = '---\\ntags: [tema]\\ndescription: uma frase sobre a nota\\ncreated: AAAA-MM-DD\\nupdated: AAAA-MM-DD\\n---';

const erros = [];
const avisos = [];

for (const file of b.walkMd()) {
  const rel = b.relPath(file);
  if (rel.includes('_arquivo-morto/')) {
    erros.push(`${rel}: pasta _arquivo-morto não existe nesta lei. Superou? Reescreva o trecho no doc vivo e apague este.`);
    continue;
  }
  if (!b.isNote(file)) continue;
  const note = b.readNote(file);
  if (!note) continue;

  if (note.fm === null) {
    erros.push(`${rel}: sem frontmatter. Toda nota começa com ${FRONTMATTER_EXEMPLO}`);
    continue;
  }
  const status = String(note.fm.status || '').toLowerCase();
  if (SUPERADO.has(status)) {
    erros.push(`${rel}: status "${status}" é marcador de supersessão. Superou? Carregue o "o que mudou" pro doc vivo e apague este.`);
  }
  if (note.fm.superseded_by !== undefined) {
    erros.push(`${rel}: chave superseded_by não existe nesta lei. Apague o doc superado em vez de marcá-lo.`);
  }
  const updated = note.fm.updated;
  if (updated && !b.isRealIsoDate(updated)) avisos.push(`${rel}: updated não é data AAAA-MM-DD (${updated})`);
  else if (updated && b.daysUntil(updated) > 0) avisos.push(`${rel}: updated no futuro (${updated})`);

  for (const p of b.parsePendencias(note.content)) {
    const onde = `${rel}:${p.line}`;
    if (p.prazo !== null && !b.isRealIsoDate(p.prazo)) erros.push(`${onde}: (prazo:${p.prazo}) não é data AAAA-MM-DD. Sem data real, tire o marcador.`);
    if (p.feito !== null && !b.isRealIsoDate(p.feito)) erros.push(`${onde}: (feito:${p.feito}) não é data AAAA-MM-DD.`);
    if (p.feito !== null && !p.done) erros.push(`${onde}: (feito:) em pendência ABERTA. Resolveu? Marque - [x]. Não resolveu? Tire o (feito:).`);
    if (!p.title) erros.push(`${onde}: pendência sem texto.`);
  }
}

for (const problema of L.validar()) erros.push(problema);

try {
  const r = require('./refresh').run({ dryRun: true });
  for (const e of r.errors) avisos.push(`gerador com erro: ${e}`);
  for (const c of r.changed) avisos.push(`bloco AUTO desatualizado (o proximo refresh corrige): ${c}`);
} catch (e) {
  avisos.push(`refresh nao rodou: ${e.message}`);
}

for (const a of avisos) process.stderr.write(`aviso: ${a}\n`);

if (!erros.length) {
  if (!process.argv.includes('--quiet')) process.stdout.write('check: ok\n');
  process.exit(0);
}

process.stderr.write([
  '',
  `HARNESS BLOQUEOU O FIM DO TURNO: ${erros.length} problema(s) mecânico(s) no cérebro.`,
  '',
  ...erros.map((e) => `  - ${e}`),
  '',
  'Corrija na NOTA DE ORIGEM (nunca dentro de bloco AUTO) e encerre o turno de novo.',
  '',
].join('\n'));
process.exit(2);
