'use strict';
// Gera o bloco AUTO:LEARNINGS de _learnings/INDEX.md: o catalogo da memoria de aprendizados
// (gatilhos por assunto, area, severidade, guard). Fonte: frontmatter de _learnings/*.md.
const path = require('node:path');
const b = require('../lib/brain');
const L = require('../lib/learnings');

const RANK = { alta: 0, media: 1, baixa: 2 };

function cell(s) {
  return String(s || '').replace(/\|/g, '/').replace(/\r?\n/g, ' ').trim();
}

module.exports = function gerarLearnings() {
  const itens = L.coletar().sort((a, c) => (RANK[a.severity] ?? 1) - (RANK[c.severity] ?? 1)
    || (Number(c.checavel) - Number(a.checavel))
    || a.slug.localeCompare(c.slug));
  const linhas = [];
  if (!itens.length) {
    linhas.push('_Nenhum aprendizado ainda. Quando eu errar e você corrigir, rode `/aprendi`._');
  } else {
    linhas.push('| Aprendizado | Sev | Guard | Área | Gatilhos (assunto) | Vezes |');
    linhas.push('|---|---|---|---|---|---|');
    for (const l of itens) {
      const guard = l.checavel ? 'duro' : '-';
      const area = l.area ? `\`${l.area}\`` : '-';
      const gatilhos = l.triggers.slice(0, 6).join(', ') || '-';
      linhas.push(`| [${cell(l.titulo).slice(0, 72)}](${l.slug}.md) | ${l.severity} | ${guard} | ${area} | ${cell(gatilhos)} | ${l.hits} |`);
    }
    linhas.push('');
    linhas.push(`_${itens.length} aprendizado(s) · ${itens.filter((x) => x.checavel).length} com guard duro · ${itens.filter((x) => x.area).length} com área._`);
  }
  return {
    file: path.join(b.ROOT, '_learnings', 'INDEX.md'),
    name: 'LEARNINGS',
    body: linhas.join('\n').trim(),
    insertAfter: /^# .*$/m,
  };
};
