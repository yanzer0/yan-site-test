#!/usr/bin/env node
'use strict';
// session-start.js - hook SessionStart. Regenera o que e derivado e entrega ao agente, em poucas
// linhas, a foto do cerebro: quantos projetos, quantas pendencias, o que ler antes de agir.
// Saida em texto puro (o Claude injeta como contexto; no Codex o shim embrulha em JSON).

const path = require('node:path');
const b = require('./lib/brain');
const refresh = require('./refresh');

const resultado = refresh.run();
const projetos = b.collectEntities('_projetos').filter((p) => !/conclu|cancel|pausad/i.test(p.status));
const pendencias = b.collectPendencias();
const urgentes = pendencias.filter((p) => b.urgencia(p)).length;
const lei = b.read(path.join(b.ROOT, 'CLAUDE.md')) || '';
const comecar = process.env.HARNESS_CLIENT === 'codex' ? '$comecar' : '/comecar';

const linhas = [
  `[Segundo Cérebro] Hoje é ${b.isoToday()}. ${projetos.length} projeto(s) ativo(s), ${pendencias.length} pendência(s) aberta(s)`
  + `${urgentes ? ` (${urgentes} urgente(s) ou vencida(s))` : ''}. Estado vivo em _memory/current-state.md; navegação em INDEX.md `
  + '(abra antes de procurar qualquer coisa). Harness ativo: índices e estado gerados, guards no fim do turno, memória de aprendizados por gatilho.',
];
if (/\[SEU NOME\]/.test(lei)) {
  linhas.push(`Este cérebro ainda não foi configurado: antes de qualquer outra coisa, proponha rodar ${comecar}.`);
}
for (const erro of resultado.errors) linhas.push(`Harness com erro no refresh: ${erro}`);

process.stdout.write(linhas.join('\n') + '\n');
process.exit(0);
