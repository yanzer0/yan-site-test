#!/usr/bin/env node
'use strict';
// pre-compact.js - hook PreCompact. Registra que houve compactacao de contexto: a partir dela o
// que o agente "lembra" e resumo, e referencia a comando ou estado deve ser conferida na nota
// antes de repetir uma acao. Best-effort: exit 0 sempre.

const fs = require('node:fs');
const path = require('node:path');

try {
  let gatilho = '?';
  try { gatilho = (JSON.parse(fs.readFileSync(0, 'utf8')) || {}).trigger || '?'; } catch { /* sem stdin */ }
  const pasta = path.join(__dirname, 'state');
  fs.mkdirSync(pasta, { recursive: true });
  fs.appendFileSync(path.join(pasta, 'compactacoes.log'), `${new Date().toISOString()} compactacao (${gatilho})\n`, 'utf8');
} catch { /* best-effort */ }
process.exit(0);
