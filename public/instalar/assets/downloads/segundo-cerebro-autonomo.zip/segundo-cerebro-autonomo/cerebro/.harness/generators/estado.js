'use strict';
// Gera o bloco AUTO:ESTADO de _memory/current-state.md: a foto atual derivada das notas
// (projetos, pipeline, pendencias por urgencia, prazos, recentes). Nunca e escrito a mao.
const path = require('node:path');
const b = require('../lib/brain');

const MAX_PENDENCIAS = 15;

function cell(s) {
  return String(s || '').replace(/\|/g, '/').replace(/\r?\n/g, ' ').trim() || '-';
}

function prazoTexto(prazo) {
  if (!prazo) return '';
  const d = b.daysUntil(prazo);
  if (d === null) return ` (prazo ${prazo})`;
  if (d < 0) return ` (prazo ${prazo}, vencido há ${-d}d)`;
  if (d === 0) return ` (prazo ${prazo}, HOJE)`;
  return ` (prazo ${prazo}, em ${d}d)`;
}

function flag(p) {
  const u = b.urgencia(p);
  if (u === 'vencida') return '[VENCIDA] ';
  if (u === 'urgente') return '[URGENTE] ';
  if (p.bloqueado) return `[BLOQUEADA: ${p.bloqueado}] `;
  return p.prio === 'alta' ? '[alta] ' : '';
}

function tabelaEntidades(L, titulo, itens) {
  L.push(`### ${titulo}`, '');
  L.push('| Nome | Status | Prioridade | Próximo passo | Prazo | Pend. |');
  L.push('|---|---|---|---|---|---|');
  for (const e of itens) {
    L.push(`| [${cell(e.title)}](${e.rel}) | ${cell(e.status)} | ${cell(e.prioridade)} | ${cell(e.proximoPasso)} | ${cell(e.prazo)} | ${e.pendenciasAbertas} |`);
  }
  L.push('');
}

module.exports = function gerarEstado() {
  const L = [];
  L.push('> Estado vivo, derivado das notas. Não edite aqui: mude a nota do projeto ou da pendência e este bloco reflete sozinho.');
  L.push('');

  const projetos = b.collectEntities('_projetos');
  if (projetos.length) tabelaEntidades(L, 'Projetos', projetos);
  else L.push('### Projetos', '', '_Nenhum projeto ainda. Crie uma nota em `_projetos/` (modelo em `_projetos/_exemplo.md`) ou rode `/comecar`._', '');

  const pipeline = b.collectEntities('_pipeline');
  if (pipeline.length) tabelaEntidades(L, 'Pipeline', pipeline);

  const pendencias = b.ordenarPendencias(b.collectPendencias());
  L.push(`### Pendências abertas (${pendencias.length})`, '');
  if (!pendencias.length) {
    L.push('_Nenhuma._');
  } else {
    for (const p of pendencias.slice(0, MAX_PENDENCIAS)) {
      L.push(`- ${flag(p)}${p.title}${prazoTexto(p.prazo)} - [${p.source.title}](${p.source.rel})`);
    }
    if (pendencias.length > MAX_PENDENCIAS) {
      L.push(`- ... e mais ${pendencias.length - MAX_PENDENCIAS} em [_memory/pendencias.md](_memory/pendencias.md)`);
    }
  }
  L.push('');

  const decisoes = b.recentNotes('_decisions', 7);
  const aprendizados = b.recentNotes('_learnings', 7);
  if (decisoes.length || aprendizados.length) {
    L.push('### Últimos 7 dias', '');
    if (decisoes.length) L.push('- Decisões: ' + decisoes.map((n) => `[${cell(n.title)}](${n.rel})`).join(' · '));
    if (aprendizados.length) L.push('- Aprendizados: ' + aprendizados.map((n) => `[${cell(n.title)}](${n.rel})`).join(' · '));
    L.push('');
  }

  return {
    file: path.join(b.ROOT, '_memory', 'current-state.md'),
    name: 'ESTADO',
    body: L.join('\n').trim(),
    insertAfter: /^# .*$/m,
  };
};
