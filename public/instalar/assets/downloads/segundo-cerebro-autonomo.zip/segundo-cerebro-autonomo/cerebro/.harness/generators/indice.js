'use strict';
// Gera o bloco AUTO:INDICE do INDEX.md: toda nota do cerebro, por pasta, com a descricao que
// vem do frontmatter (`description`) ou da primeira linha util. Indice gerado nao tem orfao.
const path = require('node:path');
const b = require('../lib/brain');

const ORDEM = ['(raiz)', '_memory', '_knowledge', '_projetos', '_pipeline', '_learnings', '_decisions', '_sessions'];
const MAX_SESSOES = 10;

function rank(pasta) {
  const i = ORDEM.indexOf(pasta);
  return i < 0 ? 50 : i;
}

function cell(s) {
  return String(s || '').replace(/\|/g, '/').replace(/\r?\n/g, ' ').trim();
}

module.exports = function gerarIndice() {
  const grupos = new Map();
  for (const file of b.walkMd()) {
    if (!b.isNote(file)) continue;
    const note = b.readNote(file);
    if (!note) continue;
    const top = note.rel.includes('/') ? note.rel.split('/')[0] : '(raiz)';
    if (!grupos.has(top)) grupos.set(top, []);
    grupos.get(top).push(note);
  }

  const pastas = [...grupos.keys()].sort((a, c) => rank(a) - rank(c) || a.localeCompare(c));
  const L = [];
  let total = 0;
  for (const pasta of pastas) {
    const notas = grupos.get(pasta).sort((a, c) => a.rel.localeCompare(c.rel));
    total += notas.length;
    const mostrar = pasta === '_sessions'
      ? notas.slice().sort((a, c) => c.rel.localeCompare(a.rel)).slice(0, MAX_SESSOES)
      : notas;
    L.push(`### ${pasta}`, '', '| Nota | Sobre |', '|---|---|');
    for (const n of mostrar) L.push(`| [${cell(n.title)}](${n.rel}) | ${cell(n.description) || ' '} |`);
    if (mostrar.length < notas.length) L.push(`| ... | e mais ${notas.length - mostrar.length} sessão(ões) antigas na pasta |`);
    L.push('');
  }
  L.unshift(`_${total} nota(s). Pra mudar uma descrição, edite o campo \`description\` no frontmatter da própria nota._`, '');

  return {
    file: path.join(b.ROOT, 'INDEX.md'),
    name: 'INDICE',
    body: L.join('\n').trim(),
    insertAfter: /^# .*$/m,
  };
};
