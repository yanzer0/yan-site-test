#!/usr/bin/env node
'use strict';
// inject-learnings.js - a memoria de aprendizados chegando ANTES da acao. Dois momentos:
//   UserPromptSubmit      -> casa o ASSUNTO da mensagem com os `triggers` dos aprendizados
//   PreToolUse (Edit|Write) -> casa o ARQUIVO que vai ser editado com a `area` dos aprendizados
//
// Emite JSON (hookSpecificOutput.additionalContext): Claude e Codex aceitam nos dois eventos.
// NUNCA bloqueia e NUNCA quebra: qualquer falha sai 0 em silencio.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const b = require('./lib/brain');
const L = require('./lib/learnings');

const MAX_ASSUNTO = 3; // mais que isso vira parede de texto e o agente ignora tudo
const MAX_AREA = 2;

function lerEntrada() {
  try { return JSON.parse(fs.readFileSync(0, 'utf8')); } catch { return {}; }
}

function emitir(evento, contexto) {
  if (!contexto) process.exit(0);
  const saida = { hookEventName: evento, additionalContext: contexto };
  if (evento === 'PreToolUse') saida.permissionDecision = 'allow';
  process.stdout.write(JSON.stringify({ hookSpecificOutput: saida }));
  process.exit(0);
}

// Dedup por sessao: repetir o mesmo aprendizado a cada edicao treina o agente a ignorar o bloco.
function jaMostrados(sessao) {
  const marca = crypto.createHash('sha1').update(b.ROOT).digest('hex').slice(0, 8);
  const id = String(sessao || 'sem-sessao').replace(/[^a-zA-Z0-9_-]/g, '');
  const arquivo = path.join(os.tmpdir(), `cerebro-learnings-${id}-${marca}.json`);
  let vistos = [];
  try { vistos = JSON.parse(fs.readFileSync(arquivo, 'utf8')); } catch { /* primeira vez */ }
  return {
    filtrar: (lista) => lista.filter((l) => !vistos.includes(l.slug)),
    marcar: (lista) => {
      try { fs.writeFileSync(arquivo, JSON.stringify([...new Set(vistos.concat(lista.map((l) => l.slug)))])); } catch { /* cache */ }
    },
  };
}

function linha(l) {
  const guard = l.checavel ? ' (guard duro ativo: não burle)' : '';
  return `- ${l.titulo}: ${l.surface}${guard} [${l.arquivo}]`;
}

function main() {
  const dados = lerEntrada();
  const todos = L.coletar();
  if (!todos.length) process.exit(0);

  const arquivoAlvo = dados.tool_input && dados.tool_input.file_path;
  const evento = dados.hook_event_name || (arquivoAlvo ? 'PreToolUse' : 'UserPromptSubmit');

  if (evento === 'PreToolUse') {
    if (!arquivoAlvo) process.exit(0);
    const cache = jaMostrados(dados.session_id);
    const novos = cache.filtrar(L.ordenar(L.casarPorArea(arquivoAlvo, todos))).slice(0, MAX_AREA);
    if (!novos.length) process.exit(0);
    cache.marcar(novos);
    emitir('PreToolUse', `MEMÓRIA DO CÉREBRO - área "${novos[0].area}". Erro já cometido aqui antes:\n`
      + novos.map(linha).join('\n')
      + '\nAplique antes de escrever a primeira linha.');
  }

  const casados = L.ordenar(L.casarPorTexto(dados.prompt || '', todos)).slice(0, MAX_ASSUNTO);
  if (!casados.length) process.exit(0);
  emitir('UserPromptSubmit', 'MEMÓRIA DO CÉREBRO - o assunto já tem lição registrada:\n'
    + casados.map(linha).join('\n')
    + '\nRELEMBRE e aplique ANTES de agir.');
}

try { main(); } catch { process.exit(0); }
