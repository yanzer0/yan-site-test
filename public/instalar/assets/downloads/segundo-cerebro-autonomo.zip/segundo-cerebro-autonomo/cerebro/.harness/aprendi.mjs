#!/usr/bin/env node
// aprendi.mjs - transforma o que acabou de acontecer em memoria que volta sozinha.
//
// O comando /aprendi escreve a nota direto; este script e o atalho pra quem tem Node na mao:
//   node .harness/aprendi.mjs "titulo curto do erro" --surface "a regra em 1 frase imperativa" \
//        --triggers "webhook, retry" --area "_projetos" --severity alta [--guard "caminho"]
//
// Ja existe aprendizado com o mesmo slug? NAO duplica: soma 1 em `hits` e atualiza a data.
// Erro que reincide vira UM aprendizado mais forte (surfaca antes), nunca dois fracos.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HARNESS = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HARNESS, '..');

function opcao(nome, padrao = '') {
  const i = process.argv.indexOf('--' + nome);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : padrao;
}

function slugificar(titulo) {
  return titulo.toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

const titulo = process.argv[2];
if (!titulo || titulo.startsWith('--')) {
  console.error('uso: node .harness/aprendi.mjs "titulo do aprendizado" --surface "regra em 1 frase" [--triggers "a, b"] [--area pasta] [--severity alta|media|baixa] [--guard caminho]');
  process.exit(1);
}

const pasta = path.join(ROOT, '_learnings');
fs.mkdirSync(pasta, { recursive: true });
const hoje = new Date().toISOString().slice(0, 10);
const slug = slugificar(titulo);
const alvo = path.join(pasta, slug + '.md');

if (fs.existsSync(alvo)) {
  const atual = fs.readFileSync(alvo, 'utf8');
  const hits = Number((/^hits:\s*(\d+)/m.exec(atual) || [])[1] || 1) + 1;
  const comHits = /^hits:/m.test(atual) ? atual.replace(/^hits:.*$/m, 'hits: ' + hits) : atual.replace(/^---$/m, '---\nhits: ' + hits);
  fs.writeFileSync(alvo, comHits.replace(/^updated:.*$/m, 'updated: ' + hoje));
  console.log('REFORÇADO (hits=' + hits + '): ' + path.relative(ROOT, alvo));
  process.exit(0);
}

const surface = opcao('surface') || titulo;
const triggers = opcao('triggers').split(',').map((s) => s.trim()).filter(Boolean);
const area = opcao('area');
const severity = opcao('severity', 'media');
const guard = opcao('guard');

if (area && /^([A-Za-z]:|[/~])/.test(area)) {
  console.error('FALHA: --area tem que ser RELATIVA ao cérebro (ex: _projetos), nunca caminho absoluto.');
  process.exit(1);
}

const fm = [
  '---',
  'tags: [learning]',
  'description: ' + surface.replace(/"/g, "'"),
  'created: ' + hoje,
  'updated: ' + hoje,
  'severity: ' + severity,
  'hits: 1',
  'checavel: ' + (guard ? 'true' : 'false'),
  guard ? 'guard: ' + guard : null,
  area ? 'area: ' + area : null,
  triggers.length ? 'triggers: [' + triggers.join(', ') + ']' : null,
  'surface: "' + surface.replace(/"/g, "'") + '"',
  '---',
].filter(Boolean).join('\n');

const corpo = [
  '',
  '# ' + titulo,
  '',
  '## O que aconteceu',
  '',
  '(o caso concreto: o que foi feito, o que quebrou, como apareceu)',
  '',
  '## A lição',
  '',
  surface,
  '',
  '## Como aplicar da próxima vez',
  '',
  '(a ação específica, não a intenção genérica)',
  '',
].join('\n');

fs.writeFileSync(alvo, fm + corpo);
console.log('APRENDIDO: ' + path.relative(ROOT, alvo));
if (triggers.length) console.log('  volta quando o assunto tocar em: ' + triggers.join(', '));
if (area) console.log('  volta quando alguém editar: ' + area);
if (!triggers.length && !area) console.log('  AVISO: sem triggers nem area, este aprendizado só volta por sorte.');
