'use strict';
// Gera o bloco AUTO:PENDENCIAS de _memory/pendencias.md: todas as pendencias abertas,
// agrupadas pela nota de origem. Fechar = marcar [x] na origem; este arquivo so reflete.
const path = require('node:path');
const b = require('../lib/brain');

function linha(p) {
  const partes = [];
  const u = b.urgencia(p);
  if (u) partes.push(u.toUpperCase());
  if (p.prazo) partes.push(`prazo ${p.prazo}`);
  if (p.prio !== 'media') partes.push(`prio ${p.prio}`);
  if (p.bloqueado) partes.push(`bloqueada: ${p.bloqueado}`);
  if (p.triggers.length) partes.push(`gatilho: ${p.triggers.join(', ')}`);
  const meta = partes.length ? ` _(${partes.join(' · ')})_` : '';
  const desc = p.desc ? ` :: ${p.desc}` : '';
  return `- ${p.title}${desc}${meta}`;
}

module.exports = function gerarPendencias() {
  const abertas = b.collectPendencias();
  const L = [];
  if (!abertas.length) {
    L.push('_Nenhuma pendência aberta._');
  } else {
    const porOrigem = new Map();
    for (const p of abertas) {
      if (!porOrigem.has(p.source.rel)) porOrigem.set(p.source.rel, { title: p.source.title, itens: [] });
      porOrigem.get(p.source.rel).itens.push(p);
    }
    L.push(`**${abertas.length} pendência(s) aberta(s)** em ${porOrigem.size} nota(s).`, '');
    for (const [rel, grupo] of [...porOrigem.entries()].sort((a, c) => a[0].localeCompare(c[0]))) {
      L.push(`### [${grupo.title}](${rel})`, '');
      for (const p of b.ordenarPendencias(grupo.itens)) L.push(linha(p));
      L.push('');
    }
  }
  return {
    file: path.join(b.ROOT, '_memory', 'pendencias.md'),
    name: 'PENDENCIAS',
    body: L.join('\n').trim(),
    insertAfter: /^# .*$/m,
  };
};
