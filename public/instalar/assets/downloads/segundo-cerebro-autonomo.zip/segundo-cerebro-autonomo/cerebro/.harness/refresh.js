#!/usr/bin/env node
'use strict';
// refresh.js - regenera tudo que e DERIVADO das notas: indice, estado vivo, pendencias,
// catalogo de aprendizados e o AGENTS.md (copia do CLAUDE.md pro Codex).
// Roda no inicio e no fim de toda sessao (hooks) e como CLI. Escreve so o que mudou.
//
//   node .harness/refresh.js            regenera
//   node .harness/refresh.js --report   so mostra o que mudaria
//
// Nunca bloqueia: erro de gerador vai pro stderr e o check.js (Stop) repete como aviso.

const fs = require('node:fs');
const path = require('node:path');
const b = require('./lib/brain');

const GERADORES = [
  require('./generators/indice'),
  require('./generators/estado'),
  require('./generators/pendencias'),
  require('./generators/learnings'),
];

const AGENTS_HEADER = '<!-- GERADO por .harness/refresh.js a partir de CLAUDE.md. Nao edite este arquivo: edite CLAUDE.md. -->\n\n';

function agentsFromClaude() {
  const claude = b.read(path.join(b.ROOT, 'CLAUDE.md'));
  return claude === null ? null : AGENTS_HEADER + claude;
}

function run({ dryRun = false } = {}) {
  const changed = [];
  const errors = [];
  for (const gerar of GERADORES) {
    let out;
    try { out = gerar(); } catch (e) { errors.push(`${gerar.name || 'gerador'}: ${e.message}`); continue; }
    try {
      const r = b.applyAutoBlock(out.file, out.name, out.body, { insertAfter: out.insertAfter, dryRun });
      if (r.missingFile) errors.push(`${out.name}: arquivo alvo nao existe: ${r.file}`);
      else if (r.changed) changed.push(`${out.name} -> ${r.file}`);
    } catch (e) {
      errors.push(`${out.name}: ${e.message}`);
    }
  }
  const agents = agentsFromClaude();
  if (agents !== null) {
    const file = path.join(b.ROOT, 'AGENTS.md');
    if (b.read(file) !== agents) {
      if (!dryRun) fs.writeFileSync(file, agents, 'utf8');
      changed.push('AGENTS.md (derivado de CLAUDE.md)');
    }
  }
  return { changed, errors };
}

module.exports = { run, GERADORES };

if (require.main === module) {
  const report = process.argv.includes('--report');
  const r = run({ dryRun: report });
  for (const c of r.changed) console.log((report ? 'mudaria: ' : 'atualizado: ') + c);
  for (const e of r.errors) console.error('erro: ' + e);
  if (!r.changed.length && !r.errors.length) console.log('refresh: tudo em dia.');
  process.exit(0);
}
