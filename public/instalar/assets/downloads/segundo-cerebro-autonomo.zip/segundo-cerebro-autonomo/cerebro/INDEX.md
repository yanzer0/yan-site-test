# Índice do cérebro

> Mapa de tudo que existe aqui, gerado das notas a cada sessão. Antes de procurar qualquer coisa, olhe aqui primeiro e vá direto na nota. Pra mudar a descrição de uma nota, edite o campo `description` no frontmatter dela.

<!-- AUTO:INDICE:START | gerado por .harness/refresh.js | não edite aqui: mude a nota de origem -->

_O índice é preenchido na primeira sessão._

<!-- AUTO:INDICE:END -->
