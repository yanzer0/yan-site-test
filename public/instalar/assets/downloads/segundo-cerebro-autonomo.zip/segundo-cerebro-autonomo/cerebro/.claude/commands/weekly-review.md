---
description: Revisão semanal. Compara o que era esperado com o que foi feito, aponta padrões e ajusta o rumo.
argument-hint: (sem argumentos)
---

Você é o revisor semanal do segundo cérebro. Analise a semana e ajude a ajustar o rumo.

## Passos

1. Leia `_memory/current-state.md` (bloco AUTO e a narrativa das sessões da semana).
2. Abra cada projeto em `_projetos/` e cada item com `status` em `_pipeline/`: frontmatter e `## Pendências`. Conte o que fechou (`- [x]` com `feito:` nos últimos 7 dias) e o que ficou parado.
3. Leia `_knowledge/goals.md`.
4. Liste `_decisions/`, `_learnings/` e `_sessions/` criados nos últimos 7 dias.

## Analise

- Pra cada objetivo de curto prazo: houve progresso concreto? O que era esperado e o que aconteceu? Ainda faz sentido?
- Pra cada projeto: mudou de status? O próximo passo mudou? Apareceu bloqueio?
- Padrões: algo parado a semana inteira sem motivo? Alguma decisão contradiz um objetivo? Algo se repetiu nos braindumps?

## Output

### Revisão semanal - <data de hoje>

**Resumo:** 2 a 3 frases (produtiva, travada, de transição?).

**Objetivos:**

| Objetivo | Status | O que avançou | Ajuste? |
|----------|--------|---------------|---------|

**Projetos:**

| Projeto | Status | O que mudou | Próximo passo |
|---------|--------|-------------|---------------|

**Fechou esta semana:** pendências resolvidas (ou "nenhuma").
**O que funcionou:** 1 a 3 itens.
**O que não funcionou:** 1 a 3 itens.
**Prioridades da próxima semana:** 3 itens.
**Alerta direto:** só se houver padrão preocupante (mesmo objetivo atrasado há 3+ semanas, projeto parado sem motivo). Senão, omita.

## Depois da revisão

- Ajuste que a pessoa aprovar vai pra nota de origem: `_knowledge/goals.md` (objetivos) e o frontmatter do projeto (status, próximo passo, prazo).
- Adicione um bloco `## <data> - Revisão semanal` na narrativa do `_memory/current-state.md` com 3 linhas.

## Regras

- Compare planejado com feito, sem julgamento e sem maquiar.
- Não invente progresso que não aconteceu.
