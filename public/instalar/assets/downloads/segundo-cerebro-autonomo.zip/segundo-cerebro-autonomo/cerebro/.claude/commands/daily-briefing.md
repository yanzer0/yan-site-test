---
description: Briefing do dia. Estado dos projetos, pendências urgentes e as 3 prioridades, lidos das notas de origem.
argument-hint: (sem argumentos)
---

Você é o segundo cérebro operacional. Gere o briefing do dia.

## Passos

1. Leia `_memory/current-state.md`. O bloco AUTO:ESTADO é a foto atual derivada das notas (projetos, pendências por urgência, recentes). A narrativa abaixo dele é histórico.
2. Pra cada projeto ativo listado, abra a nota em `_projetos/` e leia o frontmatter (`status`, `proximo_passo`, `prazo`) e a seção `## Pendências`. A nota é a verdade; o bloco é só o mapa.
3. Leia `_knowledge/goals.md` (objetivo dos 30 dias).
4. Se houver itens em `_pipeline/` com `status` (módulo negócios), leia o frontmatter de cada um.

## Regras anti-stale

- Nunca liste como "a fazer" algo marcado `- [x]` ou `concluido` em qualquer nota lida.
- Urgente = `(prazo:)` vencido ou a 5 dias ou menos. Sem prazo = sem pressa, mesmo com `prio:alta`.
- Se o bloco AUTO e a nota discordarem, a nota vence.
- Se o `CLAUDE.md` ainda tem `[SEU NOME]`, pare e proponha rodar `/comecar` primeiro.
- Não invente dados. Só o que está nas notas.

## Output (português, direto)

### Briefing - <data de hoje>

**Foco de hoje:** uma frase.

**Urgente:** pendências vencidas ou urgentes, cada uma com a nota de origem. Se não houver, "nada vencendo".

**Projetos:**

| Projeto | Status | Próximo passo | Prazo |
|---------|--------|---------------|-------|

**Prioridades (3):** ordenadas pelo impacto no objetivo dos 30 dias, cada uma com o porquê em meia linha.

**Alerta:** só se houver algo parado há muito tempo, contraditório ou sem próximo passo. Senão, omita.

Termine com UMA pergunta: "Por qual começamos?"
