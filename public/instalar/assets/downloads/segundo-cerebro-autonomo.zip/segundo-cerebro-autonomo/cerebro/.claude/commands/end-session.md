---
description: Fecha a sessão gravando o que mudou nas notas de origem (projetos, pendências, decisões, aprendizados). O harness regenera o resto.
argument-hint: (sem argumentos)
---

Você é o fechador de sessão. O princípio: o estado vivo mora na NOTA DA COISA (frontmatter e `## Pendências`), nunca numa lista solta. Você escreve na origem; o índice, o estado e as pendências se regeneram sozinhos ao fim do turno.

## Passos

1. Reconstrua o que a sessão produziu: ações, decisões, mudanças de status, o que ficou pendente.
2. Pra cada projeto ou item tocado: abra a nota em `_projetos/` (ou `_pipeline/`) e atualize `status`, `proximo_passo`, `prazo` (só data real) e `updated` (hoje). Pendência resolvida: marque `- [x]` e adicione `(feito:AAAA-MM-DD)`; nunca apague. Pendência nova: `- [ ] (trigger:palavras) (prio:alta|media|baixa) [(prazo:AAAA-MM-DD)] Título acionável :: detalhe`.
3. Projeto novo citado na sessão sem nota? Crie `_projetos/<slug>.md` pelo modelo `_projetos/_exemplo.md`.
4. Decisão estratégica (muda o rumo; micro-decisão não conta): `_decisions/AAAA-MM-DD-<slug>.md` com contexto, decisão, raciocínio, o que mudou e reversibilidade. Se ela substitui uma decisão antiga, carregue o "o que mudou" pra nova e apague a antiga. Superado é apagado, nunca marcado como arquivado.
5. Aprendizado reaproveitável (erro corrigido, gotcha que morde de novo): siga o ritual de `/aprendi`.
6. `_memory/current-state.md`: abaixo do bloco AUTO, adicione no topo da narrativa um bloco `## <data> - <tema>` com 3 a 6 linhas do que foi feito e decidido. Sem "próximos passos" ali: isso mora nas notas dos projetos.
7. Toda nota nova tem frontmatter (`tags`, `description`, `created`, `updated`). O guard bloqueia o fim do turno sem isso, e é você quem corrige.

## Output

### Fechamento - <data de hoje>

**Feito:** lista curta.
**Notas atualizadas:** nota -> o que mudou.
**Decisões:** ou "nenhuma".
**Aprendizados:** ou "nenhum".
**Pendências:** fechadas e novas.
**A próxima sessão começa por:** uma linha, a mesma que está no `proximo_passo` do projeto principal.

Honestidade radical: se a sessão rendeu pouco, diga.
