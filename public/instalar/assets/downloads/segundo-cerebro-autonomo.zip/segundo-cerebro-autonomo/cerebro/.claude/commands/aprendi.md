---
description: Registra um aprendizado que volta sozinho no momento certo, por assunto da conversa ou por área de arquivo.
argument-hint: [o que aprendemos agora]
---

Contexto: `$ARGUMENTS` (se vazio, infira da correção que acabou de acontecer nesta conversa).

Aprendizado guardado num arquivo que ninguém abre previne zero. Só muda comportamento se CHEGAR no contexto na hora da decisão. Por isso o que importa aqui é o frontmatter: é ele que faz a lição voltar.

## 1. Já existe?

Abra `_learnings/INDEX.md`. Se já existe aprendizado do MESMO erro: abra o arquivo, some 1 em `hits:` e atualize `updated:`. Erro que reincide vira UM aprendizado mais forte, nunca dois fracos. Pare aqui.

## 2. Escreva a lição, não o relato

Uma frase cada: o que aconteceu (caso concreto), a lição (regra em imperativo), como aplicar (ação específica). "Ter mais cuidado" não é lição. "Conferir a data no calendário antes de gravar um prazo" é.

## 3. Crie `_learnings/<slug-kebab>.md`

```markdown
---
tags: [learning, tema]
description: A lição em uma frase
created: <hoje>
updated: <hoje>
severity: alta | media | baixa
hits: 1
checavel: false
area: <pasta relativa, ex: _projetos>   (opcional)
triggers: [palavra específica, outra]
surface: "A regra em uma frase imperativa, sem travessão."
---

# <título curto e específico>

## O que aconteceu
## A lição
## Como aplicar da próxima vez
```

- `triggers`: palavras que, aparecendo na conversa, trazem a lição de volta. Específicas, nunca genéricas: genérico casa em tudo e vira ruído.
- `area`: pasta cujo arquivo editado traz a lição de volta. Sempre RELATIVA ao cérebro, nunca caminho absoluto.
- `surface`: o texto exato que será injetado. Uma linha, imperativo.
- `checavel: true` só se existir um guard de verdade (e aí preencha `guard:`).

## 4. Confirme

Diga em 2 linhas: o que foi registrado e por qual gatilho volta. Se a prevenção é só por injeção (sem guard), diga que é provável, não garantida. Honestidade radical.
