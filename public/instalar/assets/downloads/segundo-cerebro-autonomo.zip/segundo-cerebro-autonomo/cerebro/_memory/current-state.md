---
tags: [memory, estado]
description: A foto atual do cérebro (gerada das notas) e, abaixo dela, a narrativa das sessões.
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Estado atual

<!-- AUTO:ESTADO:START | gerado por .harness/refresh.js | não edite aqui: mude a nota de origem -->

_O estado é preenchido na primeira sessão._

<!-- AUTO:ESTADO:END -->

## Narrativa das sessões

> O `/end-session` escreve aqui, no topo, um bloco por sessão: o que foi feito e decidido. É histórico, não lista de tarefas. Tarefa, status e próximo passo moram na nota do projeto.

_Nenhuma sessão fechada ainda._
