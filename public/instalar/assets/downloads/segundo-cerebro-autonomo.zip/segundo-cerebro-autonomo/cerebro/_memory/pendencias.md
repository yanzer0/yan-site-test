---
tags: [memory, pendencias]
description: Todas as pendências abertas, agrupadas por nota de origem (gerado).
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Pendências abertas

> Gerado das seções `## Pendências` de todas as notas. Pra fechar uma pendência, marque `- [x]` na nota de origem (o link está em cada grupo) e adicione `(feito:AAAA-MM-DD)`.

<!-- AUTO:PENDENCIAS:START | gerado por .harness/refresh.js | não edite aqui: mude a nota de origem -->

_Preenchido na primeira sessão._

<!-- AUTO:PENDENCIAS:END -->
