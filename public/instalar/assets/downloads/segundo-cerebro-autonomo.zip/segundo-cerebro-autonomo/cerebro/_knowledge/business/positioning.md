---
tags: [knowledge, business, positioning]
status: active
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Posicionamento

> **Módulo negócios** - Este arquivo é opcional. Se você não usa o segundo cérebro para negócios, pode ignorar ou deletar a pasta `_knowledge/business/` inteira.

Defina como seu negócio/serviço se posiciona no mercado. O `/prospect-research` e o `/proposal-generator` usam este arquivo para gerar mensagens alinhadas.

---

## O Que Eu Faço

- [ ] **Em 1 frase:** [Ex: "Construo infraestrutura digital de credibilidade para negócios locais"]
- [ ] **Descrição expandida:** [Ex: "Crio sites profissionais que convertem visitantes em contatos para negócios que dependem de indicações"]

## Para Quem

- [ ] **Público-alvo:** [Ex: "Negócios locais de serviço com 2+ anos de operação, boa reputação, mas presença digital fraca"]
- [ ] **Nicho principal:** [Ex: "Clínicas, escritórios de advocacia, consultórios"]
- [ ] **Onde eles estão:** [Ex: "Google Maps, LinkedIn, Upwork, indicações"]

## Que Problema Resolvo

- [ ] **A dor do cliente:** [Ex: "Eles perdem clientes silenciosamente porque a presença digital não reflete a qualidade real do trabalho"]
- [ ] **O que acontece sem mim:** [Ex: "O cliente indicado pesquisa o nome no Google, não encontra nada confiável, e desiste sem avisar"]
- [ ] **O que acontece comigo:** [Ex: "O cliente indicado encontra um site profissional que transmite confiança e entra em contato"]

## Meu Diferencial

- [ ] **O que me diferencia da concorrência:** [Ex: "Diagnóstico antes de vender, foco em conversão, não em estética"]
- [ ] **O que eu NÃO faço (e por quê):** [Ex: "Não prometo SEO como feature isolada, não vendo pacotes de marketing digital"]
- [ ] **Por que alguém escolheria eu:** [Ex: "Porque eu mostro o problema antes de oferecer a solução - gera confiança"]

## Linguagem do Posicionamento

- [ ] **Palavras que uso:** [Ex: "credibilidade, infraestrutura, conversão, impacto"]
- [ ] **Palavras que evito:** [Ex: "site bonito, SEO, ranking, visibilidade, marketing digital"]
- [ ] **Tom geral:** [Ex: "Direto, confiante, baseado em dados, sem promessas vagas"]

---

## Related

- [[icp]] - Quem é o cliente ideal
- [[services]] - O que ofereço e por quanto
- [[tone-of-voice]] - Como me comunico


## Diferenciação Kit Segundo Cérebro vs. Claude Projects (nativo) — 20/07

Pergunta recorrente que vai aparecer em conteúdo/DM: "qual a diferença do Segundo Cérebro pros Projetos do Claude, que já são de graça?"

**Resposta de posicionamento (não são concorrentes):**
- **Projetos (Claude)** = um container vazio que a própria Claude dá de graça. Você sobe arquivo e escreve instrução, mas ele não diz COMO organizar isso — sem estrutura, vira bagunça com o tempo (fato antigo misturado com atual, sem índice). Também só existe dentro do Claude.com, não viaja pro Claude Code nem pra outra IA.
- **Kit Segundo Cérebro** = a metodologia + estrutura de arquivos que resolve exatamente esse problema. Confirmado na pasta real do produto (`_infoprodutos/segundo-cerebro/`): `CLAUDE.md` raiz, `_knowledge/` (fatos estáveis: posicionamento, preço, tom de voz, ICP), `_memory/current-state.md` (separado, o que está rolando agora), `_pipeline/` (trabalho ativo), `_prompts/` numerados de setup guiado (criar estrutura → gerar knowledge → configurar estado → primeiro teste), guias de instalação/personalização.
- **Framing de venda:** Projeto é o "onde" (o espaço). Segundo Cérebro é o "como" (a estrutura que organiza o que vai dentro desse espaço). O Kit roda DENTRO de um Projeto, dentro do Claude Code, ou em qualquer IA que leia arquivo — não compete com Projetos, complementa.

**Aplicação em conteúdo:** ao mencionar "Projetos" como funcionalidade do Claude em qualquer carrossel/post (ex: linha "recursos escondidos"), esse é um bridge natural pro Kit, não um risco de canibalização — fechar o slide com algo tipo "Projetos é ótimo, mas só funciona bem com estrutura por trás, que é o que o Kit entrega."

Related: [[../../../_knowledge/conteudo/estrategia-de-conteudo/linha-editorial-instagram-4-produtos]]