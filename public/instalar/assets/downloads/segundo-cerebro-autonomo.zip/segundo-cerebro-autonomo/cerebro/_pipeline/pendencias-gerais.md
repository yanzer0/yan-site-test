---
tags: [pipeline, pendencias]
description: Pendências que não pertencem a nenhum projeto ou item específico.
created: [DATA DE HOJE]
updated: [DATA DE HOJE]
---

# Pendências gerais

> Tudo que precisa ser feito mas não tem uma nota natural (projeto, cliente). Mesmo formato de sempre: `- [ ] (trigger:palavras) (prio:alta|media|baixa) (prazo:AAAA-MM-DD) Título :: detalhe`.

## Pendências

