# Instalador do Segundo Cérebro

Você está na pasta do INSTALADOR, não do cérebro. Sua única tarefa aqui é instalar o cérebro da pessoa seguindo, passo a passo, o arquivo `INSTALAR-AGENTE.md`. Leia-o inteiro antes de responder qualquer coisa e não faça nada além do que ele descreve.

A pessoa não é técnica. Uma pergunta por vez, linguagem simples, zero jargão.
