# Instalar o Segundo Cérebro (roteiro do agente)

Você (Claude Code ou Codex) vai instalar o cérebro da pessoa. Ela abriu esta pasta no app e digitou algo como "instala meu segundo cérebro". Siga os passos na ordem. Não pule a prova. Não invente passos.

## Regras de conversa

- A pessoa não é técnica. Uma pergunta por vez, resposta curta, linguagem simples. Nunca mostre comando, caminho ou jargão a não ser o que este roteiro manda mostrar.
- Se ela responder "pode ser o padrão", "tanto faz", "sim": aceite e siga.
- Se algo der errado, diga em uma frase o que aconteceu e o que ela precisa fazer (geralmente: mandar um print ou tentar de novo). Não despeje log na tela.
- Se o app pedir permissão pra rodar um comando, é esperado: ela clica em permitir.

## Passo 0: reduzir interrupções de permissão

Antes de usar qualquer ferramenta, peça para a pessoa ajustar o controle de permissões durante a instalação. No Claude para macOS, ela clica em "Aceitar edições", na barra inferior, e escolhe **Automático**. No Codex, ela escolhe **Acesso completo** e confirma a tela de risco. Explique sem esconder: esse modo libera comandos, internet e qualquer arquivo do computador sem nova permissão. A escolha foi adotada para que a instalação não pare a cada comando.

Diga em uma frase: "Isso evita interrupções durante a instalação e dá acesso amplo ao computador; quando terminarmos, você pode manter essa configuração ou voltar ao modo que preferir."

O aviso nativo do macOS para acessar dados de outro app não é controlado por esse modo. Se ele aparecer, a pessoa precisa clicar em "Permitir".

## Passo 1: descobrir o sistema

Descubra em silêncio se está no Windows, macOS ou Linux (pelo formato dos caminhos ou rodando `uname -s` / verificando `$env:OS`). Não pergunte isso a ela.

## Passo 2: onde o cérebro vai morar

Pergunte:

> Onde você quer guardar o seu cérebro? Se não tiver preferência, eu crio em Documentos, numa pasta chamada "Segundo Cerebro".

Caminho padrão:
- Windows: `C:\Users\<usuário>\Documents\Segundo Cerebro` (descubra o usuário com `$env:USERPROFILE` ou `~`)
- macOS: `/Users/<usuário>/Documents/Segundo Cerebro`
- Linux: `/home/<usuário>/Documentos/Segundo Cerebro` (ou `Documents`, o que existir)

Se ela indicar outra pasta, use a dela. A pasta precisa ser nova ou vazia. Nunca instale em cima de algo existente.

No Codex, confirme antes de executar que a pasta-pai do destino aparece entre as pastas de origem do projeto. Se não aparecer, pare e diga: "O Codex ainda não pode escrever nessa pasta. Nas configurações deste projeto, adicione a pasta onde o cérebro vai ficar e me avise quando estiver pronto." Não repita o mesmo comando enquanto o acesso não mudar.

Antes de executar, verifique em silêncio se o destino já existe e tem arquivos. Se tiver, não rode o instalador. Peça uma pasta nova e sugira outro nome simples, como "Segundo Cerebro 2".

## Passo 3: por onde ela vai usar

Pergunte:

> Você vai usar o cérebro pelo Claude, pelo Codex (o do ChatGPT) ou pelos dois?

Mapeie: Claude -> `--claude` (`-Claude` no Windows), Codex -> `--codex` (`-Codex`), os dois -> ambos. Se ela não souber, use o app em que você está agora.

## Passo 4: instalar

Rode o instalador da pasta atual (o pacote). Ele garante o Node, cria a pasta, copia o cérebro, liga os hooks e PROVA que funciona.

Windows (rode pelo PowerShell; se você só tem o Bash, prefixe com `powershell.exe -NoProfile -ExecutionPolicy Bypass -File`):

```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "./instalar.ps1" -Destino "C:\Users\<usuário>\Documents\Segundo Cerebro" -Claude -Codex
```

macOS e Linux:

```
bash "./instalar.sh" --destino "/Users/<usuário>/Documents/Segundo Cerebro" --claude --codex
```

Use só as flags escolhidas no passo 3. Pode demorar um pouco se precisar baixar o Node (uns 30 MB): avise "isso pode levar um minuto".

## Passo 5: ler o resultado

Procure na saída:

- `INSTALADO EM: <pasta>` e linhas `PROVA: ...` -> deu certo.
- `AVISO: ...` -> deu certo, mas conte o aviso pra ela em uma frase simples (exemplo: "o Git ainda não está instalado, o guia mostra como").
- `FALHA: ...` -> não deu certo. Diga o motivo em uma frase e o que fazer: pasta não vazia -> escolher outra pasta; download do Node falhou -> tentar de novo; qualquer outra coisa -> pedir pra mandar um print da tela pro suporte. Não tente consertar por conta própria além de repetir o comando uma vez.
- Se o Codex negar escrita fora das pastas de origem do projeto, não repita o comando. Peça para adicionar a pasta-pai do destino ao projeto e continue somente depois disso.

## Passo 6: dizer o próximo passo, exatamente assim

Se deu certo, mande UMA mensagem com:

1. "Pronto. Seu cérebro foi criado em: `<pasta exata>`."
2. Os próximos passos dela, numerados:
   - Feche esta conversa.
   - No app, abra a pasta `<pasta exata>` (no Claude: aba Code, "Select folder"; no Codex: abrir pasta / projeto).
   - Se o app perguntar se você confia na pasta, confirme.
   - No Claude, digite `/comecar` e responda as perguntas. Leva uns 5 minutos.
   - No Codex, digite `$comecar` e espere aparecer a primeira pergunta. Então abra Configurações > Hooks, abra o projeto, revise e ligue os 8 hooks. Antes do primeiro task, a tela pode dizer "Nenhum hook encontrado" mesmo com o arquivo instalado; o primeiro task faz o app descobrir a configuração. Volte à conversa e continue as perguntas. Depois da aprovação, abra uma conversa nova para que o contexto inicial também seja carregado automaticamente.
3. Uma linha: "O guia que veio com a compra mostra cada tela dessas com print."

Não faça mais nada nesta pasta depois disso.
