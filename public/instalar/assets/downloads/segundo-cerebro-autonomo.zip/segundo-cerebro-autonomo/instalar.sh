#!/usr/bin/env bash
# instalar.sh - macOS e Linux. Garante o Node (baixa uma copia portatil se faltar) e chama instalar.mjs.
#
#   bash instalar.sh --destino "$HOME/Documents/Segundo Cerebro" --claude --codex
#
# O Node portatil fica em .tools/node dentro do PACOTE e e copiado pra dentro do cerebro.
# O download e conferido contra o SHASUMS256.txt oficial do nodejs.org.

set -euo pipefail

PACOTE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESTINO=""; CLAUDE=0; CODEX=0; SOHOOKS=0
while [ $# -gt 0 ]; do
  case "$1" in
    --destino) DESTINO="$2"; shift 2;;
    --claude) CLAUDE=1; shift;;
    --codex) CODEX=1; shift;;
    --so-hooks) SOHOOKS=1; shift;;
    *) echo "argumento desconhecido: $1"; exit 1;;
  esac
done
[ -n "$DESTINO" ] || { echo "uso: bash instalar.sh --destino <pasta> [--claude] [--codex]"; exit 1; }

NODE=""; PORTATIL=""
if command -v node >/dev/null 2>&1; then
  MAJOR=$(node -v | sed 's/^v//' | cut -d. -f1)
  if [ "$MAJOR" -ge 18 ] 2>/dev/null; then NODE=node; fi
fi

if [ -z "$NODE" ]; then
  echo "Node não encontrado (ou antigo). Baixando uma cópia portátil só pro cérebro..."
  OS=$(uname -s); ARCH=$(uname -m)
  case "$OS" in
    Darwin) EXT=tar.gz; case "$ARCH" in arm64) ALVO=darwin-arm64;; *) ALVO=darwin-x64;; esac;;
    Linux) EXT=tar.xz; case "$ARCH" in aarch64|arm64) ALVO=linux-arm64;; *) ALVO=linux-x64;; esac;;
    *) echo "sistema não suportado: $OS"; exit 1;;
  esac
  BASE="https://nodejs.org/dist/latest-v22.x/"
  LINHA=$(curl -fsSL "${BASE}SHASUMS256.txt" | grep -E "node-v22\.[0-9]+\.[0-9]+-${ALVO}\.${EXT}\$" | head -n1)
  [ -n "$LINHA" ] || { echo "não achei o build ${ALVO} do Node 22 em nodejs.org"; exit 1; }
  HASH=$(echo "$LINHA" | awk '{print $1}')
  ARQ=$(echo "$LINHA" | awk '{print $2}')
  TOOLS="$PACOTE/.tools"; mkdir -p "$TOOLS"
  curl -fSL --progress-bar "${BASE}${ARQ}" -o "$TOOLS/$ARQ"
  if command -v sha256sum >/dev/null 2>&1; then REAL=$(sha256sum "$TOOLS/$ARQ" | awk '{print $1}'); else REAL=$(shasum -a 256 "$TOOLS/$ARQ" | awk '{print $1}'); fi
  [ "$REAL" = "$HASH" ] || { echo "o download do Node não bateu com a assinatura oficial. Tente de novo."; exit 1; }
  rm -rf "$TOOLS/node"
  case "$EXT" in
    tar.gz) tar -xzf "$TOOLS/$ARQ" -C "$TOOLS";;
    tar.xz) tar -xJf "$TOOLS/$ARQ" -C "$TOOLS";;
  esac
  mv "$TOOLS/${ARQ%.$EXT}" "$TOOLS/node"
  rm -f "$TOOLS/$ARQ"
  NODE="$TOOLS/node/bin/node"; PORTATIL="$TOOLS/node"
  echo "Node portátil pronto."
fi

ARGS=(--destino "$DESTINO")
[ "$CLAUDE" -eq 1 ] && ARGS+=(--claude)
[ "$CODEX" -eq 1 ] && ARGS+=(--codex)
[ "$SOHOOKS" -eq 1 ] && ARGS+=(--so-hooks)
[ -n "$PORTATIL" ] && ARGS+=(--node-portatil "$PORTATIL")

exec "$NODE" "$PACOTE/instalar.mjs" "${ARGS[@]}"
