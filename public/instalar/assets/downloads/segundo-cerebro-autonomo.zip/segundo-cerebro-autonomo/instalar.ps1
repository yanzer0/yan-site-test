# instalar.ps1 - Windows. Garante o Node (baixa uma copia portatil se faltar) e chama instalar.mjs.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File instalar.ps1 -Destino "C:\Users\voce\Documents\Segundo Cerebro" -Claude -Codex
#
# O Node portatil fica em .tools\node dentro do PACOTE e e copiado pra dentro do cerebro.
# O download e conferido contra o SHASUMS256.txt oficial do nodejs.org.

param(
  [Parameter(Mandatory = $true)][string]$Destino,
  [switch]$Claude,
  [switch]$Codex,
  [switch]$SoHooks
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Pacote = Split-Path -Parent $MyInvocation.MyCommand.Path

function Node-Do-Sistema {
  try {
    $v = (& node -v) 2>$null
    if ($v -match '^v(\d+)' -and [int]$Matches[1] -ge 18) { return 'node' }
  } catch {}
  return $null
}

function Baixar-Node-Portatil {
  Write-Host 'Node não encontrado (ou antigo). Baixando uma cópia portátil só pro cérebro...'
  $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'win-arm64' } else { 'win-x64' }
  $base = 'https://nodejs.org/dist/latest-v22.x/'
  $sums = (Invoke-WebRequest -Uri ($base + 'SHASUMS256.txt') -UseBasicParsing).Content
  $linha = ($sums -split "`n") | Where-Object { $_ -match "node-v22\.\d+\.\d+-$arch\.zip" } | Select-Object -First 1
  if (-not $linha) { throw "não achei o build $arch do Node 22 em nodejs.org" }
  $partes = $linha.Trim() -split '\s+'
  $hash = $partes[0]
  $arquivo = $partes[1]

  $tools = Join-Path $Pacote '.tools'
  New-Item -ItemType Directory -Force $tools | Out-Null
  $zip = Join-Path $tools $arquivo
  Invoke-WebRequest -Uri ($base + $arquivo) -OutFile $zip -UseBasicParsing
  $real = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
  if ($real -ne $hash.ToLower()) { throw 'o download do Node não bateu com a assinatura oficial. Tente de novo.' }

  $destinoNode = Join-Path $tools 'node'
  if (Test-Path $destinoNode) { Remove-Item -Recurse -Force $destinoNode }
  Expand-Archive -Path $zip -DestinationPath $tools -Force
  Move-Item (Join-Path $tools ($arquivo -replace '\.zip$', '')) $destinoNode
  Remove-Item $zip -Force
  Write-Host 'Node portátil pronto.'
  return $destinoNode
}

$node = Node-Do-Sistema
$portatil = $null
if (-not $node) {
  $portatil = Baixar-Node-Portatil
  $node = Join-Path $portatil 'node.exe'
}

$argumentos = @((Join-Path $Pacote 'instalar.mjs'), '--destino', $Destino)
if ($Claude) { $argumentos += '--claude' }
if ($Codex) { $argumentos += '--codex' }
if ($SoHooks) { $argumentos += '--so-hooks' }
if ($portatil) { $argumentos += @('--node-portatil', $portatil) }

& $node @argumentos
exit $LASTEXITCODE
