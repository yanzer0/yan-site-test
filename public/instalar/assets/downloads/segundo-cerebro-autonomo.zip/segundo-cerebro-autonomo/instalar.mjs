#!/usr/bin/env node
// instalar.mjs - cria o Segundo Cerebro na pasta escolhida e liga o harness no Claude Code
// e/ou no Codex. Quem roda isto normalmente e o proprio agente, seguindo INSTALAR-AGENTE.md,
// atraves de instalar.ps1 (Windows) ou instalar.sh (macOS/Linux), que garantem o Node antes.
//
//   node instalar.mjs --destino "<pasta>" --claude --codex [--node-portatil <dir>] [--so-hooks]
//
// NAO faz nada escondido: lista o que escreveu e PROVA que o harness roda antes de dizer que
// terminou. Instalador que so imprime "sucesso" nao provou nada.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const PACOTE = path.dirname(fileURLToPath(import.meta.url));
const MODELO = path.join(PACOTE, 'cerebro');
const HOJE = new Date().toISOString().slice(0, 10);
const PULAR = new Set(['.git', '.tools', 'node_modules']);

// O que roda em cada evento, nos dois agentes. Uma lista so, pra Claude e Codex nunca divergirem.
const SCRIPTS = {
  SessionStart: ['session-start.js'],
  UserPromptSubmit: ['inject-pendencias.js', 'inject-learnings.js'],
  PreToolUse: ['guard-pretool.js'],
  PreToolUseEscrita: ['inject-learnings.js'],
  Stop: ['refresh.js', 'check.js'],
  PreCompact: ['pre-compact.js'],
};

// ---------------------------------------------------------------- utilidades

function lerArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (!a.startsWith('--')) continue;
    const chave = a.slice(2);
    const proximo = argv[i + 1];
    if (proximo !== undefined && !proximo.startsWith('--')) { out[chave] = proximo; i += 1; } else out[chave] = true;
  }
  return out;
}

function falhar(msg) {
  console.error('FALHA: ' + msg);
  process.exit(1);
}

function posix(p) { return p.split(path.sep).join('/'); }

function aspasPowerShell(valor) {
  return `'${String(valor).replace(/'/g, "''")}'`;
}

function expandirHome(p) {
  return p.startsWith('~') ? path.join(os.homedir(), p.slice(1)) : p;
}

function listar(dir, acc = []) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    if (item.isDirectory()) { if (!PULAR.has(item.name)) listar(path.join(dir, item.name), acc); continue; }
    acc.push(path.join(dir, item.name));
  }
  return acc;
}

// ---------------------------------------------------------------- criacao do cerebro

function carimbarDatas(raiz) {
  for (const f of listar(raiz)) {
    if (!f.endsWith('.md')) continue;
    const texto = fs.readFileSync(f, 'utf8');
    if (texto.includes('[DATA DE HOJE]')) fs.writeFileSync(f, texto.split('[DATA DE HOJE]').join(HOJE), 'utf8');
  }
}

function resolverNode(raiz) {
  const win = path.join(raiz, '.tools', 'node', 'node.exe');
  const nix = path.join(raiz, '.tools', 'node', 'bin', 'node');
  if (fs.existsSync(win)) return { exec: win, portatil: true };
  if (fs.existsSync(nix)) return { exec: nix, portatil: true };
  return { exec: process.execPath, portatil: false };
}

// ---------------------------------------------------------------- Claude Code

function comandoClaude(script) {
  // Expandido pelo shell do hook (Git Bash no Windows, sh no macOS/Linux). Sem caminho
  // absoluto: a pasta pode ser movida e continua funcionando.
  return 'sh "${CLAUDE_PROJECT_DIR}/.harness/run" "${CLAUDE_PROJECT_DIR}" ' + script;
}

function hooksClaude() {
  const h = (script, extra = {}) => ({ type: 'command', command: comandoClaude(script), timeout: 120, ...extra });
  return {
    SessionStart: [{ hooks: SCRIPTS.SessionStart.map((s) => h(s)) }],
    UserPromptSubmit: [{ hooks: SCRIPTS.UserPromptSubmit.map((s) => h(s, { timeout: 30 })) }],
    PreToolUse: [
      { matcher: '', hooks: SCRIPTS.PreToolUse.map((s) => h(s, { timeout: 30 })) },
      { matcher: 'Edit|Write|MultiEdit', hooks: SCRIPTS.PreToolUseEscrita.map((s) => h(s, { timeout: 30 })) },
    ],
    Stop: [{ hooks: SCRIPTS.Stop.map((s) => h(s)) }],
    PreCompact: [{ hooks: SCRIPTS.PreCompact.map((s) => h(s, { timeout: 30 })) }],
  };
}

function escreverClaude(raiz) {
  const arquivo = path.join(raiz, '.claude', 'settings.json');
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(arquivo, 'utf8')); } catch { cfg = {}; }
  cfg.hooks = hooksClaude();
  fs.mkdirSync(path.dirname(arquivo), { recursive: true });
  fs.writeFileSync(arquivo, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
  return posix(path.relative(raiz, arquivo));
}

// ---------------------------------------------------------------- Codex

function hooksCodex(raiz, nodeExec) {
  const shim = posix(path.join(raiz, '.harness', 'codex-shim.mjs'));
  const nodeSemAspas = nodeExec.portatil ? posix(nodeExec.exec) : 'node';
  const node = nodeExec.portatil ? `"${nodeSemAspas}"` : nodeSemAspas;
  const h = (script, extra = {}) => ({
    type: 'command',
    command: `${node} "${shim}" ${script}`,
    commandWindows: `powershell.exe -NoProfile -Command "& ${aspasPowerShell(nodeSemAspas)} ${aspasPowerShell(shim)} ${aspasPowerShell(script)}"`,
    timeout: 120,
    ...extra,
  });
  const ctx = { additionalContextLimit: 6000 };
  // O parser do Codex e ESTRITO: so `description` e `hooks` no topo, senao NENHUM hook carrega.
  return {
    description: 'Harness do Segundo Cerebro (gerado pelo instalador; nao edite a mao).',
    hooks: {
      SessionStart: [{ hooks: SCRIPTS.SessionStart.map((s) => h(s, ctx)) }],
      UserPromptSubmit: [{ hooks: SCRIPTS.UserPromptSubmit.map((s) => h(s, { timeout: 30, ...ctx })) }],
      PreToolUse: [
        { hooks: SCRIPTS.PreToolUse.map((s) => h(s, { timeout: 30, ...ctx })) },
        { matcher: 'apply_patch|Edit|Write', hooks: SCRIPTS.PreToolUseEscrita.map((s) => h(s, { timeout: 30, ...ctx })) },
      ],
      Stop: [{ hooks: SCRIPTS.Stop.map((s) => h(s)) }],
      PreCompact: [{ hooks: SCRIPTS.PreCompact.map((s) => h(s, { timeout: 30 })) }],
    },
  };
}

function escreverCodex(raiz, nodeExec) {
  const arquivo = path.join(raiz, '.codex', 'hooks.json');
  fs.mkdirSync(path.dirname(arquivo), { recursive: true });
  fs.writeFileSync(arquivo, JSON.stringify(hooksCodex(raiz, nodeExec), null, 2) + '\n', 'utf8');
  return posix(path.relative(raiz, arquivo));
}

// Os comandos do Claude (.claude/commands/*.md) viram skills do Codex (.agents/skills/<nome>/SKILL.md).
function gerarSkillsCodex(raiz) {
  const origem = path.join(raiz, '.claude', 'commands');
  const gerados = [];
  for (const nome of fs.readdirSync(origem).filter((f) => f.endsWith('.md')).sort()) {
    const slug = nome.replace(/\.md$/, '');
    const texto = fs.readFileSync(path.join(origem, nome), 'utf8');
    const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(texto);
    const corpo = m ? texto.slice(m[0].length) : texto;
    const descricao = ((m && (/^description:\s*(.+)$/m.exec(m[1]) || [])[1]) || corpo.split(/\r?\n/).find((l) => l.trim()) || slug).trim();
    const destino = path.join(raiz, '.agents', 'skills', slug);
    fs.mkdirSync(destino, { recursive: true });
    fs.writeFileSync(path.join(destino, 'SKILL.md'),
      `---\nname: ${slug}\ndescription: "${descricao.replace(/"/g, '\\"')}"\n---\n\n${corpo.trimStart()}`, 'utf8');
    gerados.push(slug);
  }
  return gerados;
}

// ---------------------------------------------------------------- prova

function rodar(exec, args, raiz, stdin = '') {
  return spawnSync(exec, args, {
    cwd: raiz, encoding: 'utf8', input: stdin, windowsHide: true,
    env: { ...process.env, CLAUDE_PROJECT_DIR: raiz },
  });
}

function acharSh() {
  if (process.platform !== 'win32') return 'sh';
  const candidatos = [
    'C:\\Program Files\\Git\\bin\\sh.exe',
    'C:\\Program Files\\Git\\usr\\bin\\sh.exe',
    'C:\\Program Files (x86)\\Git\\bin\\sh.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Git', 'bin', 'sh.exe'),
  ];
  const achado = candidatos.find((c) => fs.existsSync(c));
  if (achado) return achado;
  const w = spawnSync('where', ['sh'], { encoding: 'utf8', windowsHide: true });
  return (w.stdout || '').split(/\r?\n/).find(Boolean) || null;
}

function provar(raiz, nodeExec) {
  const provas = [];
  const avisos = [];
  const H = (s) => path.join(raiz, '.harness', s);

  const check = rodar(nodeExec.exec, [H('check.js'), '--quiet'], raiz);
  if (check.status !== 0) falhar('o guard de consistência reprovou o cérebro recém-criado:\n' + check.stderr);
  provas.push('guard de consistência passou no cérebro novo');

  const memoria = rodar(nodeExec.exec, [H('inject-learnings.js')], raiz,
    JSON.stringify({ hook_event_name: 'UserPromptSubmit', prompt: 'qual o próximo passo?' }));
  if (!/MEM/.test(memoria.stdout)) falhar('a memória de aprendizados não voltou por assunto');
  provas.push('a memória de aprendizados volta por assunto');

  const guard = rodar(nodeExec.exec, [H('guard-pretool.js')], raiz,
    JSON.stringify({ tool_name: 'Grep', tool_input: { pattern: 'x' }, session_id: `prova-${Date.now()}` }));
  if (!/"deny"/.test(guard.stdout)) falhar('o guard de busca cega não bloqueou');
  provas.push('guard de busca cega ativo');

  const indice = fs.readFileSync(path.join(raiz, 'INDEX.md'), 'utf8');
  const notas = (indice.match(/^\| \[/gm) || []).length;
  if (!notas) falhar('o índice saiu vazio');
  provas.push(`índice gerado com ${notas} nota(s)`);

  if (process.platform === 'win32') {
    const cfg = JSON.parse(fs.readFileSync(path.join(raiz, '.codex', 'hooks.json'), 'utf8'));
    const comando = cfg.hooks.SessionStart[0].hooks[0].commandWindows;
    const r = spawnSync(comando, {
      cwd: raiz,
      encoding: 'utf8',
      input: JSON.stringify({ hook_event_name: 'SessionStart', cwd: raiz }),
      windowsHide: true,
      shell: true,
    });
    if (r.status !== 0 || !/Segundo Cérebro/.test(r.stdout || '')) {
      falhar('o comando Windows do hook do Codex não respondeu:\n' + ((r.stderr || r.stdout || 'sem saída').trim().slice(0, 500)));
    }
    provas.push('comando Windows dos hooks do Codex funciona');
  }

  const sh = acharSh();
  if (!sh) {
    avisos.push('sh não encontrado: no Windows, o Claude precisa do Git for Windows pra aba Code. Instale o Git e os hooks passam a rodar.');
  } else {
    const r = spawnSync(sh, [H('run'), raiz, 'session-start.js'], { cwd: raiz, encoding: 'utf8', input: '{}', windowsHide: true });
    if (/Segundo Cérebro/.test(r.stdout || '')) provas.push('lançador dos hooks funciona' + (nodeExec.portatil ? ' com o Node portátil' : ''));
    else avisos.push('o lançador dos hooks não respondeu: ' + ((r.stderr || r.stdout || 'sem saída').trim().slice(0, 200)));
  }
  return { provas, avisos };
}

// ---------------------------------------------------------------- execucao

function main() {
  const args = lerArgs(process.argv.slice(2));
  if (!args.destino || args.destino === true) falhar('faltou --destino <pasta>');
  const raiz = path.resolve(expandirHome(String(args.destino)));
  const claude = !!args.claude;
  const codex = !!args.codex;
  if (!claude && !codex) falhar('escolha --claude, --codex ou os dois');
  const soHooks = !!args['so-hooks'];
  const temCerebro = fs.existsSync(path.join(raiz, 'CLAUDE.md'));

  console.log('Segundo Cérebro - instalação');
  console.log('pasta: ' + raiz);
  console.log('');

  if (soHooks) {
    if (!temCerebro) falhar('--so-hooks precisa de um cérebro já instalado em ' + raiz);
  } else {
    if (temCerebro) falhar('já existe um cérebro em ' + raiz + '. Escolha outra pasta, ou use --so-hooks pra religar os hooks deste.');
    if (fs.existsSync(raiz) && fs.readdirSync(raiz).length) falhar('a pasta ' + raiz + ' não está vazia. Escolha uma pasta nova ou vazia.');
    fs.cpSync(MODELO, raiz, { recursive: true });
    carimbarDatas(raiz);
    if (args['node-portatil'] && args['node-portatil'] !== true) {
      fs.cpSync(String(args['node-portatil']), path.join(raiz, '.tools', 'node'), { recursive: true });
    }
    console.log('criado: o cérebro (notas, comandos e harness)');
  }

  const nodeExec = resolverNode(raiz);
  const escritos = [];
  if (claude) escritos.push(escreverClaude(raiz));
  if (codex) {
    escritos.push(escreverCodex(raiz, nodeExec));
    const skills = gerarSkillsCodex(raiz);
    escritos.push(`.agents/skills/ (${skills.length} comandos como skills: ${skills.join(', ')})`);
  }
  for (const e of escritos) console.log('escrito: ' + e);

  const refresh = rodar(nodeExec.exec, [path.join(raiz, '.harness', 'refresh.js')], raiz);
  if (refresh.status !== 0) falhar('o refresh inicial falhou:\n' + (refresh.stderr || refresh.stdout));

  const { provas, avisos } = provar(raiz, nodeExec);
  console.log('');
  for (const p of provas) console.log('PROVA: ' + p);
  for (const a of avisos) console.log('AVISO: ' + a);
  console.log('');
  console.log('INSTALADO EM: ' + raiz);
  console.log('LIGADO NO: ' + [claude ? 'Claude Code' : null, codex ? 'Codex' : null].filter(Boolean).join(' e '));
  if (nodeExec.portatil) console.log('NODE: portátil, dentro do cérebro (.tools/node)');
  console.log('');
  console.log('PRÓXIMO PASSO DA PESSOA: fechar esta sessão, abrir a pasta acima no app e digitar ' + (claude ? '/comecar' : '$comecar') + '.');
  if (codex) console.log('NO CODEX: confie na pasta. Se a tela de Hooks estiver vazia, rode $comecar uma vez; depois aprove os 8 hooks e inicie uma conversa nova.');
}

main();
